#!/bin/sh
set -eu

# DexAI Windows build workflow.
# This job builds the Windows x64 artifact and creates a release archive when a git tag is present.

echo "=== DexAI Windows Build Workflow ==="

ROOT_DIR="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT_DIR"

ARTIFACTS_DIR="${ARTIFACTS_DIR:-$ROOT_DIR/artifacts}"
OUT_DIR="${OUT_DIR:-$ROOT_DIR/build-release}"
IMAGE_NAME="${IMAGE_NAME:-dexai-windows-builder:latest}"
TMP_DIR="${TMPDIR:-$ROOT_DIR/.tmp}"
mkdir -p "$ARTIFACTS_DIR" "$OUT_DIR" "$TMP_DIR"
export TMPDIR="$TMP_DIR"
export TMP="$TMP_DIR"
export TEMP="$TMP_DIR"

# Build Windows artifact. Prefer the native Windows PowerShell build script when it is
# available, and fall back to the Docker cross-build path for Linux hosts.
if command -v pwsh >/dev/null 2>&1 || command -v powershell >/dev/null 2>&1; then
    echo "Building Windows x64 static binary via PowerShell build script..."
    if command -v pwsh >/dev/null 2>&1; then
        pwsh -NoProfile -ExecutionPolicy Bypass -File "$ROOT_DIR/scripts/build-windows.ps1" \
            -Configuration Release \
            -BuildDir "build-x64-windows-msvc+static-release" \
            -ArtifactDir "$ARTIFACTS_DIR" \
            -PackageDir "$ROOT_DIR/package"
    else
        powershell -NoProfile -ExecutionPolicy Bypass -File "$ROOT_DIR/scripts/build-windows.ps1" \
            -Configuration Release \
            -BuildDir "build-x64-windows-msvc+static-release" \
            -ArtifactDir "$ARTIFACTS_DIR" \
            -PackageDir "$ROOT_DIR/package"
    fi

    WINDOWS_ZIP="$ARTIFACTS_DIR/dexai-windows-x86_64.zip"
    if [ -f "$WINDOWS_ZIP" ]; then
        echo "Created Windows artifact: $WINDOWS_ZIP"
    else
        echo "Windows artifact not found after PowerShell build: $WINDOWS_ZIP"
    fi
elif ! command -v docker >/dev/null 2>&1; then
    echo "Neither PowerShell nor docker is available; skipping Windows artifact build"
else
    echo "Building Windows x64 static binary in Docker..."
    docker build -f "$ROOT_DIR/Dockerfile.windows" -t "$IMAGE_NAME" "$ROOT_DIR"

    CONTAINER_ID=$(docker create "$IMAGE_NAME")
    docker cp "$CONTAINER_ID:/workspace/out/." "$OUT_DIR/"
    docker rm -f "$CONTAINER_ID" >/dev/null

    BINARY_PATH="$OUT_DIR/dexai.exe"
    if [ -f "$BINARY_PATH" ]; then
        NEEDLE_DLL="$ROOT_DIR/needle/windows-x86_64/libneedle.dll"
        if [ -z "$NEEDLE_DLL" ]; then
            echo "libneedle.dll path is not configured"
            exit 1
        fi
        if [ ! -f "$NEEDLE_DLL" ]; then
            echo "libneedle.dll is required but was not found: $NEEDLE_DLL"
            exit 1
        fi
        cp "$NEEDLE_DLL" "$OUT_DIR/libneedle.dll"

        python3 - "$OUT_DIR" "$ARTIFACTS_DIR/dexai-windows-x86_64.zip" <<'PY'
import os
import sys
import zipfile

out_dir = sys.argv[1]
zip_path = sys.argv[2]
items = [
    os.path.join(out_dir, 'dexai.exe'),
]
items.extend(os.path.join(out_dir, name) for name in os.listdir(out_dir) if name.lower().endswith('.dll'))
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    for item in items:
        if os.path.exists(item):
            zf.write(item, arcname=os.path.basename(item))
PY
        echo "Created Windows artifact: $ARTIFACTS_DIR/dexai-windows-x86_64.zip"
    else
        echo "Windows executable not found in Docker output: $BINARY_PATH"
        echo "Skipping Windows archive creation"
    fi
fi

CURRENT_TAG=$(git describe --tags --exact-match HEAD 2>/dev/null || echo "")

if [ -n "$CURRENT_TAG" ]; then
    echo "Detected tag: $CURRENT_TAG"
    RELEASE_DIR="dexai-${CURRENT_TAG}"
    rm -rf "$RELEASE_DIR"
    mkdir -p "$RELEASE_DIR"

    cp "$ARTIFACTS_DIR/dexai-windows-x86_64.zip" "$RELEASE_DIR/" 2>/dev/null || true
    cp README.md "$RELEASE_DIR/" 2>/dev/null || true
    cp LICENSE "$RELEASE_DIR/" 2>/dev/null || true

    tar -czf "${RELEASE_DIR}.tar.gz" "$RELEASE_DIR"

    if command -v curl >/dev/null 2>&1; then
        echo "Creating GitBucket release for ${CURRENT_TAG}..."

        RELEASE_DESCRIPTION="Release created from tag ${CURRENT_TAG}

## Included artifacts
- dexai-windows-x86_64.zip
- README.md
- LICENSE

## Notes
This release contains the Windows x64 static build."

        RESPONSE=$(curl -sS -X POST "http://localhost:9090/api/projects/root/dexai.cpp/releases" \
            -H "Content-Type: application/json" \
            -d "{
                \"tag_name\": \"${CURRENT_TAG}\",
                \"name\": \"DexAI ${CURRENT_TAG}\",
                \"description\": \"${RELEASE_DESCRIPTION}\",
                \"draft\": false,
                \"prerelease\": false
            }" 2>&1 || true)

        if printf '%s' "$RESPONSE" | grep -qiE 'error|Error'; then
            echo "GitBucket release API reported an error: $RESPONSE"
            echo "Continuing anyway..."
        else
            echo "GitBucket release created successfully"
            echo "URL: http://localhost:9090/root/dexai.cpp/releases/${CURRENT_TAG}"
        fi
    else
        echo "curl not found; skipped GitBucket release creation"
    fi

    echo "Release archive ready: ${RELEASE_DIR}.tar.gz"
    ls -lh "${RELEASE_DIR}.tar.gz"
else
    echo "No git tag detected; the Windows package was created locally only."
    echo "To create a tagged release, push a tag like:"
    echo "  git tag v1.0.0"
    echo "  git push origin v1.0.0"
fi

echo "=== Build Complete ==="
echo "Windows package: $ARTIFACTS_DIR/dexai-windows-x86_64.zip"
