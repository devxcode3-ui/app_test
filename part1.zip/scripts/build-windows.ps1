

param(
    [string]$Configuration = "Release",
    [string]$BuildDir = "build-x64-windows-msvc+static-release",
    [string]$ArtifactDir = "artifacts",
    [string]$PackageDir = "package",
    [switch]$DisableUI,
    [switch]$SkipBuild,
    [switch]$DryRun,
    [switch]$StartUI,
    [string]$ModelPath = "D:\models\LFM2.5-VL-1.6B-UD-Q4_K_XL.gguf",
    [string]$ServerHost = "127.0.0.1",
    [int]$ServerPort = 18093,
    [int]$ContextSize = 10000,
    [string]$NeedleLib = ""
)

$ErrorActionPreference = "Stop"

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $repoRoot

$buildRoot = [System.IO.Path]::GetFullPath((Join-Path $repoRoot $BuildDir))
$artifactRoot = [System.IO.Path]::GetFullPath((Join-Path $repoRoot $ArtifactDir))
$packageRoot = [System.IO.Path]::GetFullPath((Join-Path $repoRoot $PackageDir))

function Find-Toolchain {
    $pf86 = ${env:ProgramFiles(x86)}
    $pf = ${env:ProgramFiles}

    $candidates = @(
        "$pf86\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
        "$pf\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
        "$pf86\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
        "$pf\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat",
        "$pf86\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat",
        "$pf\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat",
        "$pf86\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat",
        "$pf\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat"
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path $candidate)) {
            return $candidate
        }
    }

    throw "Unable to find vcvars64.bat for a Visual Studio x64 toolchain."
}

function Find-VcpkgRoot {
    $pf86 = ${env:ProgramFiles(x86)}
    $pf = ${env:ProgramFiles}
    $userHome = ${env:USERPROFILE}

    $candidates = @(
        $env:VCPKG_ROOT,
        "D:\vcpkg",
        "$userHome\vcpkg",
        "$pf\vcpkg",
        "$pf86\vcpkg",
        "C:\src\vcpkg"
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path (Join-Path $candidate "scripts\buildsystems\vcpkg.cmake"))) {
            return $candidate
        }
    }

    throw "Unable to find a vcpkg installation with scripts/buildsystems/vcpkg.cmake."
}

$vcVarsBat = Find-Toolchain
$vcpkgRoot = Find-VcpkgRoot
$vcpkgToolchain = Join-Path $vcpkgRoot "scripts\buildsystems\vcpkg.cmake"

Write-Host "Using Visual Studio env: $vcVarsBat"
Write-Host "Using vcpkg toolchain: $vcpkgToolchain"

$uiFlag = if ($DisableUI) { "OFF" } else { "ON" }

$cmakeArgs = @(
    "-S", ".",
    "-B", $BuildDir,
    "-G", "Ninja",
    "-DCMAKE_BUILD_TYPE=$Configuration",
    "-DLLAMA_BUILD_SERVER=ON",
    "-DLLAMA_BUILD_UI=$uiFlag",
    "-DLLAMA_USE_PREBUILT_UI=OFF",
    "-DLLAMA_BUILD_EXAMPLES=OFF",
    "-DLLAMA_BUILD_TESTS=OFF",
    "-DLLAMA_BUILD_APP=OFF",
    "-DDEXAI_BUILD_EXTRA_TOOLS=OFF",
    "-DBUILD_SHARED_LIBS=OFF",
    "-DGGML_CCACHE=OFF",
    "-DCMAKE_TOOLCHAIN_FILE=$vcpkgToolchain",
    "-DVCPKG_TARGET_TRIPLET=x64-windows"
)

$buildCommand = @(
    "call `"$vcVarsBat`"",
    "&& cd /d `"$repoRoot`"",
    "&& if exist `"$buildRoot`" rmdir /s /q `"$buildRoot`"",
    "&& cmake"
) + ($cmakeArgs | ForEach-Object { "`"$_`"" }) + @(
    "&& cmake --build `"$buildRoot`" --config $Configuration --target llama-server --parallel"
) -join " "

if ($DryRun) {
    Write-Host "Dry run:"
    Write-Host $buildCommand
    exit 0
}

if (-not $SkipBuild) {
    Write-Host "Configuring and building dexai for Windows..."
    cmd /c $buildCommand
}

$binaryPath = Join-Path $buildRoot "bin\$Configuration\dexai.exe"
if (-not (Test-Path $binaryPath)) {
    $binaryPath = Join-Path $buildRoot "bin\dexai.exe"
}

if (-not (Test-Path $binaryPath)) {
    throw "Expected dexai.exe was not produced at $binaryPath"
}

if ($StartUI) {
    $serverArgs = @(
        "--host", $ServerHost,
        "--port", [string]$ServerPort,
        "--ctx-size", [string]$ContextSize,
        "--model", $ModelPath
    )

    if ($NeedleLib -and (Test-Path $NeedleLib)) {
        $serverArgs += @("--agent-needle-lib", $NeedleLib)
    }

    $serverUrl = "http://${ServerHost}:${ServerPort}/"
    Write-Host "Starting dexai UI test server: $binaryPath"
    Write-Host "URL: $serverUrl"
    Start-Process -FilePath $binaryPath -ArgumentList $serverArgs
    Start-Process $serverUrl
}

New-Item -ItemType Directory -Force -Path $artifactRoot, $packageRoot, (Join-Path $packageRoot "dexai-windows-x86_64\bin"), (Join-Path $packageRoot "dexai-windows-x86_64\lib") | Out-Null
Copy-Item $binaryPath (Join-Path $packageRoot "dexai-windows-x86_64\bin\") -Force

$needleDll = Join-Path $repoRoot "needle\libneedle.dll"
if (Test-Path $needleDll) {
    Copy-Item $needleDll (Join-Path $packageRoot "dexai-windows-x86_64\lib\") -Force
}

$archivePath = Join-Path $artifactRoot "dexai-windows-x86_64.zip"
if (Test-Path $archivePath) {
    Remove-Item $archivePath -Force
}

Compress-Archive -Path (Join-Path $packageRoot "dexai-windows-x86_64") -DestinationPath $archivePath -Force

Write-Host "Windows artifact created: $archivePath"
