import base64
import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import whatsapp


class WhatsAppTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        root = Path(self.temp_dir.name)
        self.integration = whatsapp.WhatsAppIntegration({
            "EVOLUTION_API_URL": "http://127.0.0.1:8080",
            "AUTHENTICATION_API_KEY": "secret",
            "EVOLUTION_INSTANCE": "business",
            "LLAMA_AGENT_ID": "invoice-agent",
            "WHATSAPP_ALLOWED_SENDERS": "917873047969@s.whatsapp.net",
        }, root / "inbox.jsonl", root / "media")

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_parse_ignores_outbound_messages(self):
        self.assertIsNone(whatsapp.parse_message({"data": {"key": {"fromMe": True}}}))
        self.assertIsNone(whatsapp.parse_message({"data": {"key": "invalid"}}))

    def test_rejects_sender_not_on_allowlist(self):
        result = self.integration.receive_async({"data": {"key": {"id": "blocked", "remoteJid": "15550000000@s.whatsapp.net"}, "message": {"conversation": "process"}}})
        self.assertEqual(result["reason"], "sender_not_allowed")
        self.assertEqual(self.integration.read_messages(), [])

    @patch("whatsapp.post_json")
    def test_receive_sends_prompt_to_stored_agent(self, post):
        post.return_value = {"status": "completed", "summary": "Invoice processed"}
        result = self.integration.receive({"data": {"key": {"id": "m1", "remoteJid": "917873047969@s.whatsapp.net"}, "pushName": "Test User", "message": {"conversation": "process the invoice"}}})
        self.assertEqual(result["summary"], "Invoice processed")
        post.assert_called_once()
        self.assertIn("process the invoice", post.call_args.args[1]["prompt"])
        self.assertEqual(self.integration.read_messages()[0]["id"], "m1")
        self.assertEqual(self.integration.user_profiles()[0]["display_name"], "Test User")

    @patch("whatsapp.post_json")
    def test_receive_downloads_media_when_webhook_has_no_base64(self, post):
        post.return_value = {"status": "completed", "summary": "Invoice processed"}
        self.integration.client.media_base64 = Mock(return_value=base64.b64encode(b"pdf-data").decode())
        payload = {"data": {"key": {"id": "m-media", "remoteJid": "917873047969@s.whatsapp.net"}, "message": {"documentMessage": {"fileName": "invoice.pdf", "mimetype": "application/pdf"}}}}

        self.integration.receive(payload)

        media_path = Path(self.temp_dir.name) / "media" / "m-media.pdf"
        self.assertEqual(media_path.read_bytes(), b"pdf-data")
        self.integration.client.media_base64.assert_called_once()
        self.assertIn(str(media_path), post.call_args.args[1]["prompt"])

    @patch("whatsapp.post_json")
    def test_correlates_caption_event_with_media_event(self, post):
        post.return_value = {"status": "completed"}
        self.integration.event_window = 0.1
        self.integration.client.media_base64 = Mock(return_value=base64.b64encode(b"pdf-data").decode())
        media = {"data": {"key": {"id": "media", "remoteJid": "917873047969@s.whatsapp.net"}, "message": {"documentMessage": {"fileName": "invoice.pdf", "mimetype": "application/pdf"}}}}
        caption = {"data": {"key": {"id": "caption", "remoteJid": "917873047969@s.whatsapp.net"}, "message": {"conversation": "process the invoice"}}}

        self.integration.receive_async(media)
        self.integration.receive_async(caption)
        time.sleep(0.5)

        post.assert_called_once()
        prompt = post.call_args.args[1]["prompt"]
        self.assertIn("process the invoice", prompt)
        self.assertIn("media.pdf", prompt)
        messages = self.integration.read_messages(sender="917873047969@s.whatsapp.net")
        self.assertEqual(messages[0]["correlation_id"], messages[1]["correlation_id"])
        self.assertEqual(messages[0]["message_id"], "media")

    @patch("whatsapp.urlopen")
    def test_send_media_encodes_file(self, urlopen_mock):
        urlopen_mock.return_value.__enter__.return_value = Mock(read=lambda: json.dumps({"key": {"id": "m2"}}).encode())
        path = Path(self.temp_dir.name) / "invoice.pdf"
        path.write_bytes(b"pdf")
        self.assertEqual(self.integration.client.send_media("+15551234567", str(path)), "m2")
        body = json.loads(urlopen_mock.call_args.args[0].data)
        self.assertEqual(body["media"], base64.b64encode(b"pdf").decode())
        self.assertEqual(body["fileName"], "invoice.pdf")
        self.assertEqual(body["mediatype"], "document")

if __name__ == "__main__":
    unittest.main()