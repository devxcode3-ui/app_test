from urllib.parse import quote


DEFAULT_PRODUCT_PATH = "/products/{id}"


def format_product_message(products: list[dict], store_url: str = "", product_path: str = DEFAULT_PRODUCT_PATH) -> str:
    lines = [f"🛍️ *Store Products* ({len(products)})", ""]
    for index, product in enumerate(products, 1):
        name = product.get("name", "Unknown product")
        price = int(product.get("price_cents", 0)) / 100
        stock = product.get("stock_quantity", 0)
        lines.extend((
            f"{index}. 🛒 *{name}*",
            f"   💰 ${price:,.2f}  |  📦 {stock} in stock",
        ))
        if store_url and product.get("id"):
            path = product_path.format(id=quote(str(product["id"]), safe=""))
            lines.append(f"   🔗 {store_url.rstrip('/')}/{path.lstrip('/')}")
        lines.append("")
    return "\n".join(lines).rstrip()
