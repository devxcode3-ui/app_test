# WhatsApp notification integration

This integration connects Evolution API to a llama.cpp stored agent.

Set these values in `local.env` or the process environment:

```sh
EVOLUTION_API_URL=http://127.0.0.1:8080
AUTHENTICATION_API_KEY=...
EVOLUTION_INSTANCE=business
LLAMA_SERVER_URL=http://127.0.0.1:8081
LLAMA_AGENT_ID=invoice-agent
WHATSAPP_WEBHOOK_URL=http://127.0.0.1:8765/webhook
```

Start the inbound bridge:

```sh
python3 whatsapp.py serve --env-file /path/to/local.env
```

The same program can run as an MCP server for `llama-server`:

```json
{"mcpServers":{"whatsapp":{"command":"python3","args":["/path/to/tools/apps/notification/whatsapp.py","mcp","--env-file","/path/to/local.env"]}}}
```

The bridge stores inbound messages in the local SQLite database `data/whatsapp.db`. Each row has a `message_id` and `correlation_id`; related PDF and caption events from the same sender are grouped for up to 120 seconds. Media is saved in `data/whatsapp-media`, and the bridge calls `POST /v1/agents/{LLAMA_AGENT_ID}/run` with `allow_write: true`. Keep the webhook and MCP process on a trusted host.

Run tests with:

```sh
python3 -m unittest -v test_whatsapp.py
```