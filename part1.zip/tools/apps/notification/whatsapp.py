#!/usr/bin/env python3

import argparse
import base64
import json
import mimetypes
import os
import re
import sqlite3
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen

from ws_text_formatter import DEFAULT_PRODUCT_PATH, format_product_message

MAX_TEXT_BYTES = 4096
DEFAULT_ALLOWED_SENDER = "917873047969@s.whatsapp.net"


def normalize_number(value: str) -> str:
    number = value.strip().removeprefix("+")
    if not re.fullmatch(r"[0-9]{7,20}", number):
        raise ValueError("number must contain 7 to 20 digits, with an optional leading +")
    return number


def load_env(path: Path) -> dict[str, str]:
    values = {}
    if not path.exists():
        return values
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if line and not line.startswith("#"):
            key, separator, value = line.partition("=")
            if not separator:
                raise ValueError(f"invalid environment line in {path.name}")
            values[key] = value
    return values


class EvolutionClient:
    def __init__(self, base_url: str, api_key: str, instance: str, origin: str):
        parsed = urlparse(base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.path not in {"", "/"}:
            raise ValueError("Evolution API URL must be an HTTP origin without a path")
        if not api_key or not instance:
            raise ValueError("Evolution API key and instance are required")
        self.base_url = base_url.rstrip("/")
        self.instance = instance
        self.headers = {"Content-Type": "application/json", "Origin": origin, "apikey": api_key}

    def request(self, method: str, path: str, body: dict | None = None) -> dict:
        data = json.dumps(body, separators=(",", ":")).encode() if body is not None else None
        request = Request(self.base_url + path, data=data, headers=self.headers, method=method)
        try:
            with urlopen(request, timeout=30) as response:
                result = json.load(response)
        except HTTPError as error:
            raise RuntimeError(f"Evolution API returned HTTP {error.code}") from None
        except URLError:
            raise RuntimeError("Evolution API is unavailable") from None
        if not isinstance(result, dict):
            raise RuntimeError("Evolution API returned an invalid response")
        return result

    def send_text(self, number: str, text: str) -> str:
        if not text or len(text.encode()) > MAX_TEXT_BYTES:
            raise ValueError("text must contain 1 to 4096 bytes")
        result = self.request("POST", f"/message/sendText/{quote(self.instance, safe='')}", {"number": normalize_number(number), "text": text})
        return self._message_id(result)

    def send_media(self, number: str, path: str, caption: str = "") -> str:
        file_path = Path(path)
        if not file_path.is_file():
            raise ValueError("media file does not exist")
        mimetype = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        media_kind = mimetype.split("/", 1)[0]
        if media_kind == "application":
            media_kind = "document"
        result = self.request("POST", f"/message/sendMedia/{quote(self.instance, safe='')}", {
            "number": normalize_number(number),
            "mediatype": media_kind,
            "mimetype": mimetype,
            "caption": caption,
            "media": base64.b64encode(file_path.read_bytes()).decode(),
            "fileName": file_path.name,
        })
        return self._message_id(result)

    def register_webhook(self, url: str) -> dict:
        return self.request("POST", f"/webhook/set/{quote(self.instance, safe='')}", {"webhook": {
            "enabled": True,
            "url": url,
            "webhookByEvents": False,
            "webhookBase64": True,
            "events": ["MESSAGES_UPSERT"],
        }})

    def media_base64(self, key: dict, message: dict) -> str:
        result = self.request(
            "POST",
            f"/chat/getBase64FromMediaMessage/{quote(self.instance, safe='')}",
            {"message": {"key": key, "message": message}, "convertToMp4": False},
        )
        encoded = result.get("base64")
        if not isinstance(encoded, str) or not encoded:
            raise RuntimeError("Evolution API did not return media data")
        return encoded

    @staticmethod
    def _message_id(result: dict) -> str:
        message_id = result.get("key", {}).get("id")
        if not isinstance(message_id, str) or not message_id:
            raise RuntimeError("Evolution API did not return a message ID")
        return message_id


def parse_message(payload: dict) -> dict | None:
    data = payload.get("data")
    items = data if isinstance(data, list) else [data]
    for item in items:
        if not isinstance(item, dict):
            continue
        key = item.get("key", {})
        message = item.get("message")
        sender = key.get("remoteJid") if isinstance(key, dict) else None
        if not isinstance(key, dict) or key.get("fromMe") or not isinstance(sender, str) or not isinstance(message, dict):
            continue
        text = message.get("conversation", "")
        if not isinstance(text, str):
            text = message.get("extendedTextMessage", {}).get("text", "")
        media = next((message.get(name) for name in ("imageMessage", "documentMessage", "videoMessage") if isinstance(message.get(name), dict)), None)
        if media and not text:
            text = media.get("caption", "")
        return {"message_id": key.get("id", str(uuid.uuid4())), "sender": sender, "push_name": item.get("pushName", ""), "text": text, "key": key, "message": message}
    return None


class WhatsAppIntegration:
    def __init__(self, env: dict[str, str], inbox: Path, media_dir: Path):
        self.client = EvolutionClient(
            env.get("EVOLUTION_API_URL", "http://127.0.0.1:8080"),
            env.get("AUTHENTICATION_API_KEY", ""),
            env.get("EVOLUTION_INSTANCE", "business"),
            env.get("EVOLUTION_ORIGIN", "http://127.0.0.1:3000"),
        )
        self.llama_url = env.get("LLAMA_SERVER_URL", "http://127.0.0.1:8081").rstrip("/")
        self.agent_id = env.get("LLAMA_AGENT_ID", "")
        self.llama_api_key = env.get("LLAMA_API_KEY", "")
        self.webhook_url = env.get("WHATSAPP_WEBHOOK_URL", "http://127.0.0.1:8765/webhook")
        self.store_url = env.get("STORE_PUBLIC_URL", "")
        self.product_path = env.get("STORE_PRODUCT_PATH", DEFAULT_PRODUCT_PATH)
        self.inbox = inbox.with_suffix(".db") if inbox.suffix == ".jsonl" else inbox
        self.media_dir = media_dir
        self.lock = threading.Lock()
        self.pending: dict[str, list[dict]] = {}
        self.pending_timers: dict[str, threading.Timer] = {}
        self.event_window = float(env.get("WHATSAPP_EVENT_WINDOW_SECONDS", "120"))
        configured_senders = env.get("WHATSAPP_ALLOWED_SENDERS", "")
        self.allowed_senders = {sender.strip() for sender in configured_senders.split(",") if sender.strip()} or {DEFAULT_ALLOWED_SENDER}
        self.inbox.parent.mkdir(parents=True, exist_ok=True)
        media_dir.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.inbox) as db:
            db.execute("CREATE TABLE IF NOT EXISTS user_profiles (sender TEXT PRIMARY KEY, display_name TEXT NOT NULL, phone TEXT NOT NULL, last_message_id TEXT NOT NULL, last_message_at REAL NOT NULL, profile_json TEXT NOT NULL, is_allowed INTEGER NOT NULL DEFAULT 0)")
            columns = {row[1] for row in db.execute("PRAGMA table_info(user_profiles)")}
            if "is_allowed" not in columns:
                db.execute("ALTER TABLE user_profiles ADD COLUMN is_allowed INTEGER NOT NULL DEFAULT 0")
            db.execute("CREATE TABLE IF NOT EXISTS whatsapp_messages (message_id TEXT PRIMARY KEY, correlation_id TEXT NOT NULL, sender TEXT NOT NULL, text TEXT NOT NULL, message_json TEXT NOT NULL, key_json TEXT NOT NULL, media_path TEXT, received_at REAL NOT NULL)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_whatsapp_context ON whatsapp_messages (sender, correlation_id, received_at)")
            db.commit()

    def receive(self, payload: dict) -> dict:
        record = parse_message(payload)
        if record is None:
            return {"status": "ignored"}
        if not self.is_allowed(record["sender"]):
            return {"status": "ignored", "reason": "sender_not_allowed"}
        correlation_id = self._store_record(record)
        return self._process_correlation(record["sender"], correlation_id)

    def _store_record(self, record: dict) -> str:
        now = time.time()
        with self.lock, sqlite3.connect(self.inbox) as db:
            media = self._media(record)
            correlation_id = None
            if media:
                correlation_id = str(uuid.uuid4())
            else:
                rows = db.execute(
                    "SELECT correlation_id, message_json FROM whatsapp_messages WHERE sender = ? AND received_at >= ? ORDER BY received_at DESC",
                    (record["sender"], now - self.event_window),
                ).fetchall()
                row = next((row for row in rows if self._message_has_media(json.loads(row[1]))), None)
                correlation_id = row[0] if row else str(uuid.uuid4())
            db.execute(
                "INSERT OR REPLACE INTO whatsapp_messages (message_id, correlation_id, sender, text, message_json, key_json, received_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (record["message_id"], correlation_id, record["sender"], record["text"], json.dumps(record["message"], separators=(",", ":")), json.dumps(record["key"], separators=(",", ":")), now),
            )
            db.execute(
                "INSERT INTO user_profiles (sender, display_name, phone, last_message_id, last_message_at, profile_json, is_allowed) VALUES (?, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(sender) DO UPDATE SET display_name = excluded.display_name, phone = excluded.phone, last_message_id = excluded.last_message_id, last_message_at = excluded.last_message_at, profile_json = excluded.profile_json, is_allowed = excluded.is_allowed",
                (record["sender"], record.get("push_name", ""), record["sender"].split("@", 1)[0], record["message_id"], now, json.dumps({"key": record["key"]}, separators=(",", ":")), int(self.is_allowed(record["sender"]))),
            )
            db.commit()
        return correlation_id

    def _process_correlation(self, sender: str, correlation_id: str) -> dict:
        records = self.context(sender, correlation_id)
        merged = records[-1].copy()
        media_record = next((record for record in reversed(records) if self._media(record)), None)
        if media_record:
            merged = media_record.copy()
        merged["text"] = "\n".join(dict.fromkeys(record["text"].strip() for record in records if record["text"].strip()))
        media_path = self._save_media(merged)
        if media_path:
            with sqlite3.connect(self.inbox) as db:
                db.execute("UPDATE whatsapp_messages SET media_path = ? WHERE message_id = ?", (media_path, merged["message_id"]))
                db.commit()
        prompt = merged["text"] or "(attachment only)"
        if media_path:
            prompt += f"\nAttachment path: {media_path}"
        if not self.agent_id:
            raise RuntimeError("LLAMA_AGENT_ID is required")
        headers = {"Authorization": f"Bearer {self.llama_api_key}"} if self.llama_api_key else {}
        result = post_json(f"{self.llama_url}/v1/agents/{quote(self.agent_id, safe='')}/run", {"prompt": prompt, "allow_write": True}, headers)
        reply = result.get("summary", "")
        steps = result.get("steps", [])
        if steps:
            raw = steps[-1].get("result", {}).get("plain_text_response", "")
            try:
                products = json.loads(raw)
            except (TypeError, json.JSONDecodeError):
                products = None
            if isinstance(products, list):
                reply = format_product_message(products, self.store_url, self.product_path)
        if reply:
            result["whatsapp_message_id"] = self.client.send_text(sender.split("@", 1)[0], reply)
        return result

    def receive_async(self, payload: dict) -> dict:
        record = parse_message(payload)
        if record is None:
            return {"status": "ignored"}
        if not self.is_allowed(record["sender"]):
            return {"status": "ignored", "reason": "sender_not_allowed"}
        self._store_record(record)
        correlation_id = self._correlation_for(record)
        with self.lock:
            pending = self.pending.setdefault(record["sender"], [])
            pending.append((record, correlation_id))
            timer = self.pending_timers.pop(record["sender"], None)
            if timer:
                timer.cancel()
            timer = threading.Timer(self.event_window, self._flush_pending, args=(record["sender"],))
            timer.daemon = True
            self.pending_timers[record["sender"]] = timer
            timer.start()
        return {"status": "accepted"}

    def _flush_pending(self, sender: str) -> None:
        with self.lock:
            pending = self.pending.pop(sender, [])
            self.pending_timers.pop(sender, None)
        if not pending:
            return
        records = [item[0] for item in pending]
        correlation_id = next((item[1] for item in reversed(pending) if self._media(item[0])), pending[-1][1])
        with sqlite3.connect(self.inbox) as db:
            for record in records:
                db.execute("UPDATE whatsapp_messages SET correlation_id = ? WHERE message_id = ?", (correlation_id, record["message_id"]))
            db.commit()
        try:
            self._process_correlation(sender, correlation_id)
        except Exception as error:
            print(f"WhatsApp event processing failed: {error}", file=sys.stderr, flush=True)

    @staticmethod
    def _media(record: dict) -> dict | None:
        return next((record["message"].get(name) for name in ("imageMessage", "documentMessage", "videoMessage") if isinstance(record["message"].get(name), dict)), None)

    @staticmethod
    def _message_has_media(message: dict) -> bool:
        return any(isinstance(message.get(name), dict) for name in ("imageMessage", "documentMessage", "videoMessage"))

    def is_allowed(self, sender: str) -> bool:
        return sender in self.allowed_senders

    def user_profiles(self) -> list[dict]:
        with sqlite3.connect(self.inbox) as db:
            db.row_factory = sqlite3.Row
            return [dict(row) for row in db.execute("SELECT * FROM user_profiles ORDER BY last_message_at DESC").fetchall()]

    def read_messages(self, limit: int = 20, sender: str = "") -> list[dict]:
        if not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100")
        with sqlite3.connect(self.inbox) as db:
            db.row_factory = sqlite3.Row
            query = "SELECT * FROM whatsapp_messages"
            params: list[object] = []
            if sender:
                query += " WHERE sender = ?"
                params.append(sender)
            rows = db.execute(query + " ORDER BY received_at DESC LIMIT ?", (*params, limit)).fetchall()
        return [self._row_to_record(row) for row in reversed(rows)]

    def context(self, sender: str, correlation_id: str) -> list[dict]:
        with sqlite3.connect(self.inbox) as db:
            db.row_factory = sqlite3.Row
            rows = db.execute("SELECT * FROM whatsapp_messages WHERE sender = ? AND correlation_id = ? ORDER BY received_at, rowid", (sender, correlation_id)).fetchall()
        return [self._row_to_record(row) for row in rows]

    def _correlation_for(self, record: dict) -> str:
        with sqlite3.connect(self.inbox) as db:
            row = db.execute("SELECT correlation_id FROM whatsapp_messages WHERE message_id = ?", (record["message_id"],)).fetchone()
        return row[0]

    @staticmethod
    def _row_to_record(row: sqlite3.Row) -> dict:
        record = {"message_id": row["message_id"], "id": row["message_id"], "correlation_id": row["correlation_id"], "sender": row["sender"], "text": row["text"], "message": json.loads(row["message_json"]), "key": json.loads(row["key_json"])}
        if row["media_path"]:
            record["media_path"] = row["media_path"]
        return record

    def _save_media(self, record: dict) -> str | None:
        message = record["message"]
        media = next((message.get(key) for key in ("imageMessage", "documentMessage", "videoMessage") if isinstance(message.get(key), dict)), None)
        encoded = media.get("base64") if media else None
        if not isinstance(encoded, str):
            if not media:
                return None
            encoded = self.client.media_base64(record["key"], message)
        suffix = Path(media.get("fileName", "")).suffix or mimetypes.guess_extension(media.get("mimetype", "")) or ".bin"
        path = self.media_dir / f"{record['id']}{suffix}"
        try:
            path.write_bytes(base64.b64decode(encoded, validate=True))
        except (ValueError, TypeError):
            raise RuntimeError("Evolution API returned invalid media data") from None
        return str(path)


def post_json(url: str, body: dict, headers: dict[str, str] | None = None) -> dict:
    request = Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json", **(headers or {})}, method="POST")
    try:
        with urlopen(request, timeout=300) as response:
            result = json.load(response)
    except (HTTPError, URLError) as error:
        raise RuntimeError(f"llama-server request failed: {error}") from None
    if not isinstance(result, dict):
        raise RuntimeError("llama-server returned an invalid response")
    return result


def tools() -> list[dict]:
    return [
        {"name": "whatsapp_read_messages", "description": "Read recent inbound WhatsApp messages.", "inputSchema": {"type": "object", "properties": {"limit": {"type": "integer"}, "sender": {"type": "string"}}}},
        {"name": "whatsapp_send_text", "description": "Send a WhatsApp text message.", "inputSchema": {"type": "object", "properties": {"number": {"type": "string"}, "text": {"type": "string"}}, "required": ["number", "text"]}},
        {"name": "whatsapp_send_media", "description": "Send a file on WhatsApp.", "inputSchema": {"type": "object", "properties": {"number": {"type": "string"}, "media_path": {"type": "string"}, "caption": {"type": "string"}}, "required": ["number", "media_path"]}},
    ]


def run_mcp(integration: WhatsAppIntegration) -> int:
    for line in sys.stdin:
        request = json.loads(line)
        method = request.get("method")
        if method == "initialize":
            result = {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}, "serverInfo": {"name": "whatsapp", "version": "1.0"}}
        elif method == "notifications/initialized":
            continue
        elif method == "tools/list":
            result = {"tools": tools()}
        elif method == "tools/call":
            params = request.get("params", {})
            args = params.get("arguments", {})
            name = params.get("name")
            if name == "whatsapp_read_messages":
                value = integration.read_messages(args.get("limit", 20), args.get("sender", ""))
            elif name == "whatsapp_send_text":
                value = {"message_id": integration.client.send_text(args["number"], args["text"])}
            elif name == "whatsapp_send_media":
                value = {"message_id": integration.client.send_media(args["number"], args["media_path"], args.get("caption", ""))}
            else:
                raise ValueError("unknown WhatsApp tool")
            result = {"content": [{"type": "text", "text": json.dumps(value)}]}
        else:
            continue
        print(json.dumps({"jsonrpc": "2.0", "id": request.get("id"), "result": result}), flush=True)
    return 0


class WebhookHandler(BaseHTTPRequestHandler):
    integration: WhatsAppIntegration

    def _process_async(self, payload: dict) -> None:
        try:
            self.integration.receive_async(payload)
        except Exception as error:
            print(f"WhatsApp event processing failed: {error}", file=sys.stderr, flush=True)

    def do_POST(self) -> None:
        if self.path != "/webhook":
            self.send_error(404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length))
            threading.Thread(target=self._process_async, args=(payload,), daemon=True).start()
            body = b'{"status":"accepted"}'
            self.send_response(202)
        except (ValueError, RuntimeError, json.JSONDecodeError, OSError) as error:
            body = json.dumps({"error": str(error)}).encode()
            self.send_response(400)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            pass

    def log_message(self, *_args) -> None:
        return


def main() -> int:
    parser = argparse.ArgumentParser(description="WhatsApp Evolution API integration for llama.cpp agents.")
    parser.add_argument("command", choices=["serve", "mcp", "register-webhook"])
    parser.add_argument("--env-file", type=Path, default=Path(__file__).with_name("local.env"))
    parser.add_argument("--inbox", type=Path, default=Path(__file__).with_name("data") / "whatsapp.db")
    parser.add_argument("--media-dir", type=Path, default=Path(__file__).with_name("data") / "whatsapp-media")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    env = {**load_env(args.env_file), **os.environ}
    integration = WhatsAppIntegration(env, args.inbox, args.media_dir)
    if args.command == "mcp":
        return run_mcp(integration)
    if args.command == "register-webhook":
        integration.client.register_webhook(integration.webhook_url)
        print(json.dumps({"status": "registered", "url": integration.webhook_url}))
        return 0
    WebhookHandler.integration = integration
    integration.client.register_webhook(integration.webhook_url)
    ThreadingHTTPServer((args.host, args.port), WebhookHandler).serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())