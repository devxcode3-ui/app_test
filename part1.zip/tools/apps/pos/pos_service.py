#!/usr/bin/env python3
"""Local POS persistence, reporting API, and MCP adapter."""

import argparse
import datetime as dt
import hmac
import json
import mimetypes
import os
import signal
import sqlite3
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen

MAX_BODY_BYTES = 1024 * 1024
MAX_ITEMS_PER_SALE = 100
MAX_REPORT_LIMIT = 100


def utc_text(value: dt.datetime) -> str:
    if value.tzinfo is None:
        raise ValueError("datetime must include a timezone")
    return value.astimezone(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def parse_datetime(value: str) -> dt.datetime:
    parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("date must include a timezone")
    return parsed.astimezone(dt.timezone.utc)


def period_bounds(period: str, now: dt.datetime | None = None) -> tuple[str, str]:
    local_now = now.astimezone() if now else dt.datetime.now().astimezone()
    if period == "today":
        start = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + dt.timedelta(days=1)
    elif period == "last_30_days":
        end = local_now
        start = end - dt.timedelta(days=30)
    elif period == "last_month":
        this_month = local_now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end = this_month
        previous_day = this_month - dt.timedelta(days=1)
        start = previous_day.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    else:
        raise ValueError("period must be today, last_30_days, or last_month")
    return utc_text(start), utc_text(end)


def resolve_bounds(arguments: dict) -> tuple[str, str]:
    period = arguments.get("period", "today")
    if period == "custom":
        start = utc_text(parse_datetime(str(arguments.get("from", ""))))
        end = utc_text(parse_datetime(str(arguments.get("to", ""))))
    else:
        start, end = period_bounds(str(period))
    if start >= end:
        raise ValueError("from must be before to")
    return start, end


def agent_config():
    config_path = Path(os.environ.get("APP_RELAY_AGENT_CONFIG", "/home/ubuntu/llama_cpp/app_relay/agent.json"))
    if not config_path.exists():
        return {}
    return json.loads(config_path.read_text())


def relay_request(method, path, payload=None):
    base_url = os.environ.get("POS_RELAY_API", "http://127.0.0.1:18080").rstrip("/")
    config = agent_config()
    user_id = os.environ.get("POS_RELAY_USER_ID", config.get("user_id", ""))
    token = os.environ.get("POS_RELAY_TOKEN", config.get("token", ""))
    if not user_id or not token:
        raise ValueError("POS_RELAY_USER_ID and POS_RELAY_TOKEN are required")
    body = None if payload is None else json.dumps(payload).encode()
    request = Request(
        base_url + path,
        data=body,
        method=method,
        headers={
            "Authorization": f"Bearer {user_id}:{token}",
            "Content-Type": "application/json",
        },
    )
    with urlopen(request, timeout=10) as response:
        return json.loads(response.read())


def update_agent_config(enabled):
    local_port = int(os.environ.get("POS_APP_PORT", "4174"))
    config_path = Path(os.environ.get("APP_RELAY_AGENT_CONFIG", "/home/ubuntu/llama_cpp/app_relay/agent.json"))
    config = {}
    if config_path.exists():
        config = agent_config()
    config.setdefault("relay_host", os.environ.get("POS_RELAY_HOST", ""))
    config.setdefault("relay_scheme", os.environ.get("POS_RELAY_SCHEME", "wss"))
    config.setdefault("user_id", os.environ.get("POS_RELAY_USER_ID", ""))
    config.setdefault("token", os.environ.get("POS_RELAY_TOKEN", ""))
    config["enabled_apps"] = {**config.get("enabled_apps", {})}
    if enabled:
        config["enabled_apps"]["pos"] = local_port
    elif "pos" in config["enabled_apps"]:
        del config["enabled_apps"]["pos"]
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2) + "\n")
    config_path.chmod(0o600)

    pid_path = Path(os.environ.get("LLAMA_AGENT_APPS_PID_FILE", "/tmp/llama-agent-apps.pid"))
    if not pid_path.exists():
        return
    for line in pid_path.read_text().splitlines():
        role, _, pid = line.partition(" ")
        if role == "relay-agent" and pid.isdigit():
            os.kill(int(pid), signal.SIGHUP)
            return


class PosStore:
    def __init__(self, path: str):
        self.path = path
        self.initialize()

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def initialize(self) -> None:
        with self.connect() as db:
            db.executescript(
                """
                PRAGMA journal_mode = WAL;
                CREATE TABLE IF NOT EXISTS products (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    sku TEXT NOT NULL UNIQUE,
                    stock_quantity INTEGER NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
                    unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents >= 0),
                    active INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS sales (
                    id TEXT PRIMARY KEY,
                    sold_at TEXT NOT NULL,
                    customer_name TEXT NOT NULL DEFAULT '',
                    total_cents INTEGER NOT NULL CHECK (total_cents >= 0)
                );
                CREATE TABLE IF NOT EXISTS sale_items (
                    sale_id TEXT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
                    product_id TEXT NOT NULL,
                    product_name TEXT NOT NULL,
                    quantity INTEGER NOT NULL CHECK (quantity > 0),
                    unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents >= 0),
                    discount_cents INTEGER NOT NULL DEFAULT 0 CHECK (discount_cents >= 0),
                    line_total_cents INTEGER NOT NULL CHECK (line_total_cents >= 0),
                    PRIMARY KEY (sale_id, product_id)
                );
                CREATE TABLE IF NOT EXISTS relay_config (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    url TEXT NOT NULL DEFAULT '',
                    enabled INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS sales_sold_at_idx ON sales(sold_at);
                CREATE INDEX IF NOT EXISTS sale_items_product_idx ON sale_items(product_id);
                """
            )

    def record_sale(self, sale: dict) -> dict:
        allowed = {"id", "sold_at", "customer_name", "items"}
        if set(sale) - allowed:
            raise ValueError("sale contains unknown fields")
        sale_id = str(sale.get("id", "")).strip()
        if not sale_id or len(sale_id) > 64 or not all(c.isalnum() or c in "-_" for c in sale_id):
            raise ValueError("sale id is invalid")
        sold_at = utc_text(parse_datetime(str(sale.get("sold_at", ""))))
        customer_name = str(sale.get("customer_name", "")).strip()
        if len(customer_name) > 200:
            raise ValueError("customer_name is too long")
        items = sale.get("items")
        if not isinstance(items, list) or not 1 <= len(items) <= MAX_ITEMS_PER_SALE:
            raise ValueError("items must contain 1 to 100 entries")

        normalized = []
        seen = set()
        total_cents = 0
        for item in items:
            if not isinstance(item, dict) or set(item) - {"product_id", "name", "sku", "quantity", "unit_price_cents", "discount_cents", "stock_quantity"}:
                raise ValueError("sale item is invalid")
            product_id = str(item.get("product_id", "")).strip()
            name = str(item.get("name", "")).strip()
            sku = str(item.get("sku", product_id)).strip()
            quantity = int(item.get("quantity", 0))
            unit_price = int(item.get("unit_price_cents", -1))
            discount = int(item.get("discount_cents", 0))
            stock_quantity = int(item.get("stock_quantity", 0))
            if not product_id or len(product_id) > 64 or product_id in seen:
                raise ValueError("product_id must be unique and contain 1 to 64 bytes")
            if not name or len(name) > 200 or not sku or len(sku) > 64:
                raise ValueError("product name or sku is invalid")
            if quantity <= 0 or quantity > 100000 or unit_price < 0 or discount < 0 or stock_quantity < 0:
                raise ValueError("sale item numeric value is invalid")
            line_total = quantity * unit_price - discount
            if line_total < 0:
                raise ValueError("discount cannot exceed the line subtotal")
            seen.add(product_id)
            total_cents += line_total
            normalized.append((product_id, name, sku, quantity, unit_price, discount, stock_quantity, line_total))

        with self.connect() as db:
            db.execute(
                "INSERT INTO sales (id, sold_at, customer_name, total_cents) VALUES (?, ?, ?, ?)",
                (sale_id, sold_at, customer_name, total_cents),
            )
            for product_id, name, sku, quantity, unit_price, discount, stock_quantity, line_total in normalized:
                db.execute(
                    "INSERT INTO products (id, name, sku, stock_quantity, unit_price_cents) VALUES (?, ?, ?, ?, ?) "
                    "ON CONFLICT(id) DO UPDATE SET name = excluded.name, sku = excluded.sku, stock_quantity = excluded.stock_quantity, unit_price_cents = excluded.unit_price_cents",
                    (product_id, name, sku, stock_quantity, unit_price),
                )
                db.execute(
                    "INSERT INTO sale_items (sale_id, product_id, product_name, quantity, unit_price_cents, discount_cents, line_total_cents) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (sale_id, product_id, name, quantity, unit_price, discount, line_total),
                )
        return {"id": sale_id, "sold_at": sold_at, "total_cents": total_cents, "item_count": len(normalized)}

    def sales_summary(self, start: str, end: str) -> dict:
        with self.connect() as db:
            row = db.execute(
                "SELECT COUNT(DISTINCT s.id) AS transaction_count, COALESCE(SUM(i.quantity), 0) AS articles_sold, COALESCE(SUM(i.line_total_cents), 0) AS revenue_cents "
                "FROM sales s LEFT JOIN sale_items i ON i.sale_id = s.id WHERE s.sold_at >= ? AND s.sold_at < ?",
                (start, end),
            ).fetchone()
        return {"from": start, "to": end, **dict(row)}

    def top_selling_items(self, start: str, end: str, limit: int, rank_by: str) -> dict:
        if not 1 <= limit <= MAX_REPORT_LIMIT:
            raise ValueError("limit must be between 1 and 100")
        if rank_by not in {"quantity", "revenue"}:
            raise ValueError("rank_by must be quantity or revenue")
        order = "quantity_sold" if rank_by == "quantity" else "revenue_cents"
        sql = (
            "SELECT i.product_id, MAX(i.product_name) AS name, SUM(i.quantity) AS quantity_sold, SUM(i.line_total_cents) AS revenue_cents "
            "FROM sale_items i JOIN sales s ON s.id = i.sale_id WHERE s.sold_at >= ? AND s.sold_at < ? "
            f"GROUP BY i.product_id ORDER BY {order} DESC, name COLLATE NOCASE, i.product_id LIMIT ?"
        )
        with self.connect() as db:
            items = [dict(row) for row in db.execute(sql, (start, end, limit)).fetchall()]
        return {"from": start, "to": end, "rank_by": rank_by, "items": items}

    def inventory_status(self, low_stock_only: bool, threshold: int, limit: int) -> dict:
        if not 0 <= threshold <= 100000 or not 1 <= limit <= MAX_REPORT_LIMIT:
            raise ValueError("threshold or limit is out of range")
        where = "WHERE active = 1 AND stock_quantity <= ?" if low_stock_only else "WHERE active = 1"
        params = (threshold, limit) if low_stock_only else (limit,)
        with self.connect() as db:
            items = [
                dict(row)
                for row in db.execute(
                    f"SELECT id AS product_id, name, sku, stock_quantity, unit_price_cents FROM products {where} ORDER BY stock_quantity, name COLLATE NOCASE LIMIT ?",
                    params,
                ).fetchall()
            ]
        return {"low_stock_only": low_stock_only, "threshold": threshold, "items": items}

    def get_relay_config(self):
        with self.connect() as db:
            row = db.execute("SELECT url, enabled FROM relay_config WHERE id = 1").fetchone()
            return {"url": row[0] if row else "", "enabled": bool(row[1] if row else 0)}

    def save_relay_config(self, url, enabled):
        with self.connect() as db:
            db.execute(
                "INSERT INTO relay_config (id, url, enabled) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET url = excluded.url, enabled = excluded.enabled",
                (url, 1 if enabled else 0),
            )


class PosApiHandler(BaseHTTPRequestHandler):
    server_version = "pos-api/1"

    def send_cors_headers(self) -> None:
        """Add CORS headers to allow cross-origin requests."""
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

    def send_json(self, status: int, value: dict) -> None:
        body = json.dumps(value, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        """Handle CORS preflight requests."""
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.send_cors_headers()
        self.end_headers()

    def authorized(self) -> bool:
        expected = self.server.api_token
        supplied = self.headers.get("Authorization", "")
        return bool(expected) and hmac.compare_digest(supplied, f"Bearer {expected}")

    def require_auth(self) -> bool:
        if self.authorized():
            return True
        self.send_json(401, {"error": "unauthorized"})
        return False

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            self.send_json(200, {"status": "ok"})
            return
        if parsed.path == "/api/relay/status":
            return self.send_json(200, self.server.store.get_relay_config())
        if parsed.path.startswith("/api/"):
            if not self.require_auth():
                return
            try:
                query = {key: values[-1] for key, values in parse_qs(parsed.query).items()}
                start, end = resolve_bounds(query)
                if parsed.path == "/api/v1/reports/sales-summary":
                    self.send_json(200, self.server.store.sales_summary(start, end))
                elif parsed.path == "/api/v1/reports/top-selling-items":
                    self.send_json(200, self.server.store.top_selling_items(start, end, int(query.get("limit", 10)), query.get("rank_by", "quantity")))
                elif parsed.path == "/api/v1/reports/inventory-status":
                    self.send_json(200, self.server.store.inventory_status(query.get("low_stock_only", "false").lower() == "true", int(query.get("threshold", 5)), int(query.get("limit", 50))))
                else:
                    self.send_json(404, {"error": "not found"})
            except (ValueError, TypeError) as error:
                self.send_json(400, {"error": str(error)})
            return
        self.serve_static(parsed.path)

    def do_POST(self) -> None:
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/api/relay/enable":
                local_port = int(os.environ.get("POS_APP_PORT", "4174"))
                result = relay_request("POST", "/api/apps", {"app_slug": "pos", "app_label": "POS / Billing", "local_port": local_port})
                update_agent_config(True)
                self.server.store.save_relay_config(result["url"], True)
                return self.send_json(200, {**self.server.store.get_relay_config(), "url": result["url"]})
            if parsed.path == "/api/relay/disable":
                config = self.server.store.get_relay_config()
                if config["url"]:
                    relay_request("PATCH", "/api/apps/pos", {"enabled": False})
                update_agent_config(False)
                self.server.store.save_relay_config(config["url"], False)
                return self.send_json(200, self.server.store.get_relay_config())
            if parsed.path != "/api/v1/sales":
                self.send_json(404, {"error": "not found"})
                return
            if not self.require_auth():
                return
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= MAX_BODY_BYTES:
                raise ValueError("request body size is invalid")
            body = json.loads(self.rfile.read(length))
            self.send_json(201, self.server.store.record_sale(body))
        except (ValueError, TypeError, json.JSONDecodeError, sqlite3.IntegrityError, HTTPError, URLError, OSError) as error:
            self.send_json(400, {"error": str(error)})

    def serve_static(self, request_path: str) -> None:
        root = self.server.static_dir
        if root is None:
            self.send_json(404, {"error": "not found"})
            return
        relative = "index.html" if request_path == "/" else request_path.lstrip("/")
        target = (root / relative).resolve()
        if root not in target.parents and target != root:
            self.send_json(404, {"error": "not found"})
            return
        if not target.is_file():
            self.send_json(404, {"error": "not found"})
            return
        body = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(target.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args) -> None:
        sys.stderr.write("pos-api: " + format % args + "\n")


TOOLS = [
    {
        "name": "sales_summary",
        "description": "Returns POS transaction count, articles sold, and revenue for a reporting period.",
        "annotations": {"readOnlyHint": True},
        "inputSchema": {
            "type": "object",
            "properties": {
                "period": {"type": "string", "enum": ["today", "last_30_days", "last_month", "custom"]},
                "from": {"type": "string", "description": "ISO-8601 start for a custom period"},
                "to": {"type": "string", "description": "ISO-8601 exclusive end for a custom period"},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "top_selling_items",
        "description": "Returns the best-selling POS products ranked by quantity or revenue for a reporting period.",
        "annotations": {"readOnlyHint": True},
        "inputSchema": {
            "type": "object",
            "properties": {
                "period": {"type": "string", "enum": ["today", "last_30_days", "last_month", "custom"]},
                "from": {"type": "string"},
                "to": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 100},
                "rank_by": {"type": "string", "enum": ["quantity", "revenue"]},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "inventory_status",
        "description": "Returns POS inventory quantities, optionally limited to low-stock products.",
        "annotations": {"readOnlyHint": True},
        "inputSchema": {
            "type": "object",
            "properties": {
                "low_stock_only": {"type": "boolean"},
                "threshold": {"type": "integer", "minimum": 0, "maximum": 100000},
                "limit": {"type": "integer", "minimum": 1, "maximum": 100},
            },
            "additionalProperties": False,
        },
    },
]


def mcp_result(value: dict) -> dict:
    return {"content": [{"type": "text", "text": json.dumps(value, separators=(",", ":"))}]}


def run_mcp(store: PosStore) -> None:
    handlers = {
        "initialize": lambda params: {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}, "serverInfo": {"name": "pos-reporting", "version": "1.0"}},
        "tools/list": lambda params: {"tools": TOOLS},
        "ping": lambda params: {},
    }
    for line in sys.stdin:
        try:
            request = json.loads(line)
            method = request.get("method")
            if method == "notifications/initialized":
                continue
            if method == "tools/call":
                params = request.get("params", {})
                arguments = params.get("arguments", {})
                name = params.get("name")
                if name == "sales_summary":
                    result = mcp_result(store.sales_summary(*resolve_bounds(arguments)))
                elif name == "top_selling_items":
                    start, end = resolve_bounds(arguments)
                    result = mcp_result(store.top_selling_items(start, end, int(arguments.get("limit", 10)), str(arguments.get("rank_by", "quantity"))))
                elif name == "inventory_status":
                    result = mcp_result(store.inventory_status(bool(arguments.get("low_stock_only", False)), int(arguments.get("threshold", 5)), int(arguments.get("limit", 50))))
                else:
                    raise ValueError("unknown POS tool")
            elif method in handlers:
                result = handlers[method](request.get("params", {}))
            else:
                raise ValueError("method not found")
            response = {"jsonrpc": "2.0", "id": request.get("id"), "result": result}
        except Exception as error:
            response = {"jsonrpc": "2.0", "id": request.get("id") if "request" in locals() else None, "error": {"code": -32602, "message": str(error)}}
        print(json.dumps(response, separators=(",", ":")), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["serve", "mcp"])
    parser.add_argument("--db", default=os.environ.get("POS_DB", "./pos.db"))
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=4174)
    parser.add_argument("--static-dir")
    args = parser.parse_args()
    store = PosStore(args.db)
    if args.mode == "mcp":
        run_mcp(store)
        return
    token = os.environ.get("POS_API_TOKEN", "")
    if not token:
        raise SystemExit("POS_API_TOKEN must be set")
    server = ThreadingHTTPServer((args.host, args.port), PosApiHandler)
    server.store = store
    server.api_token = token
    server.static_dir = Path(args.static_dir).resolve() if args.static_dir else None
    server.serve_forever()


if __name__ == "__main__":
    main()
