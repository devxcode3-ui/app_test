# Store Online Relay Implementation Plan

## Goal

Expose the local Store app through the relay with an ngrok/Tailscale-like user experience:

- The Store continues to run locally and offline.
- A background relay agent maintains an outbound connection to the relay.
- An administrator enables or disables public access from Store admin settings.
- Enabling returns a stable public URL.
- Disabling removes public access without deleting the URL assignment.
- The agent reconnects automatically after network interruptions.

The first supported app is the Store app at `127.0.0.1:4175`.

## Current State

The following pieces already exist:

- Store service: `/home/ubuntu/llama_cpp/store/store_service.py`
- Store bind address: `127.0.0.1:4175`
- Store health endpoint: `/health`
- Store frontend uses relative `/api/...` requests.
- Relay server: `app_relay/cmd/relay/main.go`
- Relay agent: `app_relay/cmd/agent/main.go`
- Agent reconnect loop and WebSocket transport.
- Relay app registration endpoint: `POST /api/apps`
- Relay app listing endpoint: `GET /api/apps`
- Relay database stores app slug, port, and enabled state.
- Relay validates the registered local port instead of trusting the port advertised by the agent.
- Agent supports `relay_scheme` with `ws` for local tests and `wss` for production.

The current agent reads its app list only at startup. The current launcher can start the agent, but it is not connected to Store admin settings.

## Target User Flow

### Enable Online

1. Administrator opens Store admin settings.
2. Administrator clicks `Enable Online`.
3. Store client registers the app if it has no relay registration:

   ```http
   POST /api/apps
   Authorization: Bearer <user_id>:<token>
   Content-Type: application/json
   ```

   ```json
   {
     "app_slug": "store",
     "app_label": "Online Store",
     "local_port": 4175
   }
   ```

4. Relay returns a stable URL, for example:

   ```json
   {
     "subdomain_key": "u86484-store",
     "url": "https://u86484-store.yourdomain.com"
   }
   ```

5. Store client sends an app update to the already-running agent.
6. Agent advertises `store:4175` on its WebSocket connection.
7. Admin settings show the public URL and `Online` status.

### Disable Online

1. Administrator clicks `Disable Online`.
2. Store client sends an app update that removes `store` from the advertised app list.
3. Store client disables the relay registration without deleting the subdomain assignment.
4. Existing public requests finish or are rejected according to the chosen policy.
5. New public requests return an offline response such as HTTP `503`.
6. Admin settings show `Offline` while preserving the assigned URL.

### Reconnect

1. Agent detects a disconnected WebSocket.
2. Agent reconnects automatically using the stored credentials.
3. Agent advertises the currently enabled app list after reconnecting.
4. Store admin settings eventually show `Online` again.

## Required Code Changes

### 1. Relay API: enable and disable app access

Add authenticated endpoints in `app_relay/internal/relay/api.go`:

```text
PATCH /api/apps/{slug}
POST  /api/apps/{slug}/enable
POST  /api/apps/{slug}/disable
```

Use one consistent API style. The recommended minimum is:

```http
PATCH /api/apps/store
Authorization: Bearer <user_id>:<token>
Content-Type: application/json
```

```json
{
  "enabled": true
}
```

Requirements:

- Authenticate using the existing Bearer format.
- Verify that the app belongs to the authenticated user.
- Validate the app slug.
- Preserve the subdomain assignment when disabled.
- Return the app record, public URL, enabled state, and online state.
- Return `404` for an unknown app owned by nobody.
- Return `401` for invalid credentials.
- Return `400` for malformed JSON or unsupported values.

The existing `db.SetAppEnabled` method should be used.

### 2. Relay registry and offline behavior

Confirm that disabling an app removes it from the active registry or causes proxy requests to return a clear offline response.

Expected behavior:

- Disabled app must not be registered by a newly connected agent.
- A disabled app must not become active just because an old agent reconnects.
- An app that has no active tunnel returns HTTP `503`.
- A disabled app should not expose a local service.

If active tunnels need immediate removal, add a registry method that removes a single app key only when owned by the current tunnel.

### 3. Dynamic agent app updates

Extend the shared protocol in `app_relay/internal/protocol/messages.go`.

Add a message type or discriminator, for example:

```json
{
  "type": "update_apps",
  "apps": {
    "store": 4175
  }
}
```

Recommended protocol types:

```go
type AgentUpdate struct {
    Type string         `json:"type"`
    Apps map[string]int `json:"apps"`
}
```

Requirements:

- The agent must accept updates while its WebSocket connection remains open.
- Updates must be serialized with other WebSocket writes.
- The agent must validate ports from `1` through `65535`.
- The relay must continue enforcing the database-registered port.
- The update must not require restarting the Store service.
- The agent must advertise the latest app set after reconnecting.
- Invalid update messages must be logged and ignored without killing the connection.

The simplest implementation is to add a local control channel to the agent process and have the agent send a new `AgentInit` or `AgentUpdate` frame after receiving a local update command.

### 4. Local agent control surface

Add a local-only control mechanism for the Store client. Choose one:

- Embedded Go agent library with exported `EnableApp` and `DisableApp` methods.
- Local Unix domain socket.
- Local loopback HTTP control server protected by a random local secret.
- Process signal plus a persisted config file, only if dynamic updates are not required.

Recommended approach for this codebase:

- Keep the relay WebSocket agent as a long-running process.
- Add a local loopback HTTP control server or Unix socket.
- Bind only to `127.0.0.1` or use a Unix socket.
- Require a locally generated secret for control requests.
- Keep the current JSON config as the persisted desired state.

Example local control API:

```text
GET  /status
POST /apps/store/enable
POST /apps/store/disable
```

The local control API must never be exposed on the public relay interface.

### 5. Store-side RelayManager

Add a Store-side component, for example:

```text
/home/ubuntu/llama_cpp/store/relay_manager.py
```

Responsibilities:

- Start the relay agent process once with the Store service.
- Stop the agent cleanly when the Store service exits.
- Register the Store app on first enable.
- Persist `user_id`, token, relay URL, and local control secret securely.
- Enable and disable `store` without restarting the Store service.
- Poll or subscribe to agent connection status.
- Handle relay errors and display a useful admin message.
- Avoid logging the plaintext relay token.

Do not put relay credentials in browser JavaScript. Admin UI requests should go to the Store backend, and the backend should call the relay API.

### 6. Store admin settings

Add an admin settings section with these states:

```text
Online Store: Disabled
Public URL: Not assigned
Connection: Offline
[Enable Online]
```

When enabled:

```text
Online Store: Enabled
Public URL: https://uXXXX-store.yourdomain.com
Connection: Online
[Disable Online]
```

Required UI behavior:

- Disable the button while an operation is in progress.
- Show registration, authentication, or connection errors.
- Show the stable URL after first registration.
- Preserve the URL when the app is disabled.
- Refresh online status after enable, disable, and page load.
- Do not expose the relay token in the UI.

### 7. Process lifecycle

Update the existing launcher at:

```text
/home/ubuntu/llama_cpp/llama.cpp/tools/server/start-agent-apps.sh
```

The existing opt-in variables may be used during development:

```bash
APP_RELAY_AGENT_ENABLED=1
APP_RELAY_AGENT_BIN=/home/ubuntu/llama_cpp/app_relay/bin/app-relay-agent
APP_RELAY_AGENT_CONFIG=/home/ubuntu/llama_cpp/app_relay/agent.json
```

For production, the Store application should own the agent lifecycle rather than requiring a manually edited config file.

Requirements:

- Agent starts after the Store local port is ready.
- Agent does not start if credentials are missing.
- Agent process failure is visible in admin status.
- Agent receives SIGTERM during Store shutdown.
- Existing POS, WhatsApp, and llama.cpp processes must not be affected.

## Production Deployment

The IP and `nip.io` setup is for testing only. Production must use a real domain.

Example:

```text
relay.yourdomain.com
u86484-store.yourdomain.com
```

Required infrastructure:

1. DNS A record for `relay.yourdomain.com`.
2. Wildcard DNS A record for `*.yourdomain.com`.
3. Wildcard TLS certificate for `yourdomain.com` and `*.yourdomain.com`.
4. nginx or Caddy listening on ports `80` and `443`.
5. WebSocket upgrade forwarding for `/tunnel/`.
6. Relay bound privately to `127.0.0.1:8080`.
7. Lightsail firewall open only for TCP `80` and `443` for normal operation.

The public URL must use HTTPS. The agent must use:

```json
{
  "relay_scheme": "wss"
}
```

Do not use the public IP as the production subdomain base. IP labels are not a substitute for wildcard DNS and TLS.

## Security Requirements

- Keep relay authentication over WSS in production.
- Store relay tokens with file permissions `0600` or in the operating system secret store.
- Never send relay tokens to the browser.
- Do not log tokens, Authorization headers, or full credential URLs.
- Keep local control endpoints on loopback or a Unix socket.
- Validate user ID, app slug, and port values.
- Enforce the registered database port at the relay.
- Protect user registration in production with an admin or invitation mechanism.
- Consider one device token per installation so one client can be revoked independently.
- Add rate limiting to registration and management endpoints.
- Use an allowlist for request headers and strip hop-by-hop headers.
- Keep request and response body limits.
- Add connection and idle timeouts.

## Testing Requirements

### Relay unit tests

Add Go tests for:

- App registration and authentication.
- Enable and disable API behavior.
- Disabled app rejection during agent connection.
- Registered port enforcement when the agent advertises a different port.
- Host-based routing for the Store subdomain.
- Unknown and offline subdomain responses.
- URL-safe encoding of WebSocket query credentials.
- Dynamic app update handling.

### Store integration tests

Verify:

1. Store serves `GET /health` locally on port `4175`.
2. Relay agent connects successfully.
3. Relay reports `store` as online.
4. Public `GET /` returns the Store HTML.
5. Public `GET /health` returns the Store health response.
6. Public `/api/products` works through the tunnel.
7. Admin disable causes new public requests to return offline.
8. Admin enable restores access without restarting the Store service.
9. Agent reconnect restores the enabled Store app.
10. Store shutdown terminates the agent.

### Manual test setup

For temporary IP testing only:

```bash
# Relay control plane
APP_RELAY_SECRET='<test-secret>' \
./bin/app-relay-server \
  -addr 0.0.0.0:18080 \
  -host <private-instance-ip> \
  -domain <public-ip>.nip.io \
  -db /tmp/app-relay-store-demo.db

# Agent config
{
  "relay_host": "<private-instance-ip>:18080",
  "relay_scheme": "ws",
  "user_id": "<user-id>",
  "token": "<token>",
  "enabled_apps": {
    "store": 4175
  }
}
```

The browser URL must use a hostname whose first label is the registered key:

```text
http://<user-id>-store.<public-ip>.nip.io:18080/
```

## Suggested Implementation Order

1. Add relay API tests and implement enable/disable behavior.
2. Add dynamic agent protocol support.
3. Add local agent control surface.
4. Add Store `RelayManager` and secure credential persistence.
5. Add Store admin settings and status display.
6. Add process lifecycle handling.
7. Add end-to-end tests for enable, disable, reconnect, and shutdown.
8. Deploy behind wildcard DNS and HTTPS.
9. Replace temporary IP credentials and test database with production secrets and persistent storage.

## Definition of Done

The feature is complete when an administrator can click `Enable Online` in Store settings, receive a stable HTTPS URL, load the Store from another network, click `Disable Online`, confirm that the URL is offline, and enable it again without restarting the Store or manually editing a JSON file.
