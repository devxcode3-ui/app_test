# GitBucket build and release

GitBucket's repository Build feature runs a shell script on the build host. Set
the repository's **Build file** to:

```text
sh gitbucket-build.sh
```

The script runs `go test ./...`, builds the relay server and agents for Linux,
Windows, and macOS, and writes `dist/app-relay-<version>.tar.gz`.

For a release build, check out a tag and expose these environment variables to
the GitBucket build service:

```text
GITBUCKET_TOKEN=<repository API token>
RELEASE_TAG=v1.0.0
```

`GITBUCKET_TOKEN` must be configured on the build host or service environment,
not in this repository or the visible Build script field. The optional API URL
defaults to:

```text
https://git.13.235.99.117.nip.io/api/v3/repos/root/dexai-relay
```

The release stage creates the tag release through GitBucket's GitHub-compatible
API and uploads the generated tarball. Normal branch builds only test and
package the binaries.