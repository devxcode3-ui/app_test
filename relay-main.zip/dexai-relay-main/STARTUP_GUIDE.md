# Relay System Startup & Authentication Guide

## Overview

The llama.cpp relay system has been fully configured with automated credential refresh to ensure consistent authentication after system restarts.

## Problem Solved

**Issue #1:** The relay agent was losing authentication after each system restart because:
1. The relay server generated a new user with new credentials on each startup
2. The agent.json file was not updated in time
3. The agent connected with stale/old credentials, causing 401 errors

**Issue #2:** URLs changed after every system restart or enable/disable action:
1. Users had to update bookmarks constantly
2. QR codes became invalid
3. Not practical for production use

**Solution:** Automated startup script with credential reuse:
1. **Checks for existing valid credentials** in agent.json
2. **Reuses same credentials** if they're still valid (NEW!)
3. **Only registers new user** if credentials don't exist or are invalid
4. **Registers apps and syncs URLs** to all databases
5. **Starts relay server and agent**

**Result:** URLs now remain STABLE across restarts and enable/disable cycles! 🎉

## Current Status

✅ **HTTPS Infrastructure:** Complete and working
- Certificate issued for `dev.13-235-99-117.nip.io`
- Nginx reverse proxy running on port 443
- Public URLs accessible via HTTPS

✅ **STATIC URLs (Production-Ready!)** 
- User credentials persist across restarts
- Relay URLs NEVER change: `https://u48740-store.13-235-99-117.nip.io`
- QR codes and bookmarks work forever
- Startup script validates and reuses existing credentials

✅ **Agent Authentication:** Fully operational
- Agent successfully authenticates with relay server
- Agent logs confirm: `app-relay agent: connected to dev.13-235-99-117.nip.io, advertising 2 app(s)`
- Fresh app registrations on each startup (maintains connection)

✅ **Relay URL Synchronization:** Complete
- Startup script captures relay URLs from relay server
- Updates both store and POS databases with URLs
- Updates llama-server database for UI display
- URLs remain STATIC across system restarts

✅ **Public URLs (STABLE):**
- `https://dev.13-235-99-117.nip.io/healthz` → Returns `ok`
- `https://u48740-store.13-235-99-117.nip.io/` → Store app accessible ✓
- `https://u48740-pos.13-235-99-117.nip.io/` → POS app accessible ✓

## Startup Script

**Location:** `/home/ubuntu/llama_cpp/app_relay/startup.sh`

**Features:**
- **✅ NEW: Validates and reuses existing credentials** (if still valid)
- **✅ NEW: Keeps URLs stable across restarts**
- **Only registers new user if credentials are missing or invalid**
- Registers store and POS apps with relay server
- Captures relay URLs from relay server response
- Syncs relay URLs to all databases (llama-server, store, pos)
- Starts relay server and agent
- Validates all connections
- Provides detailed logging with color-coded output

**How Credential Reuse Works:**
1. **First startup:** Registers new user (e.g., `u48740`) → URLs created
2. **Second startup:** Checks agent.json → validates credentials → **REUSES user**
3. **Subsequent startups:** Same credentials reused → **URLs remain stable**
4. **On failure:** Registers new user if validation fails
4. Startup script updates database `relay_config` tables:
   - Store DB: `/home/ubuntu/llama_cpp/store/data/store.db`
   - POS DB: `/home/ubuntu/llama_cpp/llama.cpp/tools/apps/pos/pos.db`
5. When apps query their relay status via API, they read from database
6. UI fetches app definitions and displays SAME URLs from databases
7. **URLs remain STABLE across restarts** - no changes needed!

**Manual Usage:**
```bash
cd /home/ubuntu/llama_cpp/app_relay
./startup.sh
```

### Forcing New Credentials (if needed)

To register a new user and get new URLs, delete the agent.json file:

```bash
rm /home/ubuntu/llama_cpp/app_relay/agent.json
sudo systemctl restart llama-relay-startup.service
# OR manually run:
cd /home/ubuntu/llama_cpp/app_relay && ./startup.sh
```

This will:
1. Detect missing agent.json
2. Register a completely new user
3. Generate new URLs
4. Update all databases

**Why you might want new URLs:**
- Migrate to new hardware
- Refresh after a security concern
- Change relay host name
- Start fresh for testing

**But normally, you DON'T need to do this** - URLs stay stable! ✅

**Automatic Usage (via systemd):**
The script runs automatically on system boot via the `llama-relay-startup.service` systemd service.

## Systemd Service

**Location:** `/etc/systemd/system/llama-relay-startup.service`

**Status:**
```bash
# Check if service is enabled
systemctl is-enabled llama-relay-startup.service

# Check service status
sudo systemctl status llama-relay-startup.service

# View service logs
sudo journalctl -u llama-relay-startup.service -f
```

**Trigger Manual Startup (for testing):**
```bash
sudo systemctl start llama-relay-startup.service
```

**Disable (if needed):**
```bash
sudo systemctl disable llama-relay-startup.service
```

## Agent Configuration

**Location:** `/home/ubuntu/llama_cpp/app_relay/agent.json`

**Format:**
```json
{
  "relay_host": "dev.13-235-99-117.nip.io",
  "relay_scheme": "wss",
  "user_id": "u26213",
  "token": "1f391208bd7f8429392cbcf7ed01fa348e0c27e769dd0f7880cde5ab2ac8914f",
  "enabled_apps": {
    "pos": 4174,
    "store": 4175
  }
}
```

**Note:** This file is automatically updated by the startup script. On first run, fresh credentials are registered with the relay server. On subsequent runs, the same credentials are validated and reused, keeping URLs stable.

**Key Points:**
- User ID (e.g., `u48740`) is **persistent** across restarts
- Token is **never hardcoded** - only generated by relay server
- Validation happens on each startup to ensure credentials are still valid
- If credentials become invalid, a new user is automatically registered

## Relay Services

### Relay Server
- **Binary:** `/home/ubuntu/llama_cpp/app_relay/bin/app-relay-server`
- **Listen Address:** `127.0.0.1:18080`
- **Relay Host:** `dev.13-235-99-117.nip.io`
- **Domain:** `13-235-99-117.nip.io`
- **Logs:** `/tmp/relay-server.log`

### Relay Agent
- **Binary:** `/home/ubuntu/llama_cpp/app_relay/bin/app-relay-agent`
- **Config:** `/home/ubuntu/llama_cpp/app_relay/agent.json`
- **Apps:** Store (port 4175), POS (port 4174)
- **Logs:** `/tmp/relay-agent.log`

## Verification

### Check Relay Health
```bash
curl http://127.0.0.1:18080/healthz
# Expected response: ok
```

### Check Agent Logs
```bash
tail -20 /tmp/relay-agent.log
# Expected: "app-relay agent: connected to dev.13-235-99-117.nip.io, advertising 2 app(s)"
```

### Test HTTPS Endpoints
```bash
# Relay host
curl -ks https://dev.13-235-99-117.nip.io/healthz

# Store app (note: user_id may change after restart)
curl -ks https://u26213-store.13-235-99-117.nip.io/ | head -c 200

# POS app
curl -ks https://u26213-pos.13-235-99-117.nip.io/ | head -c 200
```

## Dynamic User IDs

**Important:** After each system restart, a new user ID is generated (e.g., u26213, u31839, etc.). This is normal and expected.

- The app URLs will change to use the new user ID (e.g., `https://u26213-store.13-235-99-117.nip.io`)
- The Online Store and POS app links in the llama.cpp interface will show the current active subdomain
- The startup script automatically handles this refresh process

## Troubleshooting

### Services Not Starting

**Check systemd service status:**
```bash
sudo systemctl status llama-relay-startup.service
sudo journalctl -u llama-relay-startup.service -n 50
```

**Manually run startup script for debugging:**
```bash
cd /home/ubuntu/llama_cpp/app_relay
bash -x ./startup.sh
```

### Agent Shows Offline

**Check agent logs:**
```bash
tail -50 /tmp/relay-agent.log
```

**Verify agent.json credentials match relay server:**
```bash
cat /home/ubuntu/llama_cpp/app_relay/agent.json
curl http://127.0.0.1:18080/healthz
```

**Manually restart startup script:**
```bash
cd /home/ubuntu/llama_cpp/app_relay
./startup.sh
```

### HTTPS Certificate Issues

**Verify certificate:**
```bash
curl -kv https://dev.13-235-99-117.nip.io 2>&1 | grep -A 5 "subject"
```

**Certificate location:**
```bash
ls -la /etc/letsencrypt/live/dev.13-235-99-117.nip.io/
```

## Architecture Diagram

```
┌─────────────────────────────────────────────────────┐
│         System Boot (Systemd Service)                │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼
         ┌──────────────────────┐
         │  startup.sh Script   │
         └──────┬───────────────┘
                │
       ┌────────┼────────┐
       │        │        │
       ▼        ▼        ▼
   Register  Update    Register
    User    agent.json   Apps
       │        │        │
       └────────┼────────┘
                │
       ┌────────┴────────┐
       │                 │
       ▼                 ▼
   Relay Server      Relay Agent
   (127.0.0.1:18080)  (WSS tunnel)
       │                 │
       └────────┬────────┘
                │
         ┌──────▼──────┐
         │   Nginx     │
         │  (HTTPS)    │
         └──────┬──────┘
                │
      ┌────────────────────────┐
      │  Public HTTPS URLs      │
      │ - dev.13-235-99-117...  │
      │ - u26213-store.13-...   │
      │ - u26213-pos.13-...     │
      └────────────────────────┘
```

## Next Steps

### Optional: Monitor Service in Real-time
```bash
# Watch systemd service logs
sudo journalctl -u llama-relay-startup.service -f
```

### Optional: Customize Startup Script
The startup script can be modified to:
- Change app registration details
- Add additional error handling
- Integrate with monitoring systems
- Send notifications on startup

### Optional: Set Up Monitoring
Consider setting up:
- Service health checks via cron
- Alerts for connection failures
- Dashboard to display current user IDs and app URLs

## Related Documentation

- [Relay HTTPS Setup](relay-https-setup.md)
- [Nginx Configuration](/etc/nginx/sites-available/relay-proxy)
- [Systemd Service Documentation](/etc/systemd/system/llama-relay-startup.service)

## Support

For issues or questions:
1. Check service logs: `sudo journalctl -u llama-relay-startup.service`
2. Check agent logs: `tail -50 /tmp/relay-agent.log`
3. Run startup script manually with debugging: `bash -x /home/ubuntu/llama_cpp/app_relay/startup.sh`
4. Verify HTTPS endpoints are responding: `curl -ks https://dev.13-235-99-117.nip.io/healthz`
