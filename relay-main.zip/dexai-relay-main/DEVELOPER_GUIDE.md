# app-relay Developer Guide

## Table of Contents

1. [Overview](#1-overview)
2. [Architecture](#2-architecture)
3. [Project Structure](#3-project-structure)
4. [Protocol Design](#4-protocol-design)
5. [Component Reference](#5-component-reference)
6. [Developer Guide — Build & Run](#6-developer-guide--build--run)
7. [Deployment Guide — Lightsail](#7-deployment-guide--lightsail)
8. [API Reference](#8-api-reference)
9. [Security Model](#9-security-model)
10. [Operational Notes](#10-operational-notes)

---

## 1. Overview

**app-relay** is a lightweight reverse-tunnel system that lets users expose locally-running web apps to the internet on demand, without opening ports or configuring routers.

### Problem it solves

A user runs apps (POS, Inventory, Store) locally on `localhost:8085`, `localhost:8081`, etc. These are inaccessible outside the machine. When the user clicks **Enable Online** in the app settings, app-relay:

1. Assigns a permanent subdomain: `u1001-pos.yourdomain.com`
2. Establishes an encrypted tunnel from the local machine to a relay server
3. Routes all inbound HTTPS traffic for that subdomain through the tunnel to the local app

When the user clicks **Disable Online**, the tunnel is dropped and the subdomain goes offline — but the subdomain assignment is preserved for next time.

### Design goals

- **Local-first** — apps work fully offline; online exposure is opt-in
- **Lightweight** — two small Go binaries, one SQLite file, one Linux server
- **Zero client-side port forwarding** — the agent initiates all connections outbound
- **Per-user subdomain isolation** — `u1001-*` subdomains can only be registered by user `u1001`
- **Auto-reconnect** — agent reconnects transparently after network interruptions

---

## 2. Architecture

### High-level diagram

```
                    *.yourdomain.com  ──►  Lightsail IP
                    (wildcard DNS A record)

Internet User
     │  HTTPS  https://u1001-pos.yourdomain.com
     ▼
┌─────────────────────────────────────────┐
│  nginx (Lightsail)                      │
│  TLS termination — wildcard cert        │
│  Proxy pass → localhost:8080            │
└──────────────────┬──────────────────────┘
                   │  HTTP
                   ▼
┌─────────────────────────────────────────┐
│  app-relay-server  (:8080)              │
│                                         │
│  Host: relay.yourdomain.com  → API/WS   │
│  Host: u1001-pos.*           → Proxy    │
│                                         │
│  Registry (in-memory):                  │
│    "u1001-pos"  → Tunnel{conn, apps}    │
│    "u1001-inv"  → Tunnel{conn, apps}    │
│                                         │
│  SQLite (persistent):                   │
│    users, apps, token hashes            │
└──────────────────┬──────────────────────┘
                   │  WSS (WebSocket over TLS)
                   │  persistent, outbound from agent
                   ▼
┌─────────────────────────────────────────┐
│  app-relay-agent  (local machine)       │
│                                         │
│  Advertises: {"pos":8085,"inv":8081}    │
│  Receives TunnelRequest frames          │
│  Forwards to localhost:<port>           │
│  Sends TunnelResponse frames back       │
└─────────────┬───────────────────────────┘
              │  HTTP  localhost
     ┌────────┼────────┐
     ▼        ▼        ▼
  :8085     :8081    :8082
   POS    Inventory  Store
```

### Request flow (one HTTP request)

```
Browser → nginx → relay-server → (WebSocket frame) → agent → localhost:8085
                                                               │
Browser ← nginx ← relay-server ← (WebSocket frame) ← agent ←┘
```

Each HTTP request is serialised as a JSON frame over the persistent WebSocket connection. The relay holds the HTTP response writer open (up to 30 s) while waiting for the agent to forward and return the response.

### Connection lifecycle

```
Agent boots
  └─ LoadConfig(agent.json)
  └─ RunTunnel(ctx)  ← infinite reconnect loop
       └─ websocket.Dial  wss://relay.yourdomain.com/tunnel/connect
       └─ Send AgentInit  {"apps":{"pos":8085}}
       └─ Read loop  ← blocks until disconnect
            └─ on each TunnelRequest frame:
                 go ForwardToLocal(req) → send TunnelResponse frame

Relay receives connection
  └─ VerifyToken(user_id, token)
  └─ Read AgentInit
  └─ Verify each app_slug against DB
  └─ registry.Register(["u1001-pos"], tunnel)
  └─ Read loop  ← blocks
       └─ on each TunnelResponse:
            tunnel.resolve(id, resp)  → unblocks proxy handler
  └─ defer registry.DeregisterIfOwned(keys, tunnel)
```

---

## 3. Project Structure

```
app-relay/
│
├── cmd/
│   ├── relay/
│   │   └── main.go          Entry point for the relay server binary
│   └── agent/
│       └── main.go          Entry point for the local agent binary
│
├── internal/
│   ├── protocol/
│   │   └── messages.go      Shared wire types (AgentInit, TunnelRequest, TunnelResponse)
│   │
│   ├── db/
│   │   ├── db.go            SQLite open + schema creation
│   │   ├── users.go         User creation, token hashing, token verification
│   │   └── apps.go          App registration, listing, enable/disable, delete
│   │
│   ├── relay/
│   │   ├── server.go        HTTP server, host-based dispatch, WebSocket agent handler
│   │   ├── registry.go      Thread-safe tunnel registry (subdomain_key → *Tunnel)
│   │   ├── proxy.go         Routes inbound HTTP through the active tunnel
│   │   └── api.go           REST handlers: /api/register, /api/apps
│   │
│   └── agent/
│       ├── tunnel.go        WebSocket connect/reconnect loop, concurrent write serialisation
│       ├── forwarder.go     HTTP forwarding to localhost, hop-by-hop header stripping
│       └── config.go        Config file load/save (agent.json)
│
├── go.mod
├── go.sum
├── Makefile
├── agent.example.json       Template agent config file
└── DEVELOPER_GUIDE.md
```

### Package responsibilities

| Package | Responsibility |
|---------|---------------|
| `protocol` | Wire format only — no logic, no I/O. Shared by both binaries. |
| `db` | All SQLite access. Exported methods only; no HTTP or WebSocket concerns. |
| `relay` | Server, routing, registry, proxy, REST API. Knows nothing about local ports. |
| `agent` | Tunnel client, local HTTP forwarding, config. Knows nothing about subdomains. |

---

## 4. Protocol Design

### Transport

All communication between relay and agent uses **WebSocket over TLS (WSS)**. Each frame carries a single JSON message. The WebSocket connection is persistent — one connection per agent, multiplexing all apps for that user.

### Message types

#### `AgentInit` — agent → relay (first frame only)

```json
{
  "apps": {
    "pos": 8085,
    "inventory": 8081
  }
}
```

Declares which local apps the agent is advertising. The relay cross-checks each slug against the database and silently drops any that are not registered or are disabled.

#### `TunnelRequest` — relay → agent

```json
{
  "id":      "a1b2c3d4-e5f6-a1b2-c3d4e5f6a1b2",
  "method":  "POST",
  "path":    "/api/products",
  "query":   "page=2&limit=20",
  "headers": {
    "Content-Type":  "application/json",
    "Authorization": "Bearer ..."
  },
  "body":    "<base64-encoded bytes>",
    "relay_scheme":  "wss",
  "port":    8085
}
    "enabled_apps":  { "store": 4175 }

`id` is a random hex string used to correlate the response. `body` is a base64-encoded byte slice (JSON marshals `[]byte` as base64 automatically).

#### `TunnelResponse` — agent → relay

```json
{
  "id":     "a1b2c3d4-e5f6-a1b2-c3d4e5f6a1b2",
  "status": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body":   "<base64-encoded bytes>"
}
```

`id` matches the originating `TunnelRequest`. The relay uses it to unblock the waiting HTTP handler.

### Concurrency model

```
relay side                         agent side
──────────────────────────────     ──────────────────────────────
One goroutine per HTTP request     One reader goroutine (serial)
  → tunnel.write() [mutex]   ──►   → spawns one goroutine per request
  → blocks on channel               → ForwardToLocal (concurrent)
                             ◄──   → writeCh <- respData (serialised)
  → unblocked by resolve()          (single writer goroutine drains writeCh)
```

- The relay uses a **per-tunnel write mutex** to serialise concurrent request frames sent to the same agent.
- The agent uses a **buffered channel + single writer goroutine** to serialise response frames back to the relay.
- Neither side blocks the other's read loop during a slow local app response.

---

## 5. Component Reference

### `relay.Server`

The central struct. Implements `http.Handler`.

`ServeHTTP` dispatches by `Host` header:
- Host == `relay.yourdomain.com` → chi router (API + WebSocket)
- Any other host → `Proxy.ServeHTTP` with subdomain key in context

### `relay.Registry`

Thread-safe `map[string]*Tunnel`. Key is the subdomain key (`u1001-pos`).

`DeregisterIfOwned` prevents a race where a reconnecting agent's new tunnel is evicted by the deferred cleanup of the old (dead) connection.

### `relay.Proxy`

Extracts subdomain key from context, looks up tunnel, sends `TunnelRequest`, waits up to 30 s for `TunnelResponse` on a per-request channel.

### `relay.Tunnel`

Wraps a `*websocket.Conn` with:
- `write()` — mutex-protected JSON write
- `addPending(id)` — registers a response channel
- `resolve(id, resp)` — delivers response to waiting proxy handler
- `cancelPending(id)` — cleans up on timeout

### `agent.RunTunnel`

Outer reconnect loop. Calls `connect()` repeatedly. On clean shutdown (`ctx.Done()`), returns immediately. On any other error, waits 5 s then retries.

### `agent.ForwardToLocal`

Builds an `http.Request` to `localhost:<port>`, strips hop-by-hop headers, executes with a 25 s timeout, returns a `TunnelResponse`. Never returns an error — failures become `502` responses.

### `db.DB`

All methods use the single `*sql.DB` connection (SQLite, single-writer mode). Token hashes use HMAC-SHA256 with a server-side secret — tokens are never stored in plaintext.

---

## 6. Developer Guide — Build & Run

### Prerequisites

- Go 1.22 or later
- `make` (optional, or run `go build` directly)

### Install dependencies

```bash
cd app-relay
go mod tidy
```

### Build

```bash
# Both binaries → bin/
make build

# Relay server only
make relay

# Agent only
make agent

# Agent cross-compiled for all platforms
make cross

# Relay cross-compiled for Lightsail (Linux amd64)
make relay-linux
```

Or without make:

```bash
go build -o bin/app-relay-server ./cmd/relay
go build -o bin/app-relay-agent  ./cmd/agent
```

### Run locally for development

**Terminal 1 — relay server (local)**

```bash
export APP_RELAY_SECRET=dev-secret-change-in-prod
./bin/app-relay-server \
  -addr   :8080 \
  -host   localhost \
  -domain localhost \
  -db     /tmp/app-relay-dev.db
```

**Terminal 2 — agent**

Create `agent-dev.json`:

```json
{
  "relay_host":    "localhost:8080",
  "user_id":       "u10001",
  "token":         "<token from registration>",
  "enabled_apps":  { "pos": 8085 }
}
```

> Note: for local dev, set `"relay_scheme": "ws"`; production configs should use `"relay_scheme": "wss"`.

```bash
./bin/app-relay-agent -config agent-dev.json
```

To run the store demo with the existing llama.cpp app launcher, build the agent
binary and provide an agent config containing `"store": 4175` in
`enabled_apps`, then start the stack with:

```bash
APP_RELAY_AGENT_ENABLED=1 \
APP_RELAY_AGENT_BIN=/home/ubuntu/llama_cpp/app_relay/bin/app-relay-agent \
APP_RELAY_AGENT_CONFIG=/home/ubuntu/llama_cpp/app_relay/agent.json \
./tools/server/start-agent-apps.sh --agent
```

The launcher keeps the store on `127.0.0.1:4175`, starts the relay agent, and
stops both when the app stack is stopped. Leave `APP_RELAY_AGENT_ENABLED=0`
or unset when the relay is not being used.

**Terminal 3 — register a user (first time)**

```bash
# Register
curl -s -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Dev User"}' | jq

# Register the store app (use user_id and token from above)
curl -s -X POST http://localhost:8080/api/apps \
  -H "Authorization: Bearer u10001:<token>" \
  -H "Content-Type: application/json" \
  -d '{"app_slug":"store","app_label":"Online Store","local_port":4175}' | jq
```

### Run tests

```bash
go test ./...
```

### Integrating the agent into your app

The agent is designed to run as a background process managed by your application:

```go
import (
    "context"
    "app-relay/internal/agent"
)

type OnlineManager struct {
    cancel context.CancelFunc
}

func (m *OnlineManager) EnableApp(slug string, port int, cfg agent.Config) string {
    cfg.EnabledApps[slug] = port
    cfg.Save("agent.json")

    ctx, cancel := context.WithCancel(context.Background())
    m.cancel = cancel
    go agent.RunTunnel(ctx, cfg)

    return "https://" + cfg.UserID + "-" + slug + ".yourdomain.com"
}

func (m *OnlineManager) DisableAll() {
    if m.cancel != nil {
        m.cancel()
    }
}
```

---

## 7. Deployment Guide — Lightsail

### Prerequisites

- Amazon Lightsail Linux instance (Ubuntu 22.04 recommended, $5/mo tier sufficient)
- A domain you control (e.g. `yourdomain.com`) with DNS managed in Route 53 or similar
- Ports 80 and 443 open in Lightsail firewall

### Step 1 — DNS records

Add two records at your DNS provider:

| Type | Name | Value |
|------|------|-------|
| A | `relay` | `<Lightsail public IP>` |
| A | `*` | `<Lightsail public IP>` |

The wildcard `*` record catches all subdomain requests (`u1001-pos.yourdomain.com`, etc.) and routes them to your server.

Verify propagation:

```bash
dig relay.yourdomain.com +short    # should return Lightsail IP
dig u1001-pos.yourdomain.com +short  # should return same IP
```

### Step 2 — TLS wildcard certificate

Wildcard certs require a DNS-01 ACME challenge. Using Certbot with Route 53:

```bash
sudo apt install certbot python3-certbot-dns-route53

# Configure AWS credentials for Route 53 access
aws configure   # or use an IAM role on the Lightsail instance

sudo certbot certonly \
  --dns-route53 \
  -d "yourdomain.com" \
  -d "*.yourdomain.com" \
  --agree-tos \
  --email you@yourdomain.com
```

For other DNS providers, use the appropriate Certbot plugin:
- `python3-certbot-dns-cloudflare` for Cloudflare
- `python3-certbot-dns-digitalocean` for DigitalOcean

Certificates are saved to `/etc/letsencrypt/live/yourdomain.com/`.

Set up auto-renewal:

```bash
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

### Step 3 — Install the relay binary

```bash
# On your dev machine — cross-compile
cd app-relay
make relay-linux
# Output: bin/app-relay-server-linux-amd64

# Upload to Lightsail
scp bin/app-relay-server-linux-amd64 ubuntu@<lightsail-ip>:/usr/local/bin/app-relay-server
ssh ubuntu@<lightsail-ip> "chmod +x /usr/local/bin/app-relay-server"
```

### Step 4 — systemd service

On the Lightsail instance:

```bash
# Generate and store the secret
sudo mkdir -p /etc/app-relay
openssl rand -hex 32 | sudo tee /etc/app-relay/secret
sudo chmod 600 /etc/app-relay/secret

# Create data directory
sudo mkdir -p /var/lib/app-relay
```

Create `/etc/systemd/system/app-relay.service`:

```ini
[Unit]
Description=app-relay relay server
After=network.target

[Service]
Type=simple
User=www-data
ExecStart=/usr/local/bin/app-relay-server \
  -addr   127.0.0.1:8080 \
  -host   relay.yourdomain.com \
  -domain yourdomain.com \
  -db     /var/lib/app-relay/data.db
EnvironmentFile=/etc/app-relay/env
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Create `/etc/app-relay/env`:

```bash
APP_RELAY_SECRET=<paste contents of /etc/app-relay/secret>
```

```bash
sudo chmod 600 /etc/app-relay/env
sudo chown www-data /var/lib/app-relay
sudo systemctl daemon-reload
sudo systemctl enable app-relay
sudo systemctl start app-relay
sudo systemctl status app-relay
```

### Step 5 — nginx reverse proxy

Install nginx:

```bash
sudo apt install nginx
```

Create `/etc/nginx/sites-available/app-relay`:

```nginx
# Redirect HTTP → HTTPS for all subdomains
server {
    listen 80;
    server_name *.yourdomain.com yourdomain.com;
    return 301 https://$host$request_uri;
}

# Relay API + agent WebSocket tunnel (relay.yourdomain.com)
server {
    listen 443 ssl http2;
    server_name relay.yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;

    # WebSocket tunnel connections — long timeout, upgrade headers
    location /tunnel/ {
        proxy_pass         http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade    $http_upgrade;
        proxy_set_header   Connection "upgrade";
        proxy_set_header   Host       $host;
        proxy_read_timeout 3600s;   # keep tunnel alive for up to 1 hour idle
        proxy_send_timeout 3600s;
    }

    # REST API
    location / {
        proxy_pass       http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}

# User app subdomains (u1001-pos.yourdomain.com, etc.)
server {
    listen 443 ssl http2;
    server_name *.yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;

    # All traffic proxied to relay; relay routes by Host header
    location / {
        proxy_pass       http://127.0.0.1:8080;
        proxy_set_header Host       $host;
        proxy_set_header X-Real-IP  $remote_addr;
        proxy_read_timeout 35s;     # slightly above relay's 30s request timeout
    }
}
```

Enable and reload:

```bash
sudo ln -s /etc/nginx/sites-available/app-relay /etc/nginx/sites-enabled/
sudo nginx -t          # test config
sudo systemctl reload nginx
```

### Step 6 — verify

```bash
# Health check
curl https://relay.yourdomain.com/healthz
# → ok

# Register a test user
curl -s -X POST https://relay.yourdomain.com/api/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test"}' | jq
```

### Firewall (Lightsail console)

Ensure these ports are open in the Lightsail instance firewall (not just OS-level):

| Port | Protocol | Purpose |
|------|----------|---------|
| 22   | TCP      | SSH |
| 80   | TCP      | HTTP (redirect to HTTPS) |
| 443  | TCP      | HTTPS / WSS |

The relay itself binds to `127.0.0.1:8080` — it is never exposed directly.

---

## 8. API Reference

All API endpoints are served at `https://relay.yourdomain.com`.

### Authentication

Protected endpoints use the `Authorization` header:

```
Authorization: Bearer <user_id>:<token>
```

Example: `Authorization: Bearer u10001:abc123def456...`

The token is issued at registration and never re-issued. Store it securely.

---

### `POST /api/register`

Create a new user account. Called once per local installation.

**Request**

```json
{ "name": "My Store" }
```

**Response `201`**

```json
{
  "user_id": "u42731",
  "token":   "8f3a...",
  "note":    "Save this token — it will never be shown again."
}
```

---

### `POST /api/apps`

Register a local app for online access. Creates the subdomain assignment.  
Call this when the user clicks **Enable Online** for the first time on an app.

**Request** _(authenticated)_

```json
{
  "app_slug":   "pos",
  "app_label":  "POS System",
  "local_port": 8085
}
```

**Response `200`**

```json
{
  "subdomain_key": "u42731-pos",
  "url":           "https://u42731-pos.yourdomain.com"
}
```

---

### `GET /api/apps`

List all registered apps for the authenticated user, including live online/offline status.

**Response `200`**

```json
[
  {
    "app_slug":   "pos",
    "app_label":  "POS System",
    "local_port": 8085,
    "url":        "https://u42731-pos.yourdomain.com",
    "enabled":    true,
    "online":     true
  },
  {
    "app_slug":   "inventory",
    "app_label":  "Inventory",
    "local_port": 8081,
    "url":        "https://u42731-inventory.yourdomain.com",
    "enabled":    true,
    "online":     false
  }
]
```

`online: true` means the agent is currently connected and the app is reachable.

---

### `DELETE /api/apps/{slug}`

Permanently remove an app registration. The subdomain is freed.

**Response `204`** (no body)

---

### `GET /tunnel/connect` _(WebSocket)_

Agent-only endpoint. Upgrades to WebSocket.

**Query parameters**

| Parameter | Description |
|-----------|-------------|
| `user_id` | e.g. `u42731` |
| `token`   | plaintext token |

After upgrade, the agent sends one `AgentInit` frame, then enters a receive loop for `TunnelRequest` frames, responding with `TunnelResponse` frames.

---

## 9. Security Model

### Token security

- Tokens are 32 random bytes (256-bit entropy), hex-encoded
- Only the HMAC-SHA256 hash is stored server-side
- Tokens are issued once and never retrievable again
- `hmac.Equal` (constant-time comparison) prevents timing attacks
- Agent config file saved with `0600` permissions

### Subdomain isolation

- Subdomain keys are constructed server-side as `{verified_user_id}-{app_slug}`
- An agent can only register subdomains under its own verified user_id
- The relay cross-checks each advertised app_slug against the database before activating
- No user can claim another user's subdomain

### Transport security

- All relay ↔ browser traffic: HTTPS (TLS 1.2+, nginx termination)
- All relay ↔ agent traffic: WSS (WebSocket over TLS)
- Relay binds to `127.0.0.1` only — not directly internet-accessible
- Agent connects outbound only — no listening port on the local machine

### Relay registration hardening (recommended for production)

By default, anyone with the relay URL can call `POST /api/register`. To restrict this:

Option A — **Pre-shared registration key**: add a static `X-Registration-Key` header check in `handleRegister`.

Option B — **Admin-only registration**: remove the public `/api/register` endpoint and provision users via a separate admin CLI or script.

### Known limitations

- **No WebSocket proxying to local apps** — HTTP only. Local apps that use WebSockets for client connections will not work through the tunnel. This can be added in a future version.
- **No streaming responses** — the agent buffers the full response body before sending it back. Large file downloads will consume memory proportional to file size.
- **Single relay** — no high-availability or multi-region. Acceptable for 50–100 users; revisit at larger scale.

---

## 10. Operational Notes

### Monitoring

```bash
# Check service status
sudo systemctl status app-relay

# Follow logs
sudo journalctl -u app-relay -f

# Check active tunnel count (grep relay logs)
sudo journalctl -u app-relay | grep "agent connected" | wc -l
```

### Backup

The entire state of the relay is one SQLite file:

```bash
# Backup
sqlite3 /var/lib/app-relay/data.db ".backup /var/lib/app-relay/data.db.bak"

# Or simply copy (safe while service is running due to SQLite WAL mode)
cp /var/lib/app-relay/data.db /var/lib/app-relay/data.db.$(date +%Y%m%d)
```

### Upgrading the relay binary

```bash
# Cross-compile new version
make relay-linux

# Upload
scp bin/app-relay-server-linux-amd64 ubuntu@<ip>:/usr/local/bin/app-relay-server

# Restart (agents reconnect automatically within 5 s)
sudo systemctl restart app-relay
```

### Resource usage (estimated, 100 active users)

| Resource | Usage |
|----------|-------|
| RAM | ~15–30 MB |
| CPU | < 1% (idle), brief spikes on request bursts |
| Disk (SQLite) | < 1 MB for 100 users × 5 apps |
| Network | Proportional to tunnelled traffic |

The cheapest Lightsail tier ($3.50/mo, 512 MB RAM, 1 vCPU) is sufficient for 100 users.

### Adding HTTPS to local development (optional)

To test with `wss://` locally, use [mkcert](https://github.com/FiloSottile/mkcert):

```bash
mkcert -install
mkcert localhost 127.0.0.1
# Generates localhost.pem + localhost-key.pem
```

Then point nginx locally at those certs, or add TLS support directly to the relay server's `ListenAndServeTLS`.
