#!/bin/bash

# Startup script for llama.cpp relay system
# This script ensures proper initialization and credential refresh after system restarts

set -e

# Configuration
RELAY_DIR="/home/ubuntu/llama_cpp/app_relay"
AGENT_CONFIG="$RELAY_DIR/agent.json"
RELAY_SECRET="llama-relay-secret-dev"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to register or reuse existing user credentials
register_user() {
    local response
    local user_id
    local token
    
    # Check if we already have credentials and they're valid
    if [[ -f "$AGENT_CONFIG" ]]; then
        user_id=$(jq -r '.user_id // empty' "$AGENT_CONFIG" 2>/dev/null)
        token=$(jq -r '.token // empty' "$AGENT_CONFIG" 2>/dev/null)
        
        if [[ -n "$user_id" && -n "$token" ]]; then
            print_info "Found existing credentials for user: $user_id"
            print_info "Validating existing credentials..."
            
            # Validate by trying to list apps with these credentials
            if curl -s -X GET http://127.0.0.1:18080/api/apps \
                -H "Authorization: Bearer $user_id:$token" | jq -e '.' > /dev/null 2>&1; then
                print_info "✓ Credentials are valid - reusing existing user: $user_id"
                print_info "✓ URLs will remain stable: https://$user_id-store.13-235-99-117.nip.io"
                return 0
            else
                print_warn "Existing credentials are invalid, will register new user"
            fi
        fi
    fi
    
    # Credentials don't exist or are invalid - register new user
    print_info "Registering new user with relay server..."
    
    # Register user and capture response
    response=$(curl -s -X POST http://127.0.0.1:18080/api/register \
        -H "Content-Type: application/json" \
        -d '{"name":"Store Owner"}')
    
    # Extract user_id and token from response
    user_id=$(echo "$response" | jq -r '.user_id')
    token=$(echo "$response" | jq -r '.token')
    
    if [[ -z "$user_id" || -z "$token" ]]; then
        print_error "Failed to register user. Response: $response"
        return 1
    fi
    
    print_info "Registered new user: $user_id"
    
    # Update agent.json with fresh credentials
    print_info "Updating agent configuration..."
    
    # Create backup of current config
    if [[ -f "$AGENT_CONFIG" ]]; then
        cp "$AGENT_CONFIG" "${AGENT_CONFIG}.backup"
    fi
    
    # Update the JSON file using jq
    jq --arg user_id "$user_id" \
       --arg token "$token" \
       '.user_id = $user_id | .token = $token' \
       "$AGENT_CONFIG" > "${AGENT_CONFIG}.tmp" && \
    mv "${AGENT_CONFIG}.tmp" "$AGENT_CONFIG"
    
    print_info "Agent configuration updated with fresh credentials"
}

# Function to start relay server
start_relay_server() {
    print_info "Starting relay server..."
    
    # Kill any existing relay processes
    pkill -9 -f 'app-relay' || true
    sleep 1
    
    # Start relay server
    cd "$RELAY_DIR"
    nohup ./bin/app-relay-server -addr 127.0.0.1:18080 \
        -host dev.13-235-99-117.nip.io \
        -domain 13-235-99-117.nip.io \
        > /tmp/relay-server.log 2>&1 &
    
    # Wait for server to start
    sleep 3
    
    # Check if server is running
    if curl -s http://127.0.0.1:18080/healthz | grep -q "ok"; then
        print_info "Relay server started successfully"
        return 0
    else
        print_error "Failed to start relay server"
        cat /tmp/relay-server.log
        return 1
    fi
}

# Function to start relay agent
start_relay_agent() {
    print_info "Starting relay agent..."
    
    # Start relay agent with updated config
    cd "$RELAY_DIR"
    export APP_RELAY_SECRET="$RELAY_SECRET"
    nohup ./bin/app-relay-agent -config agent.json > /tmp/relay-agent.log 2>&1 &
    
    # Wait for agent to start
    sleep 5
    
    # Check if agent is running
    if grep -q "connected to dev.13-235-99-117.nip.io" /tmp/relay-agent.log; then
        print_info "Relay agent started successfully"
        return 0
    else
        print_error "Failed to start relay agent"
        cat /tmp/relay-agent.log
        return 1
    fi
}

# Function to update relay config in database
update_app_db_relay_config() {
    local app_name=$1
    local relay_url=$2
    local db_path=$3
    
    if [[ ! -f "$db_path" ]]; then
        print_warn "Database not found for $app_name: $db_path"
        return 0
    fi
    
    # Use Python to update the database (sqlite3 CLI might not be installed)
    python3 << PYTHON_SCRIPT
import sqlite3
import sys

try:
    db = sqlite3.connect('$db_path')
    cursor = db.cursor()
    
    # Ensure relay_config table exists
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS relay_config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            url TEXT NOT NULL DEFAULT '',
            enabled INTEGER NOT NULL DEFAULT 0
        )
    """)
    
    # Update or insert the relay config
    cursor.execute("""
        INSERT INTO relay_config (id, url, enabled) 
        VALUES (1, ?, 1)
        ON CONFLICT(id) DO UPDATE SET url = excluded.url, enabled = 1
    """, ('$relay_url',))
    
    db.commit()
    db.close()
    print("Updated relay config for $app_name")
except Exception as e:
    print(f"Error updating relay config for $app_name: {e}", file=sys.stderr)
    sys.exit(1)
PYTHON_SCRIPT
    
    if [[ $? -ne 0 ]]; then
        print_warn "Failed to update relay config for $app_name"
        return 0
    fi
}

# Function to update llama-server app definitions database
update_llama_server_apps() {
    local store_url=$1
    local pos_url=$2
    local llama_db="/home/ubuntu/llama_cpp/llama.cpp/agents.db"
    
    if [[ ! -f "$llama_db" ]]; then
        print_warn "Llama-server database not found: $llama_db"
        return 0
    fi
    
    print_info "Updating llama-server app definitions..."
    
    python3 << PYTHON_SCRIPT
import sqlite3
import sys
from datetime import datetime

try:
    db = sqlite3.connect('$llama_db')
    cursor = db.cursor()
    
    # Update store_app online_url
    cursor.execute("""
        UPDATE app_definitions 
        SET online_url = ?, online_enabled = 1, updated_at = ?
        WHERE id = 'store_app'
    """, ('$store_url', int(datetime.now().timestamp())))
    
    # Update pos_app online_url
    cursor.execute("""
        UPDATE app_definitions 
        SET online_url = ?, online_enabled = 1, updated_at = ?
        WHERE id = 'pos_app'
    """, ('$pos_url', int(datetime.now().timestamp())))
    
    db.commit()
    db.close()
    
    # Verify the updates
    db = sqlite3.connect('$llama_db')
    cursor = db.cursor()
    cursor.execute("SELECT id, online_url FROM app_definitions WHERE id IN ('store_app', 'pos_app')")
    for row in cursor.fetchall():
        print(f"Updated {row[0]}: {row[1]}")
    db.close()
except Exception as e:
    print(f"Error updating llama-server apps: {e}", file=sys.stderr)
    sys.exit(1)
PYTHON_SCRIPT
    
    if [[ $? -ne 0 ]]; then
        print_warn "Failed to update llama-server app definitions"
        return 0
    fi
}

# Function to register apps
register_apps() {
    print_info "Registering apps with relay server..."
    
    local user_id
    local token
    local store_url
    local pos_url
    
    # Read credentials from agent.json
    user_id=$(jq -r '.user_id' "$AGENT_CONFIG")
    token=$(jq -r '.token' "$AGENT_CONFIG")
    
    if [[ -z "$user_id" || -z "$token" ]]; then
        print_error "Invalid agent configuration"
        return 1
    fi
    
    # Register store app and capture URL
    print_info "Registering store app..."
    store_response=$(curl -s -X POST http://127.0.0.1:18080/api/apps \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $user_id:$token" \
        -d '{"app_slug":"store","app_label":"Online Store","local_port":4175}')
    
    store_url=$(echo "$store_response" | jq -r '.url // empty')
    if [[ -n "$store_url" ]]; then
        print_info "Store app registered: $store_url"
        # Update store database with new relay URL
        update_app_db_relay_config "store" "$store_url" "/home/ubuntu/llama_cpp/store/data/store.db"
    else
        print_warn "Could not extract URL from store registration response"
        echo "$store_response" | jq .
    fi
    
    # Register POS app and capture URL
    print_info "Registering POS app..."
    pos_response=$(curl -s -X POST http://127.0.0.1:18080/api/apps \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $user_id:$token" \
        -d '{"app_slug":"pos","app_label":"POS Billing","local_port":4174}')
    
    pos_url=$(echo "$pos_response" | jq -r '.url // empty')
    if [[ -n "$pos_url" ]]; then
        print_info "POS app registered: $pos_url"
        # Update POS database with new relay URL (note: POS service uses the llama.cpp directory)
        update_app_db_relay_config "pos" "$pos_url" "/home/ubuntu/llama_cpp/llama.cpp/tools/apps/pos/pos.db"
    else
        print_warn "Could not extract URL from POS registration response"
        echo "$pos_response" | jq .
    fi
    
    # Update llama-server app definitions with the new URLs
    if [[ -n "$store_url" && -n "$pos_url" ]]; then
        update_llama_server_apps "$store_url" "$pos_url"
    fi
    
    print_info "Apps registered successfully"
}

# Main startup process
main() {
    print_info "Starting llama.cpp relay system..."
    
    # Check if we're in the right directory
    if [[ ! -d "$RELAY_DIR" ]]; then
        print_error "Relay directory not found: $RELAY_DIR"
        exit 1
    fi
    
    # Check if required binaries exist
    if [[ ! -f "$RELAY_DIR/bin/app-relay-server" ]]; then
        print_error "Relay server binary not found"
        exit 1
    fi
    
    if [[ ! -f "$RELAY_DIR/bin/app-relay-agent" ]]; then
        print_error "Relay agent binary not found"
        exit 1
    fi
    
    # Check if jq is available
    if ! command_exists jq; then
        print_error "jq is required but not installed"
        exit 1
    fi
    
    # Start relay server
    if ! start_relay_server; then
        exit 1
    fi
    
    # Register new user and update credentials
    if ! register_user; then
        print_warn "Failed to register new user, continuing with existing config"
    fi
    
    # Register apps
    if ! register_apps; then
        print_error "Failed to register apps"
        exit 1
    fi
    
    # Start relay agent
    if ! start_relay_agent; then
        exit 1
    fi
    
    print_info "=== Startup Complete ==="
    print_info "Relay server: http://127.0.0.1:18080/healthz"
    print_info "Agent logs: /tmp/relay-agent.log"
    print_info "Server logs: /tmp/relay-server.log"
    print_info "Agent config: $AGENT_CONFIG"
}

# Run main function
main