#!/bin/sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT_DIR"

TAG=${RELEASE_TAG:-${GIT_TAG:-}}
if [ -z "$TAG" ]; then
    TAG=$(git describe --tags --exact-match HEAD 2>/dev/null || true)
fi
VERSION="$TAG"
if [ -z "$VERSION" ]; then
    VERSION="build-${BUILD_NUMBER:-$(date -u +%Y%m%d%H%M%S)}"
fi

case "$VERSION" in
    *[!A-Za-z0-9._-]*)
        echo "Invalid version: $VERSION" >&2
        exit 1
        ;;
esac

echo "Testing app-relay ${VERSION}"
go test ./...

rm -rf dist
mkdir -p "dist/app-relay-${VERSION}/bin"

make VERSION="$VERSION" build cross relay-linux

cp bin/app-relay-server-linux-amd64 "dist/app-relay-${VERSION}/bin/"
cp bin/app-relay-agent-linux-amd64 "dist/app-relay-${VERSION}/bin/"
cp bin/app-relay-agent-linux-arm64 "dist/app-relay-${VERSION}/bin/"
cp bin/app-relay-agent-windows.exe "dist/app-relay-${VERSION}/bin/"
cp bin/app-relay-agent-darwin-arm64 "dist/app-relay-${VERSION}/bin/"
cp bin/app-relay-agent-darwin-amd64 "dist/app-relay-${VERSION}/bin/"
cp agent.example.json STARTUP_GUIDE.md "dist/app-relay-${VERSION}/"

ARCHIVE="dist/app-relay-${VERSION}.tar.gz"
tar -C dist -czf "$ARCHIVE" "app-relay-${VERSION}"
echo "Created ${ARCHIVE}"

# GitBucket's Build feature does not provide a release secret. Configure the
# token as GITBUCKET_TOKEN in the build service environment.
if [ -n "${GITBUCKET_TOKEN:-}" ] && [ -n "$TAG" ]; then
    API_URL=${GITBUCKET_API_URL:-https://git.13.235.99.nip.io/api/v3/repos/root/dexai-relay}
    RELEASE_JSON=$(printf '%s' "{\"tag_name\":\"${TAG}\",\"name\":\"app-relay ${TAG}\",\"body\":\"Automated app-relay build for ${TAG}.\",\"draft\":false,\"prerelease\":false}" | \
        curl -fsS \
            -H "Authorization: token ${GITBUCKET_TOKEN}" \
            -H 'Accept: application/vnd.github+json' \
            -H 'Content-Type: application/json' \
            -X POST "${API_URL}/releases" \
            --data @-)
    RELEASE_ID=$(printf '%s' "$RELEASE_JSON" | sed -n 's/.*"id"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p')
    if [ -z "$RELEASE_ID" ]; then
        echo "GitBucket release response did not contain an id" >&2
        exit 1
    fi
    curl -fsS \
        -H "Authorization: token ${GITBUCKET_TOKEN}" \
        -H 'Accept: application/vnd.github+json' \
        -H 'Content-Type: application/gzip' \
        --data-binary "@${ARCHIVE}" \
        -X POST "${API_URL}/releases/${RELEASE_ID}/assets?name=$(basename "$ARCHIVE")"
    echo "Published ${TAG} to GitBucket"
fi