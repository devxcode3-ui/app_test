#!/usr/bin/env bash

set -euo pipefail

public_ip="${1:-13.235.99.117}"
region="${AWS_REGION:-${AWS_DEFAULT_REGION:-ap-south-1}}"
port="${2:-18080}"

if ! command -v aws >/dev/null 2>&1; then
    echo "AWS CLI is required: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html" >&2
    exit 2
fi

instance_name="$(aws lightsail get-instances \
    --region "$region" \
    --query "instances[?publicIpAddress=='$public_ip'].name | [0]" \
    --output text)"

if [[ -z "$instance_name" || "$instance_name" == "None" ]]; then
    echo "No Lightsail instance found with public IP $public_ip in region $region." >&2
    exit 1
fi

aws lightsail open-instance-public-ports \
    --region "$region" \
    --instance-name "$instance_name" \
    --port-info "fromPort=$port,toPort=$port,protocol=tcp"

echo "Opened TCP port $port on $instance_name ($public_ip) in $region."