package main

import (
	"flag"
	"log"
	"os"

	"app-relay/internal/db"
	"app-relay/internal/relay"
)

func main() {
	addr := flag.String("addr", ":8080", "TCP listen address")
	dbPath := flag.String("db", "app-relay.db", "SQLite database file path")
	host := flag.String("host", "relay.mydomain.com", "relay's own hostname (for API routing)")
	domain := flag.String("domain", "mydomain.com", "base domain for subdomain URLs")
	publicScheme := flag.String("public-scheme", "https", "scheme for generated public app URLs")
	flag.Parse()

	secret := os.Getenv("APP_RELAY_SECRET")
	if secret == "" {
		log.Fatal("APP_RELAY_SECRET environment variable is required (used for token HMAC)")
	}

	database, err := db.Open(*dbPath)
	if err != nil {
		log.Fatalf("open database: %v", err)
	}
	defer database.Close()

	srv := relay.NewServer(relay.Config{
		Host:         *host,
		Domain:       *domain,
		PublicScheme: *publicScheme,
		Secret:       secret,
		Addr:         *addr,
	}, database)

	log.Fatal(srv.ListenAndServe())
}
