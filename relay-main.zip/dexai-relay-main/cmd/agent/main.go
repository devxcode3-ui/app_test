package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
	"syscall"

	"app-relay/internal/agent"
)

func main() {
	cfgPath := flag.String("config", "agent.json", "path to agent config file")
	flag.Parse()

	cfg, err := agent.LoadConfig(*cfgPath)
	if err != nil {
		log.Fatalf("load config from %q: %v", *cfgPath, err)
	}
	if cfg.RelayHost == "" || cfg.UserID == "" || cfg.Token == "" {
		log.Fatal("config must have relay_host, user_id, and token set")
	}
	if len(cfg.EnabledApps) == 0 {
		log.Println("warning: no enabled_apps in config — agent will connect but expose nothing")
	}

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	log.Printf("app-relay agent starting — user=%s relay=%s", cfg.UserID, cfg.RelayHost)
	hup := make(chan os.Signal, 1)
	signal.Notify(hup, syscall.SIGHUP)
	defer signal.Stop(hup)

	for {
		tunnelCtx, stopTunnel := context.WithCancel(ctx)
		done := make(chan struct{})
		go func(current agent.Config) {
			agent.RunTunnel(tunnelCtx, current)
			close(done)
		}(cfg)

		select {
		case <-ctx.Done():
			stopTunnel()
			<-done
			log.Println("app-relay agent stopped")
			return
		case <-hup:
			stopTunnel()
			<-done
			updated, err := agent.LoadConfig(*cfgPath)
			if err != nil {
				log.Printf("reload config: %v", err)
				continue
			}
			if updated.RelayHost == "" || updated.UserID == "" || updated.Token == "" {
				log.Printf("reload config: relay_host, user_id, and token are required")
				continue
			}
			cfg = updated
			log.Printf("reloaded agent config — advertising %d app(s)", len(cfg.EnabledApps))
		}
	}
}
