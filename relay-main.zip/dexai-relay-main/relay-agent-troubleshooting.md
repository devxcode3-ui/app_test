# Relay Agent Troubleshooting

This guide records the Windows relay issue where POS and Store appeared online but public URLs served the wrong backend or failed to connect.

## Expected Architecture

- POS app: `http://127.0.0.1:4174/`
- Store app: `http://127.0.0.1:4175/`
- Relay management API: `https://dev.13-235-99-117.nip.io`
- DexAI server and Apps UI: `http://127.0.0.1:18093`
- Windows relay agent: `app-relay-agent-windows.exe`
- Agent configuration: `data/agent.json`

The relay agent advertises local ports to the relay server. The public hostname is generated from the relay user ID, so URLs belonging to another user cannot be reused for this Windows installation.

The Windows package does not require a relay server on local port `18080`. The launcher uses the configured `STORE_RELAY_API` (normally the public relay host) for registration.

## Symptoms

### Enable Online fails

The POS or Store UI may show:

```text
Failed to load apps: Server is not running or unreachable
```

or:

```text
<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED]>
```

### Relay logs show no valid apps

```text
skipping unregistered/disabled app "pos"
skipping unregistered/disabled app "store"
received close frame: status = StatusPolicyViolation
reason = "no valid apps registered"
```

This means the agent authenticated, but the relay server has no enabled registration matching the advertised app.

### Public URL opens the wrong application

A URL such as `u48740-pos...` may open GitBucket instead of the Windows POS app. This happens when the hostname belongs to another relay user or when Nginx routes that hostname to the GitBucket server block.

### TLS errors

Typical errors include:

```text
certificate has expired
```

or:

```text
certificate is valid for u95358-pos..., u95358-store..., not dev...
```

The relay agent connects to the relay host, not to an app hostname. The certificate must therefore include the relay host as well as the app hostnames.

### Invalid character in `agent.json`

This error indicates a UTF-8 byte-order mark (BOM) at the beginning of the JSON file:

```text
invalid character 'ï' looking for beginning of value
```

The Go relay agent requires BOM-free UTF-8 JSON. The synchronization script writes `agent.json` without a BOM. If repairing an existing file, rewrite it with a UTF-8 encoder that disables the BOM.

### Legacy app returns 404, 400, or 501

Older packaged POS or Store services may not implement `/api/relay/enable`, or may try to use an obsolete relay endpoint. The Windows synchronizer does not depend on that route. It registers apps through the relay API and updates each app's local `relay_config` SQLite table directly.

### Port bind failure

Starting a second package instance can produce:

```text
couldn't bind HTTP server socket ... port: 18093
```

The launcher checks ports `4174`, `4175`, and `18093` before starting services. Run `stop-server.bat` before starting the package again.

## Diagnosis

Check the local services:

```powershell
Get-NetTCPConnection -State Listen |
  Where-Object { $_.LocalPort -in 4174,4175,18080,18093 }
```

Check the Windows agent:

```powershell
Get-Process -Name app-relay-agent-windows
```

Check the agent configuration. Do not publish the token:

```powershell
Get-Content .\data\agent.json
```

The important mapping is:

```json
"enabled_apps": {
  "pos": 4174,
  "store": 4175
}
```

Check the relay registrations with the user ID and token from `agent.json`:

```powershell
$headers = @{ Authorization = "Bearer <user_id>:<token>" }
Invoke-WebRequest -UseBasicParsing `
  -Uri https://dev.13-235-99-117.nip.io/api/apps `
  -Headers $headers
```

Check the URLs shown by the DexAI Apps UI:

```powershell
(Invoke-WebRequest -UseBasicParsing `
  -Uri http://127.0.0.1:18093/v1/apps).Content
```

The `online_url` values must match the relay registrations exactly. For example, if the agent user is `u95358`, the expected URLs are:

```text
https://u95358-pos.13-235-99-117.nip.io
https://u95358-store.13-235-99-117.nip.io
```

## Fix Applied

The incident was fixed in these steps:

1. Registered POS with the relay server using local port `4174`.
2. Registered Store with the relay server using local port `4175`.
3. Restarted the Windows relay agent with the correct `agent.json`.
4. Replaced stale `u48740-*` URLs in the DexAI app registry with the active `u95358-*` URLs.
5. Added `sync-relay-apps.ps1` to the Windows package to register both apps, update local databases, and synchronize DexAI URLs at startup.
6. Added BOM-free JSON output so the Windows agent can parse `agent.json`.

The resulting relay state was:

```text
pos   -> 127.0.0.1:4174 -> https://u95358-pos.13-235-99-117.nip.io
store -> 127.0.0.1:4175 -> https://u95358-store.13-235-99-117.nip.io
```

No POS, Store, or relay-agent application code needed to change for this correction. The problem was registration and persisted configuration state.

## Register an App

Use the relay API with the agent credentials. Replace the placeholder values and do not store the token in scripts or documentation.

```powershell
$headers = @{ Authorization = "Bearer <user_id>:<token>" }
$body = '{"app_slug":"pos","app_label":"POS / Billing","local_port":4174}'
Invoke-WebRequest -UseBasicParsing `
  -Uri https://dev.13-235-99-117.nip.io/api/apps `
  -Method Post -Headers $headers -ContentType application/json -Body $body

$body = '{"app_slug":"store","app_label":"Store","local_port":4175}'
Invoke-WebRequest -UseBasicParsing `
  -Uri https://dev.13-235-99-117.nip.io/api/apps `
  -Method Post -Headers $headers -ContentType application/json -Body $body
```

Restart the agent:

```powershell
$exe = 'C:\path\to\app-relay-agent-windows.exe'
$config = 'C:\path\to\data\agent.json'
Start-Process -FilePath $exe -ArgumentList '--config', $config
```

Then confirm the relay response reports both apps as `enabled: true` and `online: true`.

## Startup Synchronization

`start-server.bat` starts POS, Store, and DexAI, then runs `sync-relay-apps.ps1` before starting the relay agent. The synchronizer:

1. Waits for the relay and DexAI APIs.
2. Registers POS on port `4174` and Store on port `4175`.
3. Updates each app's local `relay_config` database.
4. Updates DexAI `online_url` and `online_enabled` fields.
5. Rewrites `agent.json` as BOM-free UTF-8.
6. Starts the relay agent with the synchronized configuration.

This makes the startup state recoverable after package extraction, relay-user changes, or stale database URLs.

## Certificate and Nginx Requirements

The public relay certificate must cover:

- `dev.13-235-99-117.nip.io`
- `u95358-pos.13-235-99-117.nip.io`
- `u95358-store.13-235-99-117.nip.io`

A wildcard certificate for `*.13-235-99-117.nip.io` does not cover the bare `dev.13-235-99-117.nip.io` hostname, so both names must be included explicitly when issuing the certificate.

Nginx must route the app hostnames to the relay server on `127.0.0.1:18080`, preserving WebSocket upgrade headers. It must not route them to GitBucket. Validate and reload after changing Nginx:

```bash
sudo nginx -t
sudo nginx -s reload
```

Verify the certificate and backend:

```bash
curl -I https://u95358-pos.13-235-99-117.nip.io/
curl -I https://u95358-store.13-235-99-117.nip.io/
```

If the certificate is not trusted, do not use certificate bypasses in production. Renew the certificate and reload Nginx.

## Important Distinction

These are separate layers:

1. Local app availability: ports `4174` and `4175`.
2. Relay registration: app enabled for the correct relay user.
3. Agent tunnel: agent connected and advertising the registered apps.
4. Public routing: Nginx routes the hostname to the relay server.
5. UI state: DexAI `online_url` matches the active relay URL.
6. TLS: the certificate matches the relay and app hostnames.

All six must be correct for the Apps UI links to work.
