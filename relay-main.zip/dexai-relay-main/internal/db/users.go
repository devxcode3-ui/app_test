package db

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"math/big"
)

// CreateUser generates a unique user_id and a secure token, stores the token
// hash, and returns the plaintext token (shown only once).
func (d *DB) CreateUser(name, secret string) (userID, token string, err error) {
	for attempts := 0; attempts < 5; attempts++ {
		n, randErr := rand.Int(rand.Reader, big.NewInt(90000))
		if randErr != nil {
			return "", "", randErr
		}
		candidate := fmt.Sprintf("u%d", n.Int64()+10000)

		rawToken := make([]byte, 32)
		if _, randErr = rand.Read(rawToken); randErr != nil {
			return "", "", randErr
		}
		plainToken := hex.EncodeToString(rawToken)
		hash := hashToken(plainToken, secret)

		_, dbErr := d.sql.Exec(
			"INSERT INTO users (user_id, name, token_hash) VALUES (?, ?, ?)",
			candidate, name, hash,
		)
		if dbErr == nil {
			return candidate, plainToken, nil
		}
		// retry on UNIQUE constraint (collision)
	}
	return "", "", fmt.Errorf("failed to generate unique user_id after retries")
}

// VerifyToken returns true when token is valid for the given user.
func (d *DB) VerifyToken(userID, token, secret string) bool {
	var stored string
	err := d.sql.QueryRow(
		"SELECT token_hash FROM users WHERE user_id = ?", userID,
	).Scan(&stored)
	if err != nil {
		return false
	}
	expected := hashToken(token, secret)
	return hmac.Equal([]byte(stored), []byte(expected))
}

func hashToken(token, secret string) string {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(token))
	return hex.EncodeToString(mac.Sum(nil))
}
