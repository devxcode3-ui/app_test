package db

import "fmt"

// App represents a registered app-to-subdomain mapping.
type App struct {
	SubdomainKey string
	UserID       string
	AppSlug      string
	AppLabel     string
	LocalPort    int
	Enabled      bool
}

// SubdomainKey builds the routing key for user+app.
func SubdomainKey(userID, appSlug string) string {
	return fmt.Sprintf("%s-%s", userID, appSlug)
}

// RegisterApp inserts or updates an app registration.
// Returns the subdomain_key (e.g. "u1001-pos").
func (d *DB) RegisterApp(userID, appSlug, appLabel string, localPort int) (string, error) {
	key := SubdomainKey(userID, appSlug)
	_, err := d.sql.Exec(`
		INSERT INTO apps (subdomain_key, user_id, app_slug, app_label, local_port, enabled)
		VALUES (?, ?, ?, ?, ?, 1)
		ON CONFLICT(subdomain_key) DO UPDATE SET
			app_label  = excluded.app_label,
			local_port = excluded.local_port,
			enabled    = 1`,
		key, userID, appSlug, appLabel, localPort,
	)
	return key, err
}

// GetUserApps returns all registered apps for a user.
func (d *DB) GetUserApps(userID string) ([]App, error) {
	rows, err := d.sql.Query(`
		SELECT subdomain_key, user_id, app_slug, app_label, local_port, enabled
		FROM apps WHERE user_id = ?`, userID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var apps []App
	for rows.Next() {
		var a App
		var enabled int
		if err := rows.Scan(&a.SubdomainKey, &a.UserID, &a.AppSlug, &a.AppLabel, &a.LocalPort, &enabled); err != nil {
			return nil, err
		}
		a.Enabled = enabled == 1
		apps = append(apps, a)
	}
	return apps, rows.Err()
}

// GetApp returns a single app by user and slug.
func (d *DB) GetApp(userID, appSlug string) (*App, error) {
	key := SubdomainKey(userID, appSlug)
	var a App
	var enabled int
	err := d.sql.QueryRow(`
		SELECT subdomain_key, user_id, app_slug, app_label, local_port, enabled
		FROM apps WHERE subdomain_key = ?`, key,
	).Scan(&a.SubdomainKey, &a.UserID, &a.AppSlug, &a.AppLabel, &a.LocalPort, &enabled)
	if err != nil {
		return nil, err
	}
	a.Enabled = enabled == 1
	return &a, nil
}

// SetAppEnabled toggles the enabled flag without removing the subdomain assignment.
func (d *DB) SetAppEnabled(userID, appSlug string, enabled bool) error {
	v := 0
	if enabled {
		v = 1
	}
	_, err := d.sql.Exec(
		"UPDATE apps SET enabled = ? WHERE subdomain_key = ?",
		v, SubdomainKey(userID, appSlug),
	)
	return err
}

// DeleteApp removes an app registration permanently.
func (d *DB) DeleteApp(userID, appSlug string) error {
	_, err := d.sql.Exec(
		"DELETE FROM apps WHERE subdomain_key = ?",
		SubdomainKey(userID, appSlug),
	)
	return err
}
