package db

import (
	"database/sql"

	_ "modernc.org/sqlite"
)

const schema = `
CREATE TABLE IF NOT EXISTS users (
	user_id    TEXT PRIMARY KEY,
	name       TEXT NOT NULL,
	token_hash TEXT NOT NULL,
	created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS apps (
	subdomain_key TEXT PRIMARY KEY,
	user_id       TEXT NOT NULL REFERENCES users(user_id),
	app_slug      TEXT NOT NULL,
	app_label     TEXT NOT NULL,
	local_port    INTEGER NOT NULL,
	enabled       INTEGER NOT NULL DEFAULT 1,
	created_at    TEXT DEFAULT (datetime('now'))
);
`

// DB wraps a SQLite connection.
type DB struct {
	sql *sql.DB
}

// Open opens (or creates) the SQLite database at path and applies the schema.
func Open(path string) (*DB, error) {
	sqlDB, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, err
	}
	sqlDB.SetMaxOpenConns(1) // SQLite: single writer
	if _, err := sqlDB.Exec(schema); err != nil {
		sqlDB.Close()
		return nil, err
	}
	return &DB{sql: sqlDB}, nil
}

func (d *DB) Close() error {
	return d.sql.Close()
}
