package protocol

// AgentInit is the first message sent by agent after WebSocket connect,
// declaring which local apps it is advertising.
type AgentInit struct {
	Apps map[string]int `json:"apps"` // app_slug → local_port  e.g. {"pos": 8085}
}

// TunnelRequest is sent from relay → agent to forward an inbound HTTP request.
type TunnelRequest struct {
	ID      string            `json:"id"`
	Method  string            `json:"method"`
	Path    string            `json:"path"`
	Query   string            `json:"query"`
	Headers map[string]string `json:"headers"`
	Body    []byte            `json:"body"`
	Port    int               `json:"port"`
}

// TunnelResponse is sent from agent → relay with the HTTP response.
type TunnelResponse struct {
	ID      string            `json:"id"`
	Status  int               `json:"status"`
	Headers map[string]string `json:"headers"`
	Body    []byte            `json:"body"`
}
