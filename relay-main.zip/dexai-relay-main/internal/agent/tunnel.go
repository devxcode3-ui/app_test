package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/url"
	"time"

	"app-relay/internal/protocol"
	"github.com/coder/websocket"
)

// RunTunnel connects to the relay and runs the tunnel loop indefinitely,
// reconnecting automatically on disconnect. Blocks until ctx is cancelled.
func RunTunnel(ctx context.Context, cfg Config) {
	for {
		err := connect(ctx, cfg)
		if ctx.Err() != nil {
			return // clean shutdown
		}
		log.Printf("app-relay agent: tunnel disconnected (%v) — reconnecting in 5s", err)
		select {
		case <-ctx.Done():
			return
		case <-time.After(5 * time.Second):
		}
	}
}

func connect(ctx context.Context, cfg Config) error {
	scheme := cfg.RelayScheme
	if scheme == "" {
		scheme = "wss"
	}
	if scheme != "ws" && scheme != "wss" {
		return fmt.Errorf("invalid relay scheme %q", scheme)
	}

	query := url.Values{}
	query.Set("user_id", cfg.UserID)
	query.Set("token", cfg.Token)
	wsURL := fmt.Sprintf("%s://%s/tunnel/connect?%s", scheme, cfg.RelayHost, query.Encode())

	conn, _, err := websocket.Dial(ctx, wsURL, &websocket.DialOptions{
		// Keep the tunnel alive through idle periods.
		CompressionMode: websocket.CompressionDisabled,
	})
	if err != nil {
		return fmt.Errorf("dial: %w", err)
	}
	conn.SetReadLimit(64 << 20)
	defer conn.Close(websocket.StatusNormalClosure, "")

	// Serialise all writes through a buffered channel so concurrent
	// ForwardToLocal goroutines don't race on the connection.
	writeCh := make(chan []byte, 64)
	writeErrCh := make(chan error, 1)

	go func() {
		for data := range writeCh {
			if err := conn.Write(ctx, websocket.MessageText, data); err != nil {
				writeErrCh <- err
				return
			}
		}
	}()

	// Send AgentInit.
	initData, _ := json.Marshal(protocol.AgentInit{Apps: cfg.EnabledApps})
	select {
	case writeCh <- initData:
	case <-ctx.Done():
		return ctx.Err()
	}

	log.Printf("app-relay agent: connected to %s, advertising %d app(s)", cfg.RelayHost, len(cfg.EnabledApps))

	for {
		// Check for write errors from the background goroutine.
		select {
		case err := <-writeErrCh:
			return fmt.Errorf("write: %w", err)
		default:
		}

		_, data, err := conn.Read(ctx)
		if err != nil {
			return fmt.Errorf("read: %w", err)
		}

		var req protocol.TunnelRequest
		if err := json.Unmarshal(data, &req); err != nil {
			log.Printf("app-relay agent: invalid frame from relay: %v", err)
			continue
		}

		// Handle each request in its own goroutine so slow local apps
		// don't block other concurrent requests.
		go func(r protocol.TunnelRequest) {
			resp := ForwardToLocal(ctx, r)
			respData, _ := json.Marshal(resp)
			select {
			case writeCh <- respData:
			case <-ctx.Done():
			}
		}(req)
	}
}
