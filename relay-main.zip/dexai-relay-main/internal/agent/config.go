package agent

import (
	"encoding/json"
	"os"
)

// Config holds the local tunnel agent settings.
// Stored at ~/.config/app-relay/agent.json or next to the binary.
type Config struct {
	// RelayHost is the relay server hostname, e.g. "relay.mydomain.com".
	RelayHost string `json:"relay_host"`

	// RelayScheme selects ws for local development or wss for deployment.
	// It defaults to wss when omitted.
	RelayScheme string `json:"relay_scheme,omitempty"`

	// UserID is assigned by the relay on first registration, e.g. "u1001".
	UserID string `json:"user_id"`

	// Token is the plaintext auth token returned at registration.
	// Stored locally; never sent to third parties.
	Token string `json:"token"`

	// EnabledApps maps app_slug → local_port for apps the user has turned online.
	// e.g. {"pos": 8085, "inventory": 8081}
	EnabledApps map[string]int `json:"enabled_apps"`
}

func LoadConfig(path string) (Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return Config{}, err
	}
	var cfg Config
	return cfg, json.Unmarshal(data, &cfg)
}

func (c Config) Save(path string) error {
	data, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0600)
}
