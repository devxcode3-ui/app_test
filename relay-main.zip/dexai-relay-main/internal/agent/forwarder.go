package agent

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"app-relay/internal/protocol"
)

var httpClient = &http.Client{
	Timeout: 25 * time.Second,
}

// ForwardToLocal sends the tunnel request to the appropriate localhost port
// and returns the response. Never returns an error; failures become 502 responses.
func ForwardToLocal(ctx context.Context, req protocol.TunnelRequest) protocol.TunnelResponse {
	urlStr := fmt.Sprintf("http://localhost:%d%s", req.Port, req.Path)
	if req.Query != "" {
		urlStr += "?" + req.Query
	}

	var bodyReader io.Reader = http.NoBody
	if len(req.Body) > 0 {
		bodyReader = bytes.NewReader(req.Body)
	}

	httpReq, err := http.NewRequestWithContext(ctx, req.Method, urlStr, bodyReader)
	if err != nil {
		return errResp(req.ID, 502, "failed to build request: "+err.Error())
	}

	for k, v := range req.Headers {
		switch strings.ToLower(k) {
		case "host", "connection", "transfer-encoding", "te", "trailers", "upgrade":
			// strip hop-by-hop headers
		default:
			httpReq.Header.Set(k, v)
		}
	}
	// Tell the local app what the real host was.
	httpReq.Host = fmt.Sprintf("localhost:%d", req.Port)

	resp, err := httpClient.Do(httpReq)
	if err != nil {
		return errResp(req.ID, 502, "local app unreachable: "+err.Error())
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(io.LimitReader(resp.Body, 32<<20))
	if err != nil {
		return errResp(req.ID, 502, "failed to read local response: "+err.Error())
	}

	headers := make(map[string]string, len(resp.Header))
	for k, vals := range resp.Header {
		switch strings.ToLower(k) {
		case "transfer-encoding", "connection":
			// strip
		default:
			headers[k] = strings.Join(vals, ", ")
		}
	}

	return protocol.TunnelResponse{
		ID:      req.ID,
		Status:  resp.StatusCode,
		Headers: headers,
		Body:    body,
	}
}

func errResp(id string, status int, msg string) protocol.TunnelResponse {
	return protocol.TunnelResponse{
		ID:      id,
		Status:  status,
		Headers: map[string]string{"Content-Type": "text/plain; charset=utf-8"},
		Body:    []byte(msg),
	}
}
