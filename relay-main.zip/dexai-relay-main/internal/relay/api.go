package relay

import (
	"encoding/json"
	"net/http"
	"strings"

	"github.com/go-chi/chi/v5"
)

// handleRegister creates a new user account and returns user_id + token.
// The token is shown only once and never stored in plaintext.
//
// POST /api/register
// Body: {"name": "John's Store"}
func (s *Server) handleRegister(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Name string `json:"name"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || strings.TrimSpace(body.Name) == "" {
		http.Error(w, `{"error":"name required"}`, http.StatusBadRequest)
		return
	}

	userID, token, err := s.db.CreateUser(strings.TrimSpace(body.Name), s.config.Secret)
	if err != nil {
		http.Error(w, `{"error":"failed to create user"}`, http.StatusInternalServerError)
		return
	}

	writeJSON(w, http.StatusCreated, map[string]string{
		"user_id": userID,
		"token":   token,
		"note":    "Save this token — it will never be shown again.",
	})
}

// handleRegisterApp registers (or updates) a local app for online access.
// Returns the public subdomain URL assigned to this app.
//
// POST /api/apps
// Auth: Bearer <user_id>:<token>
// Body: {"app_slug":"pos","app_label":"POS System","local_port":8085}
func (s *Server) handleRegisterApp(w http.ResponseWriter, r *http.Request) {
	userID, ok := s.authenticate(r)
	if !ok {
		http.Error(w, `{"error":"unauthorized"}`, http.StatusUnauthorized)
		return
	}

	var body struct {
		AppSlug   string `json:"app_slug"`
		AppLabel  string `json:"app_label"`
		LocalPort int    `json:"local_port"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, `{"error":"invalid JSON body"}`, http.StatusBadRequest)
		return
	}
	if body.AppSlug == "" || body.LocalPort < 1 || body.LocalPort > 65535 {
		http.Error(w, `{"error":"app_slug and local_port must be valid"}`, http.StatusBadRequest)
		return
	}

	key, err := s.db.RegisterApp(userID, body.AppSlug, body.AppLabel, body.LocalPort)
	if err != nil {
		http.Error(w, `{"error":"failed to register app"}`, http.StatusInternalServerError)
		return
	}

	writeJSON(w, http.StatusOK, map[string]string{
		"subdomain_key": key,
		"url":           s.publicURL(key),
	})
}

// handleListApps returns all registered apps for the authenticated user.
//
// GET /api/apps
func (s *Server) handleListApps(w http.ResponseWriter, r *http.Request) {
	userID, ok := s.authenticate(r)
	if !ok {
		http.Error(w, `{"error":"unauthorized"}`, http.StatusUnauthorized)
		return
	}

	apps, err := s.db.GetUserApps(userID)
	if err != nil {
		http.Error(w, `{"error":"failed to list apps"}`, http.StatusInternalServerError)
		return
	}

	type appItem struct {
		AppSlug   string `json:"app_slug"`
		AppLabel  string `json:"app_label"`
		LocalPort int    `json:"local_port"`
		URL       string `json:"url"`
		Enabled   bool   `json:"enabled"`
		Online    bool   `json:"online"`
	}

	result := make([]appItem, 0, len(apps))
	for _, a := range apps {
		key := a.SubdomainKey
		_, online := s.registry.Get(key)
		result = append(result, appItem{
			AppSlug:   a.AppSlug,
			AppLabel:  a.AppLabel,
			LocalPort: a.LocalPort,
			URL:       s.publicURL(key),
			Enabled:   a.Enabled,
			Online:    online,
		})
	}
	writeJSON(w, http.StatusOK, result)
}

func (s *Server) handleUpdateApp(w http.ResponseWriter, r *http.Request) {
	userID, ok := s.authenticate(r)
	if !ok {
		http.Error(w, `{"error":"unauthorized"}`, http.StatusUnauthorized)
		return
	}

	var body struct {
		Enabled *bool `json:"enabled"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body.Enabled == nil {
		http.Error(w, `{"error":"enabled is required"}`, http.StatusBadRequest)
		return
	}
	app, err := s.db.GetApp(userID, chi.URLParam(r, "slug"))
	if err != nil {
		http.Error(w, `{"error":"app not found"}`, http.StatusNotFound)
		return
	}
	if err := s.db.SetAppEnabled(userID, app.AppSlug, *body.Enabled); err != nil {
		http.Error(w, `{"error":"failed to update app"}`, http.StatusInternalServerError)
		return
	}
	if !*body.Enabled {
		key := app.SubdomainKey
		if tunnel, found := s.registry.Get(key); found {
			s.registry.DeregisterIfOwned([]string{key}, tunnel)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"app_slug": app.AppSlug,
		"url":      s.publicURL(app.SubdomainKey),
		"enabled":  *body.Enabled,
	})
}

// handleDeleteApp removes an app registration permanently.
//
// DELETE /api/apps/{slug}
func (s *Server) handleDeleteApp(w http.ResponseWriter, r *http.Request) {
	userID, ok := s.authenticate(r)
	if !ok {
		http.Error(w, `{"error":"unauthorized"}`, http.StatusUnauthorized)
		return
	}

	slug := chi.URLParam(r, "slug")
	if err := s.db.DeleteApp(userID, slug); err != nil {
		http.Error(w, `{"error":"failed to delete app"}`, http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// authenticate extracts credentials from the Authorization header.
// Expected format: Bearer <user_id>:<token>
func (s *Server) authenticate(r *http.Request) (string, bool) {
	auth := r.Header.Get("Authorization")
	bearer, found := strings.CutPrefix(auth, "Bearer ")
	if !found {
		return "", false
	}
	userID, token, found := strings.Cut(bearer, ":")
	if !found || userID == "" || token == "" {
		return "", false
	}
	if !s.db.VerifyToken(userID, token, s.config.Secret) {
		return "", false
	}
	return userID, true
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}
