package relay

import (
	"context"
	"encoding/json"
	"sync"

	"app-relay/internal/protocol"
	"github.com/coder/websocket"
)

// Tunnel represents one connected agent and all its pending in-flight requests.
type Tunnel struct {
	UserID  string
	Apps    map[string]int // app_slug → local_port

	conn    *websocket.Conn
	writeMu sync.Mutex
	pendMu  sync.Mutex
	pending map[string]chan *protocol.TunnelResponse
}

func newTunnel(userID string, conn *websocket.Conn, apps map[string]int) *Tunnel {
	return &Tunnel{
		UserID:  userID,
		Apps:    apps,
		conn:    conn,
		pending: make(map[string]chan *protocol.TunnelResponse),
	}
}

// write serialises JSON and sends it to the agent; safe for concurrent callers.
func (t *Tunnel) write(ctx context.Context, v any) error {
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}
	t.writeMu.Lock()
	defer t.writeMu.Unlock()
	return t.conn.Write(ctx, websocket.MessageText, data)
}

// addPending registers a response channel for a request ID.
func (t *Tunnel) addPending(id string) chan *protocol.TunnelResponse {
	ch := make(chan *protocol.TunnelResponse, 1)
	t.pendMu.Lock()
	t.pending[id] = ch
	t.pendMu.Unlock()
	return ch
}

// resolve delivers a response to the waiting proxy handler.
func (t *Tunnel) resolve(id string, resp *protocol.TunnelResponse) {
	t.pendMu.Lock()
	ch, ok := t.pending[id]
	if ok {
		delete(t.pending, id)
	}
	t.pendMu.Unlock()
	if ok {
		select {
		case ch <- resp:
		default:
		}
	}
}

// cancelPending removes a pending entry (called on timeout/context cancel).
func (t *Tunnel) cancelPending(id string) {
	t.pendMu.Lock()
	delete(t.pending, id)
	t.pendMu.Unlock()
}

// Registry is a thread-safe map of subdomain_key → active Tunnel.
type Registry struct {
	mu      sync.RWMutex
	tunnels map[string]*Tunnel
}

func NewRegistry() *Registry {
	return &Registry{tunnels: make(map[string]*Tunnel)}
}

func (r *Registry) Register(keys []string, t *Tunnel) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, k := range keys {
		r.tunnels[k] = t
	}
}

func (r *Registry) Get(key string) (*Tunnel, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	t, ok := r.tunnels[key]
	return t, ok
}

// DeregisterIfOwned removes keys only when the stored tunnel is still t.
// This prevents a reconnecting agent from evicting a freshly registered session.
func (r *Registry) DeregisterIfOwned(keys []string, t *Tunnel) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, k := range keys {
		if r.tunnels[k] == t {
			delete(r.tunnels, k)
		}
	}
}
