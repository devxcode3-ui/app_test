package relay

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"app-relay/internal/protocol"
)

type contextKey string

const ctxKeySubdomain contextKey = "subdomain"

// Proxy routes inbound HTTP requests to the correct tunnel based on subdomain key.
type Proxy struct {
	registry *Registry
}

func NewProxy(r *Registry) *Proxy {
	return &Proxy{registry: r}
}

func (p *Proxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	key, _ := r.Context().Value(ctxKeySubdomain).(string)

	tunnel, ok := p.registry.Get(key)
	if !ok {
		http.Error(w, fmt.Sprintf("no active tunnel for %q — agent may be offline", key), http.StatusServiceUnavailable)
		return
	}

	// Derive app_slug from subdomain key: "u1001-pos" → "pos"
	// SplitN with n=2 preserves hyphens inside the slug (e.g. "my-pos").
	parts := strings.SplitN(key, "-", 2)
	if len(parts) != 2 {
		http.Error(w, "malformed subdomain key", http.StatusBadRequest)
		return
	}
	appSlug := parts[1]

	port, ok := tunnel.Apps[appSlug]
	if !ok {
		http.Error(w, fmt.Sprintf("app %q is not registered on this tunnel", appSlug), http.StatusNotFound)
		return
	}

	body, err := io.ReadAll(io.LimitReader(r.Body, 32<<20)) // 32 MB cap
	if err != nil {
		http.Error(w, "failed to read request body", http.StatusInternalServerError)
		return
	}

	headers := make(map[string]string, len(r.Header))
	for k, vals := range r.Header {
		lower := strings.ToLower(k)
		if lower == "connection" || lower == "upgrade" || lower == "transfer-encoding" {
			continue
		}
		headers[k] = strings.Join(vals, ", ")
	}

	reqID := newID()
	req := protocol.TunnelRequest{
		ID:      reqID,
		Method:  r.Method,
		Path:    r.URL.Path,
		Query:   r.URL.RawQuery,
		Headers: headers,
		Body:    body,
		Port:    port,
	}

	ch := tunnel.addPending(reqID)
	defer tunnel.cancelPending(reqID)

	ctx, cancel := context.WithTimeout(r.Context(), 30*time.Second)
	defer cancel()

	if err := tunnel.write(ctx, req); err != nil {
		http.Error(w, "tunnel write error", http.StatusBadGateway)
		return
	}

	select {
	case resp := <-ch:
		for k, v := range resp.Headers {
			if strings.ToLower(k) != "transfer-encoding" {
				w.Header().Set(k, v)
			}
		}
		w.WriteHeader(resp.Status)
		w.Write(resp.Body)

	case <-ctx.Done():
		http.Error(w, "tunnel response timeout", http.StatusGatewayTimeout)
	}
}

func newID() string {
	b := make([]byte, 16)
	rand.Read(b)
	var buf bytes.Buffer
	buf.WriteString(hex.EncodeToString(b[:4]))
	buf.WriteByte('-')
	buf.WriteString(hex.EncodeToString(b[4:8]))
	buf.WriteByte('-')
	buf.WriteString(hex.EncodeToString(b[8:]))
	return buf.String()
}
