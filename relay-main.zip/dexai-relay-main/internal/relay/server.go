package relay

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"net/http"
	"strings"

	"app-relay/internal/db"
	"app-relay/internal/protocol"
	"github.com/coder/websocket"
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
)

// Config holds all relay server settings.
type Config struct {
	// Host is the relay's own hostname, e.g. "relay.mydomain.com".
	// Requests to this host are routed to the API / WebSocket handlers.
	Host string

	// Domain is the base domain used when generating subdomain URLs,
	// e.g. "mydomain.com" → "u1001-pos.mydomain.com".
	Domain string
	// PublicScheme is used for generated app URLs, e.g. "https" in production.
	PublicScheme string

	// Secret is the server-side HMAC secret used for token hashing.
	Secret string

	// Addr is the TCP listen address, e.g. ":8080".
	Addr string
}

// Server is the main app-relay relay server.
type Server struct {
	config   Config
	db       *db.DB
	registry *Registry
	router   *chi.Mux
	proxy    *Proxy
}

func NewServer(cfg Config, database *db.DB) *Server {
	s := &Server{
		config:   cfg,
		db:       database,
		registry: NewRegistry(),
	}
	s.proxy = NewProxy(s.registry)
	s.router = s.buildRouter()
	return s
}

func (s *Server) buildRouter() *chi.Mux {
	r := chi.NewRouter()
	r.Use(middleware.RealIP)
	r.Use(middleware.Recoverer)

	// Agent WebSocket endpoint
	r.Get("/tunnel/connect", s.handleAgentConnect)

	// REST management API
	r.Post("/api/register", s.handleRegister)
	r.Post("/api/apps", s.handleRegisterApp)
	r.Get("/api/apps", s.handleListApps)
	r.Patch("/api/apps/{slug}", s.handleUpdateApp)
	r.Delete("/api/apps/{slug}", s.handleDeleteApp)

	r.Get("/healthz", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("ok"))
	})

	return r
}

func (s *Server) publicURL(key string) string {
	scheme := s.config.PublicScheme
	if scheme == "" {
		scheme = "https"
	}
	return fmt.Sprintf("%s://%s.%s", scheme, key, s.config.Domain)
}

// ServeHTTP dispatches by hostname:
//   - relay's own host → API / WebSocket router
//   - any other host   → tunnel proxy (subdomain-based routing)
func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	host := r.Host
	if h, _, err := net.SplitHostPort(host); err == nil {
		host = h
	}
	host = strings.ToLower(strings.TrimSpace(host))

	relayHost := strings.ToLower(strings.TrimSpace(s.config.Host))
	if host == relayHost || host == "localhost" || host == "127.0.0.1" {
		s.router.ServeHTTP(w, r)
		return
	}

	// Extract the leftmost label as the subdomain key.
	// "u1001-pos.mydomain.com" → "u1001-pos"
	subdomainKey := strings.SplitN(host, ".", 2)[0]
	ctx := context.WithValue(r.Context(), ctxKeySubdomain, subdomainKey)
	s.proxy.ServeHTTP(w, r.WithContext(ctx))
}

func (s *Server) ListenAndServe() error {
	log.Printf("app-relay listening on %s (relay host: %s, domain: %s)",
		s.config.Addr, s.config.Host, s.config.Domain)
	return http.ListenAndServe(s.config.Addr, s)
}

// handleAgentConnect upgrades the connection to a WebSocket tunnel.
//
// GET /tunnel/connect?user_id=u1001&token=<token>
func (s *Server) handleAgentConnect(w http.ResponseWriter, r *http.Request) {
	userID := r.URL.Query().Get("user_id")
	token := r.URL.Query().Get("token")

	if !s.db.VerifyToken(userID, token, s.config.Secret) {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	conn, err := websocket.Accept(w, r, &websocket.AcceptOptions{
		// Allow all origins; TLS + token auth is the security boundary.
		InsecureSkipVerify: true,
	})
	if err != nil {
		// websocket.Accept already wrote the error response.
		return
	}
	defer conn.Close(websocket.StatusNormalClosure, "agent disconnected")
	conn.SetReadLimit(64 << 20)

	ctx := r.Context()

	// First frame must be AgentInit declaring which apps to advertise.
	_, data, err := conn.Read(ctx)
	if err != nil {
		return
	}
	var init protocol.AgentInit
	if err := json.Unmarshal(data, &init); err != nil {
		conn.Close(websocket.StatusUnsupportedData, "invalid init message")
		return
	}

	// Verify each advertised app is registered in the DB.
	verifiedApps := make(map[string]int, len(init.Apps))
	for slug := range init.Apps {
		app, err := s.db.GetApp(userID, slug)
		if err != nil || !app.Enabled {
			log.Printf("agent %s: skipping unregistered/disabled app %q", userID, slug)
			continue
		}
		verifiedApps[slug] = app.LocalPort
	}

	if len(verifiedApps) == 0 {
		conn.Close(websocket.StatusPolicyViolation, "no valid apps registered")
		return
	}

	keys := make([]string, 0, len(verifiedApps))
	for slug := range verifiedApps {
		keys = append(keys, fmt.Sprintf("%s-%s", userID, slug))
	}

	tunnel := newTunnel(userID, conn, verifiedApps)
	s.registry.Register(keys, tunnel)
	defer s.registry.DeregisterIfOwned(keys, tunnel)

	log.Printf("agent connected: user=%s apps=%v", userID, keys)

	// Read loop: agent sends TunnelResponse frames back to resolve pending proxies.
	for {
		_, data, err := conn.Read(ctx)
		if err != nil {
			log.Printf("agent disconnected: user=%s err=%v", userID, err)
			return
		}
		var resp protocol.TunnelResponse
		if err := json.Unmarshal(data, &resp); err != nil {
			log.Printf("agent %s: invalid response frame: %v", userID, err)
			continue
		}
		tunnel.resolve(resp.ID, &resp)
	}
}
