#!/usr/bin/env bash

set -euo pipefail

pid_file="${LLAMA_AGENT_APPS_PID_FILE:-/tmp/llama-agent-apps.pid}"

if [[ ! -f "$pid_file" ]]; then
    child_pids=()
else
    child_pids=()
fi

launcher_pid=""
if [[ -f "$pid_file" ]]; then
    while read -r role pid; do
        [[ -n "${pid:-}" ]] || continue
        if [[ "$role" == "launcher" ]]; then
            launcher_pid="$pid"
        else
            child_pids+=("$pid")
        fi
    done < "$pid_file"
fi

for pattern in 'pos_service.py serve' 'store_service.py serve' 'notification/whatsapp.py serve' 'app-relay-agent'; do
    while read -r pid; do
        [[ -n "$pid" ]] && child_pids+=("$pid")
    done < <(pgrep -f "$pattern" || true)
done

if [[ -z "$launcher_pid" && "${#child_pids[@]}" == "0" ]]; then
    echo "No running agent app stack found at $pid_file."
    exit 0
fi

if [[ -n "$launcher_pid" ]] && kill -0 "$launcher_pid" 2>/dev/null; then
    kill "$launcher_pid" 2>/dev/null || true
else
    for pid in "${child_pids[@]}"; do
        kill "$pid" 2>/dev/null || true
    done
fi

for _ in {1..50}; do
    running=0
    for pid in "$launcher_pid" "${child_pids[@]}"; do
        if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
            running=1
            break
        fi
    done
    if [[ "$running" == "0" ]]; then
        rm -f "$pid_file"
        echo "Agent app stack stopped."
        exit 0
    fi
    read -r -t 0.1 _ || true
done

echo "Agent app stack did not stop within 5 seconds; send SIGKILL to remaining PIDs if needed." >&2
exit 1
