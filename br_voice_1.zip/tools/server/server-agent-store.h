#pragma once

#include "server-common.h"
#include "server-http.h"

#include <memory>
#include <string>

class server_agent_store {
public:
    explicit server_agent_store(const std::string & path);
    ~server_agent_store();

    server_agent_store(const server_agent_store &) = delete;
    server_agent_store & operator=(const server_agent_store &) = delete;

    json get_definition(const std::string & id) const;

    server_http_context::handler_t handle_list;
    server_http_context::handler_t handle_get;
    server_http_context::handler_t handle_create;
    server_http_context::handler_t handle_update;
    server_http_context::handler_t handle_delete;

private:
    struct impl;
    std::unique_ptr<impl> pimpl;
};
