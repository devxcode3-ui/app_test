#pragma once

#include "server-http.h"

#include <memory>
#include <string>

struct notification_config {
    // SQLite database path (shared with agent_db is fine)
    std::string db_path;

    // Evolution API connection
    std::string evolution_url;       // e.g. "http://127.0.0.1:8080"
    std::string evolution_api_key;
    std::string evolution_instance;  // e.g. "business"

    // Optional stored agent ID — if empty, chat-only mode is used when tools are needed
    std::string agent_id;

    // Comma-separated sender JIDs allowed to interact, e.g. "919999@s.whatsapp.net,..."
    // Set to "all" to allow any sender (not recommended for production)
    std::string allowed_senders;

    // System prompt injected at the start of every conversation
    std::string system_prompt;

    // Max conversation turns kept per sender (user+assistant pairs)
    int max_history_turns = 10;

    // How often the scheduler checks for due outbound notifications (seconds)
    int scheduler_interval_s = 30;

    // Directory for saving received media files
    std::string media_dir;
};

class server_notification {
public:
    server_notification(
        server_http_context::handler_t chat_handler,
        server_http_context::handler_t classify_handler,
        server_http_context::handler_t agent_run_handler,  // may be empty/null
        const notification_config & cfg);
    ~server_notification();

    server_notification(const server_notification &) = delete;
    server_notification & operator=(const server_notification &) = delete;

    server_http_context::handler_t handle_webhook;          // POST /v1/whatsapp/webhook
    server_http_context::handler_t handle_notify;           // POST /v1/whatsapp/notify
    server_http_context::handler_t handle_broadcast;        // POST /v1/whatsapp/broadcast
    server_http_context::handler_t handle_get_health;       // GET  /v1/whatsapp/health
    server_http_context::handler_t handle_get_senders;      // GET  /v1/whatsapp/senders
    server_http_context::handler_t handle_get_conversations;// GET  /v1/whatsapp/conversations
    server_http_context::handler_t handle_get_scheduled;    // GET  /v1/whatsapp/scheduled
    server_http_context::handler_t handle_get_connection;   // GET  /v1/whatsapp/connection
    server_http_context::handler_t handle_connect;          // POST /v1/whatsapp/connect
    server_http_context::handler_t handle_disconnect;       // POST /v1/whatsapp/disconnect

private:
    struct impl;
    std::unique_ptr<impl> pimpl;
};
