#include "server-app-store.h"

#include <sqlite3.h>

#include <chrono>
#include <cctype>
#include <mutex>
#include <set>
#include <stdexcept>
#include <vector>

namespace {

constexpr size_t APP_ID_MAX_BYTES = 64;
constexpr size_t APP_NAME_MAX_BYTES = 100;
constexpr size_t APP_DESCRIPTION_MAX_BYTES = 1024;
constexpr size_t APP_URL_MAX_BYTES = 2048;
constexpr size_t APP_PROMPT_FIELD_MAX_BYTES = 16 * 1024;
constexpr size_t APP_ENTITY_MAX_BYTES = 128;
constexpr size_t APP_TOOL_NAME_MAX_BYTES = 128;
constexpr size_t APP_ENTITIES_MAX = 64;
constexpr size_t APP_TOOLS_MAX = 32;
constexpr size_t APP_DEFINITIONS_MAX = 256;
constexpr size_t APP_DEFINITION_BODY_MAX_BYTES = 64 * 1024;

int64_t now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

bool valid_id(const std::string & id) {
    if (id.empty() || id.size() > APP_ID_MAX_BYTES) {
        return false;
    }
    for (unsigned char value : id) {
        if (!std::isalnum(value) && value != '-' && value != '_') {
            return false;
        }
    }
    return true;
}

bool valid_launch_url(const std::string & url) {
    if (url.empty() || url.size() > APP_URL_MAX_BYTES) {
        return false;
    }
    return url.rfind("http://", 0) == 0 || url.rfind("https://", 0) == 0;
}

void validate_string_list(
        const std::vector<std::string> & values,
        size_t max_count,
        size_t max_bytes,
        const std::string & field,
        bool require_value) {
    if ((require_value && values.empty()) || values.size() > max_count) {
        throw std::invalid_argument(field + " must contain " + (require_value ? "1 to " : "at most ") + std::to_string(max_count) + " values");
    }
    std::set<std::string> unique;
    for (const std::string & value : values) {
        if (value.empty() || value.size() > max_bytes) {
            throw std::invalid_argument(field + " values must contain 1 to " + std::to_string(max_bytes) + " bytes");
        }
        if (!unique.insert(value).second) {
            throw std::invalid_argument(field + " values must be unique");
        }
    }
}

json validate_definition(const json & input, const std::string & path_id = {}) {
    if (!input.is_object()) {
        throw std::invalid_argument("app definition must be an object");
    }
    const std::set<std::string> fields = {
        "schema_version", "id", "name", "description", "launch_url", "agent_id", "tools", "prompt", "online_enabled", "online_url",
        "built_in", "created_at", "updated_at",
    };
    for (const auto & item : input.items()) {
        if (fields.find(item.key()) == fields.end()) {
            throw std::invalid_argument("unknown app definition field: " + item.key());
        }
    }
    if (input.value("schema_version", 1) != 1) {
        throw std::invalid_argument("schema_version must be 1");
    }

    std::string id = input.value("id", path_id);
    if (id.empty()) {
        id = "app-" + random_string();
    }
    if (!path_id.empty() && id != path_id) {
        throw std::invalid_argument("app definition id does not match the request path");
    }
    if (!valid_id(id)) {
        throw std::invalid_argument("id must contain 1 to 64 letters, numbers, dashes, or underscores");
    }

    const std::string name = input.at("name").get<std::string>();
    const std::string description = input.value("description", "");
    const std::string launch_url = input.at("launch_url").get<std::string>();
    const std::string agent_id = input.value("agent_id", "");
    const bool online_enabled = input.value("online_enabled", false);
    const std::string online_url = input.value("online_url", "");
    if (name.empty() || name.size() > APP_NAME_MAX_BYTES) {
        throw std::invalid_argument("name must contain 1 to 100 bytes");
    }
    if (description.size() > APP_DESCRIPTION_MAX_BYTES) {
        throw std::invalid_argument("description must contain at most 1024 bytes");
    }
    if (!valid_launch_url(launch_url)) {
        throw std::invalid_argument("launch_url must be an HTTP or HTTPS URL containing at most 2048 bytes");
    }
    if (!agent_id.empty() && !valid_id(agent_id)) {
        throw std::invalid_argument("agent_id must contain at most 64 letters, numbers, dashes, or underscores");
    }

    const std::vector<std::string> tools = input.at("tools").get<std::vector<std::string>>();
    validate_string_list(tools, APP_TOOLS_MAX, APP_TOOL_NAME_MAX_BYTES, "tools", true);

    const json prompt = input.at("prompt");
    if (!prompt.is_object()) {
        throw std::invalid_argument("prompt must be an object");
    }
    const std::set<std::string> prompt_fields = {"domain", "entities", "instructions"};
    for (const auto & item : prompt.items()) {
        if (prompt_fields.find(item.key()) == prompt_fields.end()) {
            throw std::invalid_argument("unknown app prompt field: " + item.key());
        }
    }
    const std::string domain = prompt.at("domain").get<std::string>();
    const std::string instructions = prompt.at("instructions").get<std::string>();
    const std::vector<std::string> entities = prompt.at("entities").get<std::vector<std::string>>();
    if (domain.empty() || domain.size() > APP_PROMPT_FIELD_MAX_BYTES) {
        throw std::invalid_argument("prompt.domain must contain 1 to 16384 bytes");
    }
    if (instructions.empty() || instructions.size() > APP_PROMPT_FIELD_MAX_BYTES) {
        throw std::invalid_argument("prompt.instructions must contain 1 to 16384 bytes");
    }
    validate_string_list(entities, APP_ENTITIES_MAX, APP_ENTITY_MAX_BYTES, "prompt.entities", true);

    return {
        {"schema_version", 1},
        {"id", id},
        {"name", name},
        {"description", description},
        {"launch_url", launch_url},
        {"agent_id", agent_id},
        {"online_enabled", online_enabled},
        {"online_url", online_url},
        {"tools", tools},
        {"prompt", {
            {"domain", domain},
            {"entities", entities},
            {"instructions", instructions},
        }},
    };
}

server_http_res_ptr json_response(const json & body, int status = 200) {
    auto response = std::make_unique<server_http_res>();
    response->status = status;
    response->data = safe_json_to_str(body);
    return response;
}

server_http_res_ptr error_response(const std::string & message, int status) {
    const error_type type = status == 400 || status == 409 ? ERROR_TYPE_INVALID_REQUEST : ERROR_TYPE_SERVER;
    json error = format_error_response(message, type);
    error["code"] = status;
    return json_response({{"error", error}}, status);
}

class sqlite_statement {
public:
    sqlite_statement(sqlite3 * db, const char * sql) {
        if (sqlite3_prepare_v2(db, sql, -1, &statement, nullptr) != SQLITE_OK) {
            throw std::runtime_error("failed to prepare app database statement");
        }
    }
    ~sqlite_statement() { sqlite3_finalize(statement); }
    sqlite3_stmt * get() const { return statement; }

private:
    sqlite3_stmt * statement = nullptr;
};

void bind_text(sqlite3_stmt * statement, int index, const std::string & value) {
    if (sqlite3_bind_text(statement, index, value.c_str(), (int) value.size(), SQLITE_TRANSIENT) != SQLITE_OK) {
        throw std::runtime_error("failed to bind app database value");
    }
}

json read_definition(sqlite3_stmt * statement) {
    const auto text = [statement](int index) {
        const char * value = reinterpret_cast<const char *>(sqlite3_column_text(statement, index));
        return value ? std::string(value) : std::string();
    };
    return {
        {"schema_version", 1},
        {"id", text(0)},
        {"name", text(1)},
        {"description", text(2)},
        {"launch_url", text(3)},
        {"agent_id", text(4)},
        {"tools", json::parse(text(5))},
        {"prompt", {
            {"domain", text(6)},
            {"entities", json::parse(text(7))},
            {"instructions", text(8)},
        }},
        {"built_in", sqlite3_column_int(statement, 9) != 0},
        {"created_at", sqlite3_column_int64(statement, 10)},
        {"updated_at", sqlite3_column_int64(statement, 11)},
        {"online_enabled", sqlite3_column_int(statement, 12) != 0},
        {"online_url", text(13)},
    };
}

} // namespace

struct server_app_store::impl {
    sqlite3 * db = nullptr;
    mutable std::mutex mutex;

    explicit impl(const std::string & path) {
        const int flags = SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX;
        if (sqlite3_open_v2(path.c_str(), &db, flags, nullptr) != SQLITE_OK) {
            const std::string message = db ? sqlite3_errmsg(db) : "unknown error";
            if (db) {
                sqlite3_close(db);
                db = nullptr;
            }
            throw std::runtime_error("failed to open app database: " + message);
        }
        execute("PRAGMA busy_timeout = 5000");
        execute("PRAGMA journal_mode = WAL");
        execute("CREATE TABLE IF NOT EXISTS app_definitions ("
                "id TEXT PRIMARY KEY,"
                "name TEXT NOT NULL,"
                "description TEXT NOT NULL,"
                "launch_url TEXT NOT NULL,"
                "agent_id TEXT NOT NULL,"
                "tools_json TEXT NOT NULL,"
                "prompt_domain TEXT NOT NULL,"
                "prompt_entities_json TEXT NOT NULL,"
                "prompt_instructions TEXT NOT NULL,"
                "built_in INTEGER NOT NULL DEFAULT 0,"
                "created_at INTEGER NOT NULL,"
                "updated_at INTEGER NOT NULL,"
                "online_enabled INTEGER NOT NULL DEFAULT 0,"
                "online_url TEXT NOT NULL DEFAULT ''"
                ")");
        try {
            execute("ALTER TABLE app_definitions ADD COLUMN online_enabled INTEGER NOT NULL DEFAULT 0");
        } catch (const std::runtime_error &) {
        }
        try {
            execute("ALTER TABLE app_definitions ADD COLUMN online_url TEXT NOT NULL DEFAULT ''");
        } catch (const std::runtime_error &) {
        }
        seed_pos_app();
    }

    ~impl() {
        if (db) sqlite3_close(db);
    }

    void execute(const char * sql) {
        char * error = nullptr;
        if (sqlite3_exec(db, sql, nullptr, nullptr, &error) != SQLITE_OK) {
            const std::string message = error ? error : "unknown error";
            sqlite3_free(error);
            throw std::runtime_error("app database operation failed: " + message);
        }
    }

    static void bind_definition(sqlite3_stmt * statement, const json & definition) {
        bind_text(statement, 1, definition.at("id").get<std::string>());
        bind_text(statement, 2, definition.at("name").get<std::string>());
        bind_text(statement, 3, definition.at("description").get<std::string>());
        bind_text(statement, 4, definition.at("launch_url").get<std::string>());
        bind_text(statement, 5, definition.at("agent_id").get<std::string>());
        bind_text(statement, 6, definition.at("tools").dump());
        const json & prompt = definition.at("prompt");
        bind_text(statement, 7, prompt.at("domain").get<std::string>());
        bind_text(statement, 8, prompt.at("entities").dump());
        bind_text(statement, 9, prompt.at("instructions").get<std::string>());
    }

    void seed_pos_app() {
        const json pos_definition = validate_definition({
            {"id", "pos_app"},
            {"name", "POS / Billing"},
            {"description", "Sales, billing, inventory, and product reporting."},
            {"launch_url", "http://127.0.0.1:4174"},
            {"agent_id", "pos-agent"},
            {"tools", {"pos_sales_summary", "pos_top_selling_items", "pos_inventory_status"}},
            {"prompt", {
                {"domain", "Point-of-sale reporting. Sales are completed bills. Revenue is the sum of line totals after line-level discounts."},
                {"entities", {"sale", "sale_item", "product", "inventory", "customer"}},
                {"instructions", "Use only POS tools for POS facts. Treat today as the server-local calendar day. Treat last month as the previous calendar month. Rank best-selling items by quantity unless the user asks for revenue. State the reporting period and never invent missing values."},
            }},
        });
        sqlite_statement pos_statement(db,
            "INSERT OR IGNORE INTO app_definitions "
            "(id, name, description, launch_url, agent_id, tools_json, prompt_domain, prompt_entities_json, prompt_instructions, built_in, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)");
        bind_definition(pos_statement.get(), pos_definition);
        const int64_t timestamp = now_ms();
        sqlite3_bind_int64(pos_statement.get(), 10, timestamp);
        sqlite3_bind_int64(pos_statement.get(), 11, timestamp);
        if (sqlite3_step(pos_statement.get()) != SQLITE_DONE) {
            throw std::runtime_error("failed to seed POS app");
        }

        const json store_definition = validate_definition({
            {"id", "store_app"},
            {"name", "Online Store"},
            {"description", "Product catalog, categories, and orders for the online storefront."},
            {"launch_url", "http://127.0.0.1:4175"},
            {"agent_id", "store-agent"},
            {"tools", {"store_list_products", "store_inventory_status", "store_add_product", "store_update_product", "store_list_orders", "store_add_order", "store_list_categories", "store_add_category"}},
            {"prompt", {
                {"domain", "Online storefront operations. Products and categories support merchandising, while orders track customer purchases and fulfillment."},
                {"entities", {"product", "category", "order", "customer", "inventory"}},
                {"instructions", "Use only store tools for storefront facts. Prefer product and order records from the store database. State totals in the local currency and be explicit when a product or order is missing."},
            }},
        });
        sqlite_statement store_statement(db,
            "INSERT OR IGNORE INTO app_definitions "
            "(id, name, description, launch_url, agent_id, tools_json, prompt_domain, prompt_entities_json, prompt_instructions, built_in, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)");
        bind_definition(store_statement.get(), store_definition);
        sqlite3_bind_int64(store_statement.get(), 10, timestamp);
        sqlite3_bind_int64(store_statement.get(), 11, timestamp);
        if (sqlite3_step(store_statement.get()) != SQLITE_DONE) {
            throw std::runtime_error("failed to seed store app");
        }
    }

    json find_locked(const std::string & id) const {
        sqlite_statement statement(db,
            "SELECT id, name, description, launch_url, agent_id, tools_json, prompt_domain, prompt_entities_json, prompt_instructions, built_in, created_at, updated_at, online_enabled, online_url "
            "FROM app_definitions WHERE id = ?");
        bind_text(statement.get(), 1, id);
        return sqlite3_step(statement.get()) == SQLITE_ROW ? read_definition(statement.get()) : json(nullptr);
    }

    json find(const std::string & id) const {
        std::lock_guard<std::mutex> lock(mutex);
        return find_locked(id);
    }

    json list() const {
        std::lock_guard<std::mutex> lock(mutex);
        sqlite_statement statement(db,
            "SELECT id, name, description, launch_url, agent_id, tools_json, prompt_domain, prompt_entities_json, prompt_instructions, built_in, created_at, updated_at, online_enabled, online_url "
            "FROM app_definitions ORDER BY built_in DESC, name COLLATE NOCASE, id");
        json result = json::array();
        int status;
        while ((status = sqlite3_step(statement.get())) == SQLITE_ROW) {
            result.push_back(read_definition(statement.get()));
        }
        if (status != SQLITE_DONE) throw std::runtime_error("failed to list app definitions");
        return result;
    }

    json create(const json & input) {
        const json definition = validate_definition(input);
        std::lock_guard<std::mutex> lock(mutex);
        sqlite_statement count_statement(db, "SELECT COUNT(*) FROM app_definitions");
        if (sqlite3_step(count_statement.get()) != SQLITE_ROW) throw std::runtime_error("failed to count app definitions");
        if (sqlite3_column_int64(count_statement.get(), 0) >= static_cast<int64_t>(APP_DEFINITIONS_MAX)) {
            throw std::invalid_argument("app definition limit reached");
        }
        sqlite_statement statement(db,
            "INSERT INTO app_definitions "
            "(id, name, description, launch_url, agent_id, tools_json, prompt_domain, prompt_entities_json, prompt_instructions, built_in, created_at, updated_at, online_enabled, online_url) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)");
        bind_definition(statement.get(), definition);
        const int64_t timestamp = now_ms();
        sqlite3_bind_int64(statement.get(), 10, timestamp);
        sqlite3_bind_int64(statement.get(), 11, timestamp);
        sqlite3_bind_int(statement.get(), 12, definition.value("online_enabled", false) ? 1 : 0);
        bind_text(statement.get(), 13, definition.value("online_url", ""));
        const int status = sqlite3_step(statement.get());
        if (status == SQLITE_CONSTRAINT) throw std::invalid_argument("an app with this id already exists");
        if (status != SQLITE_DONE) throw std::runtime_error("failed to create app definition");
        return find_locked(definition.at("id").get<std::string>());
    }

    json update(const std::string & id, const json & input) {
        const json definition = validate_definition(input, id);
        std::lock_guard<std::mutex> lock(mutex);
        sqlite_statement statement(db,
            "UPDATE app_definitions SET name = ?, description = ?, launch_url = ?, agent_id = ?, tools_json = ?, prompt_domain = ?, prompt_entities_json = ?, prompt_instructions = ?, updated_at = ?, online_enabled = ?, online_url = ? WHERE id = ?");
        bind_text(statement.get(), 1, definition.at("name").get<std::string>());
        bind_text(statement.get(), 2, definition.at("description").get<std::string>());
        bind_text(statement.get(), 3, definition.at("launch_url").get<std::string>());
        bind_text(statement.get(), 4, definition.at("agent_id").get<std::string>());
        bind_text(statement.get(), 5, definition.at("tools").dump());
        const json & prompt = definition.at("prompt");
        bind_text(statement.get(), 6, prompt.at("domain").get<std::string>());
        bind_text(statement.get(), 7, prompt.at("entities").dump());
        bind_text(statement.get(), 8, prompt.at("instructions").get<std::string>());
        sqlite3_bind_int64(statement.get(), 9, now_ms());
        sqlite3_bind_int(statement.get(), 10, definition.value("online_enabled", false) ? 1 : 0);
        bind_text(statement.get(), 11, definition.value("online_url", ""));
        bind_text(statement.get(), 12, id);
        if (sqlite3_step(statement.get()) != SQLITE_DONE) throw std::runtime_error("failed to update app definition");
        return sqlite3_changes(db) == 0 ? json(nullptr) : find_locked(id);
    }

    int remove(const std::string & id) {
        std::lock_guard<std::mutex> lock(mutex);
        const json existing = find_locked(id);
        if (existing.is_null()) return 0;
        if (existing.value("built_in", false)) return -1;
        sqlite_statement statement(db, "DELETE FROM app_definitions WHERE id = ?");
        bind_text(statement.get(), 1, id);
        if (sqlite3_step(statement.get()) != SQLITE_DONE) throw std::runtime_error("failed to delete app definition");
        return sqlite3_changes(db);
    }
};

server_app_store::server_app_store(const std::string & path)
    : pimpl(std::make_unique<impl>(path)) {
    handle_list = [this](const server_http_req &) -> server_http_res_ptr {
        return json_response({{"apps", pimpl->list()}});
    };
    handle_get = [this](const server_http_req & req) -> server_http_res_ptr {
        const json definition = pimpl->find(req.get_param("id"));
        return definition.is_null() ? error_response("app not found", 404) : json_response(definition);
    };
    handle_create = [this](const server_http_req & req) -> server_http_res_ptr {
        try {
            if (req.body.size() > APP_DEFINITION_BODY_MAX_BYTES) throw std::invalid_argument("app definition must contain at most 65536 bytes");
            return json_response(pimpl->create(json::parse(req.body)), 201);
        } catch (const json::exception & e) {
            return error_response(e.what(), 400);
        } catch (const std::invalid_argument & e) {
            const int status = std::string(e.what()).find("already exists") != std::string::npos ? 409 : 400;
            return error_response(e.what(), status);
        }
    };
    handle_update = [this](const server_http_req & req) -> server_http_res_ptr {
        try {
            if (req.body.size() > APP_DEFINITION_BODY_MAX_BYTES) throw std::invalid_argument("app definition must contain at most 65536 bytes");
            const json definition = pimpl->update(req.get_param("id"), json::parse(req.body));
            return definition.is_null() ? error_response("app not found", 404) : json_response(definition);
        } catch (const json::exception & e) {
            return error_response(e.what(), 400);
        } catch (const std::invalid_argument & e) {
            return error_response(e.what(), 400);
        }
    };
    handle_delete = [this](const server_http_req & req) -> server_http_res_ptr {
        const int removed = pimpl->remove(req.get_param("id"));
        if (removed < 0) return error_response("built-in apps cannot be deleted", 400);
        if (removed == 0) return error_response("app not found", 404);
        auto response = std::make_unique<server_http_res>();
        response->status = 204;
        return response;
    };
}

server_app_store::~server_app_store() = default;

json server_app_store::get_definition(const std::string & id) const {
    return valid_id(id) ? pimpl->find(id) : json(nullptr);
}
