#pragma once

#include "server-http.h"
#include "server-tool-registry.h"

#include <memory>

class server_query_processor {
public:
    server_query_processor(server_http_context::handler_t chat_handler, server_tool_registry & registry);
    ~server_query_processor();
    server_query_processor(const server_query_processor &) = delete;
    server_query_processor & operator=(const server_query_processor &) = delete;

    server_http_context::handler_t handle_post;

private:
    struct impl;
    std::unique_ptr<impl> pimpl;
};
