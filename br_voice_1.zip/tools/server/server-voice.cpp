// server-voice.cpp — voice transcription bridge for dexai
//
// Two transcription paths:
//
//   Path A (standalone Whisper — preferred):
//     Enabled when DEXAI_HAS_WHISPER is defined and --voice-model is set.
//     Loads a whisper GGUF model directly. No multimodal LLM required.
//     Run tools/server/whisper/get-whisper.sh to download whisper source,
//     then rebuild to enable this path.
//
//   Path B (internal handler fallback):
//     Calls the existing /v1/audio/transcriptions handler.
//     Requires a multimodal audio-capable model to be loaded (e.g. Qwen2-Audio).
//
// VAD logic (high_pass_filter + vad_simple) copied from
// whisper.cpp examples/common.cpp — MIT License, ggerganov

#include "server-voice.h"
#include "server-common.h"
#include "server-http.h"
#include "log.h"

#ifdef DEXAI_HAS_WHISPER
#include "whisper/whisper.h"
#endif

// miniaudio is implemented in the mtmd helper library. Include the declaration
// surface here without creating another implementation so the voice path links to
// the shared library symbols.
#define MA_NO_DEVICE_IO
#define MA_NO_RESOURCE_MANAGER
#define MA_NO_NODE_GRAPH
#define MA_NO_ENGINE
#define MA_NO_GENERATION
#include "vendor/miniaudio/miniaudio.h"

#include <nlohmann/json.hpp>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

// ---------------------------------------------------------------------------
// Indian language table
// ---------------------------------------------------------------------------

struct lang_entry {
    const char * code;
    const char * name;
    const char * native;
    const char * quality; // quality with whisper-medium base model
};

static constexpr lang_entry INDIAN_LANGS[] = {
    {"hi", "Hindi",    "हिन्दी",   "excellent"},
    {"bn", "Bengali",  "বাংলা",    "good"},
    {"or", "Odia",     "ଓଡ଼ିଆ",   "fair — use IndicWhisper for best results"},
    {"pa", "Punjabi",  "ਪੰਜਾਬੀ",  "good"},
    {"gu", "Gujarati", "ગુજરાતી", "good"},
};
static constexpr int N_INDIAN_LANGS = (int)(sizeof(INDIAN_LANGS) / sizeof(INDIAN_LANGS[0]));

// ---------------------------------------------------------------------------
// base64 decode
// ---------------------------------------------------------------------------

static std::vector<uint8_t> b64_decode(const std::string & in) {
    static const std::string T =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::vector<uint8_t> out;
    out.reserve(in.size() * 3 / 4);
    int val = 0, bits = -8;
    for (unsigned char c : in) {
        if (c == '=') break;
        auto p = T.find(c);
        if (p == std::string::npos) continue;
        val = (val << 6) | (int)p;
        bits += 6;
        if (bits >= 0) {
            out.push_back(static_cast<uint8_t>((val >> bits) & 0xFF));
            bits -= 8;
        }
    }
    return out;
}

// ---------------------------------------------------------------------------
// Audio decoding: any format → mono PCM float32 via miniaudio
// ---------------------------------------------------------------------------

static std::vector<float> decode_to_pcm(const uint8_t * data, size_t size,
                                         int target_sr, int max_dur_s,
                                         std::string & err) {
    ma_decoder_config cfg = ma_decoder_config_init(ma_format_f32, 1, (ma_uint32)target_sr);
    ma_decoder dec;
    if (ma_decoder_init_memory(data, size, &cfg, &dec) != MA_SUCCESS) {
        err = "unsupported audio format";
        return {};
    }
    ma_uint64 n_frames = 0;
    ma_decoder_get_length_in_pcm_frames(&dec, &n_frames);
    const ma_uint64 max_frames = (ma_uint64)max_dur_s * (ma_uint64)target_sr;
    if (n_frames > max_frames) {
        ma_decoder_uninit(&dec);
        err = "audio exceeds max duration (" + std::to_string(max_dur_s) + "s)";
        return {};
    }
    if (n_frames == 0) { n_frames = max_frames; } // streaming format: read up to max
    std::vector<float> pcm(n_frames);
    ma_uint64 read = 0;
    ma_decoder_read_pcm_frames(&dec, pcm.data(), n_frames, &read);
    pcm.resize(read);
    ma_decoder_uninit(&dec);
    if (pcm.empty()) { err = "no audio frames decoded"; }
    return pcm;
}

// ---------------------------------------------------------------------------
// WAV encoder: PCM float32 → mono 16-bit WAV bytes
// ---------------------------------------------------------------------------

static void push_le16(std::vector<uint8_t> & b, uint16_t v) {
    b.push_back(v & 0xFF);
    b.push_back((v >> 8) & 0xFF);
}
static void push_le32(std::vector<uint8_t> & b, uint32_t v) {
    b.push_back(v & 0xFF);
    b.push_back((v >> 8) & 0xFF);
    b.push_back((v >> 16) & 0xFF);
    b.push_back((v >> 24) & 0xFF);
}

static std::vector<uint8_t> pcm_to_wav(const std::vector<float> & pcm, int sr) {
    const uint32_t n    = (uint32_t)pcm.size();
    const uint32_t dlen = n * 2; // int16
    std::vector<uint8_t> wav;
    wav.reserve(44 + dlen);
    wav.insert(wav.end(), {'R','I','F','F'});
    push_le32(wav, 36 + dlen);
    wav.insert(wav.end(), {'W','A','V','E','f','m','t',' '});
    push_le32(wav, 16);
    push_le16(wav, 1);              // PCM
    push_le16(wav, 1);              // mono
    push_le32(wav, (uint32_t)sr);
    push_le32(wav, (uint32_t)sr * 2);
    push_le16(wav, 2);              // block align
    push_le16(wav, 16);             // bits
    wav.insert(wav.end(), {'d','a','t','a'});
    push_le32(wav, dlen);
    for (float s : pcm) {
        float c = s < -1.0f ? -1.0f : (s > 1.0f ? 1.0f : s);
        int16_t i16 = (int16_t)(c * 32767.0f);
        wav.push_back((uint8_t)(i16 & 0xFF));
        wav.push_back((uint8_t)((i16 >> 8) & 0xFF));
    }
    return wav;
}

// ---------------------------------------------------------------------------
// VAD — copied from whisper.cpp examples/common.cpp (MIT License)
// ---------------------------------------------------------------------------

static void high_pass_filter(std::vector<float> & data, float cutoff, float sr) {
    static constexpr float pi = 3.14159265358979323846f;
    const float rc    = 1.0f / (2.0f * pi * cutoff);
    const float dt    = 1.0f / sr;
    const float alpha = dt / (rc + dt);
    float y = data[0];
    for (size_t i = 1; i < data.size(); ++i) {
        y       = alpha * (y + data[i] - data[i - 1]);
        data[i] = y;
    }
}

// Returns true when the tail of the buffer is silent (utterance has ended).
static bool vad_simple(std::vector<float> & pcm, int sr, int last_ms,
                        float vad_thold, float freq_thold) {
    const int n            = (int)pcm.size();
    const int n_last       = (sr * last_ms) / 1000;
    if (n_last >= n) { return false; }
    if (freq_thold > 0.0f) { high_pass_filter(pcm, freq_thold, (float)sr); }
    float e_all = 0.0f, e_last = 0.0f;
    for (int i = 0; i < n; ++i) {
        e_all += fabsf(pcm[i]);
        if (i >= n - n_last) { e_last += fabsf(pcm[i]); }
    }
    e_all  /= n;
    e_last /= n_last;
    return e_last <= vad_thold * e_all;
}

// ---------------------------------------------------------------------------
// Call the existing /v1/audio/transcriptions handler internally
// ---------------------------------------------------------------------------

static std::string call_transcribe(const server_http_context::handler_t & h,
                                    std::vector<uint8_t>                   wav,
                                    const std::string                    & lang,
                                    const std::function<bool()>          & stop) {
    if (!h || wav.empty()) { return ""; }

    uploaded_file uf;
    uf.data         = std::move(wav);
    uf.filename     = "audio.wav";
    uf.content_type = "audio/wav";

    std::map<std::string, std::string> params;
    params["response_format"] = "json";
    if (!lang.empty()) { params["language"] = lang; }

    server_http_req req{
        params, {}, "/v1/audio/transcriptions", {},
        {}, {{"file", std::move(uf)}}, stop,
    };

    auto res = h(req);
    if (!res || res->status != 200) { return ""; }
    try {
        return json::parse(res->data).value("text", "");
    } catch (...) {
        return "";
    }
}

// ---------------------------------------------------------------------------
// PCM16 chunk → float32 (for streaming endpoint)
// Browser sends raw PCM16 little-endian at 16 kHz
// ---------------------------------------------------------------------------

static std::vector<float> pcm16_to_f32(const uint8_t * data, size_t n_bytes) {
    const size_t n = n_bytes / 2;
    std::vector<float> out(n);
    for (size_t i = 0; i < n; ++i) {
        int16_t s;
        std::memcpy(&s, data + i * 2, 2);
        out[i] = (float)s / 32768.0f;
    }
    return out;
}

// ---------------------------------------------------------------------------
// Session state for streaming endpoint
// ---------------------------------------------------------------------------

struct voice_session {
    std::vector<float>                        pcm_buf;
    std::chrono::steady_clock::time_point     last_activity;
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

static int resolve_threads(int n) {
    if (n > 0) { return n; }
    const int hw = (int)std::thread::hardware_concurrency();
    if (hw <= 1) { return 1; }
    return hw > 4 ? hw / 2 : hw - 1;
}

// ---------------------------------------------------------------------------
// Standalone Whisper inference (Path A)
// Only compiled when DEXAI_HAS_WHISPER is defined.
// ---------------------------------------------------------------------------

#ifdef DEXAI_HAS_WHISPER

// Run whisper_full() on PCM float32 and collect all segment text.
static std::string whisper_run(whisper_context * wctx,
                                const std::vector<float> & pcm,
                                const std::string & lang,
                                int n_threads) {
    auto wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.n_threads          = resolve_threads(n_threads);
    wp.language           = lang.empty() ? "auto" : lang.c_str();
    wp.translate          = false;
    wp.no_context         = true;
    wp.single_segment     = false;
    wp.print_realtime     = false;
    wp.print_progress     = false;
    wp.print_timestamps   = false;
    wp.print_special      = false;
    wp.suppress_blank     = true;
    wp.suppress_nst       = true;

    if (whisper_full(wctx, wp, pcm.data(), (int)pcm.size()) != 0) {
        return "";
    }

    std::string out;
    const int n = whisper_full_n_segments(wctx);
    for (int i = 0; i < n; ++i) {
        const char * t = whisper_full_get_segment_text(wctx, i);
        if (t) { out += t; }
    }

    // Trim surrounding whitespace
    const auto s = out.find_first_not_of(" \t\r\n");
    if (s == std::string::npos) { return ""; }
    const auto e = out.find_last_not_of(" \t\r\n");
    return out.substr(s, e - s + 1);
}

#endif // DEXAI_HAS_WHISPER

// ---------------------------------------------------------------------------
// pimpl
// ---------------------------------------------------------------------------

struct server_voice::impl {
    server_http_context::handler_t transcribe_handler; // Path B fallback
    voice_config                   cfg;

#ifdef DEXAI_HAS_WHISPER
    whisper_context * wctx = nullptr; // Path A — standalone Whisper
#endif

    std::map<std::string, voice_session> sessions;
    std::mutex                           sessions_mtx;

    // Background thread removes stale sessions every 60 s
    std::thread                     gc_thread;
    std::atomic<bool>               stop_flag{false};

    impl(server_http_context::handler_t h, const voice_config & c)
        : transcribe_handler(std::move(h)), cfg(c)
    {
#ifdef DEXAI_HAS_WHISPER
        if (!cfg.model_path.empty()) {
            auto cp     = whisper_context_default_params();
            cp.use_gpu  = false;   // CPU-only; GPU support can be added later
            wctx = whisper_init_from_file_with_params(cfg.model_path.c_str(), cp);
            if (!wctx) {
                throw std::runtime_error(
                    "server_voice: failed to load Whisper model: " + cfg.model_path);
            }
            SRV_INF("voice: loaded Whisper model '%s' (%d threads)\n",
                    cfg.model_path.c_str(), resolve_threads(cfg.n_threads));
        }
#else
        if (!cfg.model_path.empty()) {
            SRV_WRN("%s", "voice: --voice-model set but standalone Whisper not compiled. "
                           "Run tools/server/whisper/get-whisper.sh then rebuild.\n");
        }
#endif
        gc_thread = std::thread([this] {
            while (!stop_flag.load()) {
                std::this_thread::sleep_for(std::chrono::seconds(60));
                auto now = std::chrono::steady_clock::now();
                std::lock_guard<std::mutex> lk(sessions_mtx);
                for (auto it = sessions.begin(); it != sessions.end(); ) {
                    if (now - it->second.last_activity > std::chrono::seconds(120)) {
                        it = sessions.erase(it);
                    } else {
                        ++it;
                    }
                }
            }
        });
    }

    ~impl() {
        stop_flag.store(true);
        if (gc_thread.joinable()) { gc_thread.join(); }
#ifdef DEXAI_HAS_WHISPER
        if (wctx) { whisper_free(wctx); }
#endif
    }

    // Central transcription: tries Path A (standalone Whisper) then Path B (handler).
    std::string transcribe(const std::vector<float> & pcm,
                            const std::string & lang,
                            const std::function<bool()> & stop) const {
#ifdef DEXAI_HAS_WHISPER
        if (wctx) {
            return whisper_run(wctx, pcm, lang, cfg.n_threads);
        }
#endif
        // Path B: encode as WAV and call the internal transcription handler
        auto wav = pcm_to_wav(pcm, cfg.sample_rate);
        return call_transcribe(transcribe_handler, std::move(wav), lang, stop);
    }

    bool has_transcription() const {
#ifdef DEXAI_HAS_WHISPER
        if (wctx) { return true; }
#endif
        return transcribe_handler ? true : false;
    }

    std::string active_path() const {
#ifdef DEXAI_HAS_WHISPER
        if (wctx) { return "standalone-whisper"; }
#endif
        return transcribe_handler ? "internal-handler" : "none";
    }
};

// ---------------------------------------------------------------------------
// server_voice constructor — wires up all handlers
// ---------------------------------------------------------------------------

server_voice::server_voice(server_http_context::handler_t transcribe_handler,
                            const voice_config & cfg)
    : pimpl(std::make_unique<impl>(std::move(transcribe_handler), cfg))
{
    // -----------------------------------------------------------------------
    // POST /v1/voice/transcribe
    //
    // Accepts one of:
    //   (a) multipart/form-data with "file" field  (browser file upload)
    //   (b) JSON { "audio_base64": "...", "language": "hi" }  (WhatsApp bridge)
    //
    // Returns: { "text": "transcribed text", "language": "hi" }
    // -----------------------------------------------------------------------
    handle_transcribe = [this](const server_http_req & req) -> server_http_res_ptr {
        SRV_DBG("voice message received: multipart=%s json_bytes=%zu\n",
            req.files.empty() ? "false" : "true", req.body.size());
        std::string language = req.get_param("language", pimpl->cfg.default_language);
        std::string err;
        std::vector<float> pcm;

        // --- multipart path ---
        if (!req.files.empty()) {
            auto it = req.files.find("file");
            if (it != req.files.end()) {
                // override language param if supplied in form
                const auto lp = req.params.find("language");
                if (lp != req.params.end()) { language = lp->second; }
                pcm = decode_to_pcm(it->second.data.data(), it->second.data.size(),
                                    pimpl->cfg.sample_rate, pimpl->cfg.max_duration_s, err);
            }
        }

        // --- JSON body path ---
        if (pcm.empty() && err.empty() && !req.body.empty()) {
            json j;
            try { j = json::parse(req.body); } catch (...) {
                auto r = std::make_unique<server_http_res>();
                r->status = 400;
                r->data   = json{{"error", "invalid JSON body"}}.dump();
                return r;
            }
            const std::string ab64 = j.value("audio_base64", "");
            if (ab64.empty()) {
                auto r = std::make_unique<server_http_res>();
                r->status = 400;
                r->data   = json{{"error", "provide 'file' (multipart) or 'audio_base64' (JSON)"}}.dump();
                return r;
            }
            language = j.value("language", language);
            auto raw = b64_decode(ab64);
            pcm = decode_to_pcm(raw.data(), raw.size(),
                                 pimpl->cfg.sample_rate, pimpl->cfg.max_duration_s, err);
        }

        if (!err.empty()) {
            auto r = std::make_unique<server_http_res>();
            r->status = 400;
            r->data   = json{{"error", err}}.dump();
            return r;
        }
        if (pcm.empty()) {
            auto r = std::make_unique<server_http_res>();
            r->status = 400;
            r->data   = json{{"error", "no audio provided"}}.dump();
            return r;
        }

        auto text = pimpl->transcribe(pcm, language, req.should_stop);

        auto r = std::make_unique<server_http_res>();
        r->status = 200;
        r->data   = json{{"text", text}, {"language", language.empty() ? "auto" : language}}.dump();
        SRV_DBG("voice message sent: %s\n", r->data.c_str());
        return r;
    };

    // -----------------------------------------------------------------------
    // POST /v1/voice/stream/chunk
    //
    // Browser sends raw PCM16 chunks (16 kHz mono) from MediaRecorder.
    // Server accumulates per session, runs VAD, transcribes when utterance ends.
    //
    // Request JSON:
    //   {
    //     "session_id": "uuid",         // client-generated
    //     "pcm_base64": "...",          // raw PCM16 LE bytes, base64
    //     "language":   "hi",           // optional
    //     "is_last":    false           // true when mic button released
    //   }
    //
    // Response JSON:
    //   { "utterance_end": false }                                // still listening
    //   { "utterance_end": true, "text": "...", "language": "hi" } // utterance complete
    // -----------------------------------------------------------------------
    handle_stream_chunk = [this](const server_http_req & req) -> server_http_res_ptr {
        auto make_err = [](int st, const std::string & msg) {
            auto r = std::make_unique<server_http_res>();
            r->status = st;
            r->data   = json{{"error", msg}}.dump();
            return r;
        };

        if (req.body.empty()) { return make_err(400, "empty body"); }

        json j;
        try { j = json::parse(req.body); } catch (...) { return make_err(400, "invalid JSON"); }

        const std::string session_id = j.value("session_id", "");
        const std::string pcm_b64    = j.value("pcm_base64", "");
        const std::string language   = j.value("language", pimpl->cfg.default_language);
        const bool        is_last    = j.value("is_last", false);

        if (session_id.empty()) { return make_err(400, "session_id required"); }

        // Decode incoming PCM16 chunk
        std::vector<float> chunk;
        if (!pcm_b64.empty()) {
            auto raw = b64_decode(pcm_b64);
            chunk    = pcm16_to_f32(raw.data(), raw.size());
        }

        // Accumulate into session buffer
        bool utterance_ended = false;
        std::vector<float> utterance_pcm;
        {
            std::lock_guard<std::mutex> lk(pimpl->sessions_mtx);
            auto & sess = pimpl->sessions[session_id];
            sess.last_activity = std::chrono::steady_clock::now();
            sess.pcm_buf.insert(sess.pcm_buf.end(), chunk.begin(), chunk.end());

            const int max_frames = pimpl->cfg.max_duration_s * pimpl->cfg.sample_rate;
            if ((int)sess.pcm_buf.size() > max_frames) {
                sess.pcm_buf.erase(sess.pcm_buf.begin(),
                                   sess.pcm_buf.begin() + (sess.pcm_buf.size() - max_frames));
            }

            // VAD: check if utterance ended (silent tail after speech)
            const int min_speech_frames = pimpl->cfg.sample_rate / 2; // 500ms minimum
            if (is_last || ((int)sess.pcm_buf.size() > min_speech_frames &&
                             vad_simple(sess.pcm_buf,
                                        pimpl->cfg.sample_rate,
                                        pimpl->cfg.vad_last_ms,
                                        pimpl->cfg.vad_threshold,
                                        pimpl->cfg.vad_freq_thold))) {
                utterance_ended = true;
                utterance_pcm   = std::move(sess.pcm_buf);
                pimpl->sessions.erase(session_id);
            }
        }

        auto r = std::make_unique<server_http_res>();
        r->status = 200;

        if (!utterance_ended) {
            r->data = json{{"utterance_end", false}}.dump();
            return r;
        }

        // Transcribe the completed utterance
        auto text = pimpl->transcribe(utterance_pcm, language, req.should_stop);
        r->data = json{
            {"utterance_end", true},
            {"text",     text},
            {"language", language.empty() ? "auto" : language},
        }.dump();
        return r;
    };

    // -----------------------------------------------------------------------
    // GET /v1/voice/health
    // -----------------------------------------------------------------------
    handle_get_health = [this](const server_http_req &) -> server_http_res_ptr {
        std::lock_guard<std::mutex> lk(pimpl->sessions_mtx);
        auto r = std::make_unique<server_http_res>();
        r->status = 200;
        r->data   = json{
            {"status",            "ok"},
            {"transcription_path", pimpl->active_path()},
            {"has_transcription", pimpl->has_transcription()},
            {"model_path",        pimpl->cfg.model_path.empty()
                                      ? "(none)" : pimpl->cfg.model_path},
            {"model_hint",        pimpl->cfg.model_hint},
            {"default_language",  pimpl->cfg.default_language.empty()
                                      ? "auto" : pimpl->cfg.default_language},
            {"n_threads",         resolve_threads(pimpl->cfg.n_threads)},
            {"max_duration_s",    pimpl->cfg.max_duration_s},
            {"sample_rate",       pimpl->cfg.sample_rate},
            {"active_sessions",   (int)pimpl->sessions.size()},
        }.dump();
        return r;
    };

    // -----------------------------------------------------------------------
    // GET /v1/voice/languages
    // -----------------------------------------------------------------------
    handle_get_languages = [](const server_http_req &) -> server_http_res_ptr {
        json langs = json::array();
        for (int i = 0; i < N_INDIAN_LANGS; ++i) {
            langs.push_back(json{
                {"code",    INDIAN_LANGS[i].code},
                {"name",    INDIAN_LANGS[i].name},
                {"native",  INDIAN_LANGS[i].native},
                {"quality", INDIAN_LANGS[i].quality},
            });
        }
        auto r = std::make_unique<server_http_res>();
        r->status = 200;
        r->data   = json{
            {"languages", langs},
            {"note", "For Hinglish (Hindi+English), pass language=hi or omit for auto-detect. "
                     "For Odia (or), use AI4Bharat IndicWhisper model for best accuracy."},
            {"models", {
                {"lightweight",  "whisper-small.gguf — 466 MB, good Hindi/Bengali"},
                {"recommended",  "whisper-medium.gguf or Qwen2-Audio-7B-Instruct — best Indian language coverage"},
                {"best_odia",    "IndicWhisper-medium.gguf — convert from AI4Bharat/IndicWhisper on HuggingFace"},
            }},
        }.dump();
        return r;
    };
}

server_voice::~server_voice() = default;

// ---------------------------------------------------------------------------
// Internal API — called from server-notification for WhatsApp voice messages
// ---------------------------------------------------------------------------

std::string server_voice::transcribe_audio(const std::vector<uint8_t> & audio_data,
                                            const std::string          & /*mime_type*/,
                                            const std::string          & language_hint) const {
    const std::string lang = language_hint.empty()
                             ? pimpl->cfg.default_language
                             : language_hint;
    std::string err;
    auto pcm = decode_to_pcm(audio_data.data(), audio_data.size(),
                              pimpl->cfg.sample_rate, pimpl->cfg.max_duration_s, err);
    if (pcm.empty()) {
        SRV_WRN("voice: audio decode failed: %s\n", err.c_str());
        return "";
    }
    auto stop = []() { return false; };
    return pimpl->transcribe(pcm, lang, stop);
}
