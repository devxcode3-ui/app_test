#include "server-notification.h"

#include "server-common.h"

#include <sqlite3.h>
#include <cpp-httplib/httplib.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_set>
#include <vector>

namespace {

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

int64_t notif_now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

std::string url_encode_component(const std::string & s) {
    std::string out;
    for (unsigned char c : s) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            out += (char) c;
        } else {
            char hex[4];
            std::snprintf(hex, sizeof(hex), "%%%02X", c);
            out += hex;
        }
    }
    return out;
}

// Strip the "@s.whatsapp.net" suffix to get the plain phone number
std::string sender_to_number(const std::string & sender) {
    const auto pos = sender.find('@');
    return pos != std::string::npos ? sender.substr(0, pos) : sender;
}

// Decode base64 (simple table-based decoder for media saving)
static const std::string B64_CHARS =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

std::vector<uint8_t> base64_decode(const std::string & encoded) {
    std::vector<uint8_t> out;
    out.reserve(encoded.size() * 3 / 4);
    int val = 0, valb = -8;
    for (unsigned char c : encoded) {
        if (c == '=') break;
        const auto pos = B64_CHARS.find(c);
        if (pos == std::string::npos) continue;
        val = (val << 6) + (int) pos;
        valb += 6;
        if (valb >= 0) {
            out.push_back((uint8_t)((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return out;
}

server_http_res_ptr notif_json_ok(const json & body) {
    auto res = std::make_unique<server_http_res>();
    res->status = 200;
    res->data   = safe_json_to_str(body);
    return res;
}

server_http_res_ptr notif_json_accepted(const json & body) {
    auto res = std::make_unique<server_http_res>();
    res->status = 202;
    res->data   = safe_json_to_str(body);
    return res;
}

server_http_res_ptr notif_json_error(const std::string & msg, int status) {
    const error_type type = status == 400 ? ERROR_TYPE_INVALID_REQUEST
                          : status == 403 ? ERROR_TYPE_PERMISSION
                          : status == 404 ? ERROR_TYPE_NOT_FOUND
                          : ERROR_TYPE_SERVER;
    auto res = std::make_unique<server_http_res>();
    res->status = status;
    res->data   = safe_json_to_str({{"error", format_error_response(msg, type)}});
    return res;
}

// ---------------------------------------------------------------------------
// Parsed inbound message
// ---------------------------------------------------------------------------

struct wa_inbound {
    std::string message_id;
    std::string sender;      // e.g. "919899429152@s.whatsapp.net"
    std::string push_name;
    std::string text;
    std::string media_kind;  // "image" | "document" | "video" | "audio" | ""
    std::string media_b64;   // base64-encoded media data from webhook
    std::string media_filename;
    std::string media_mimetype;
    json raw_message;
    json raw_key;
};

std::optional<wa_inbound> parse_webhook(const json & payload) {
    try {
        const json & data_raw = payload.at("data");
        const json & item = data_raw.is_array() ? data_raw.at(0) : data_raw;
        if (!item.is_object()) return std::nullopt;

        const json & key = item.at("key");
        if (!key.is_object() || key.value("fromMe", false)) return std::nullopt;

        const std::string sender = key.at("remoteJid").get<std::string>();
        if (sender.empty()) return std::nullopt;

        const json & message = item.at("message");
        if (!message.is_object()) return std::nullopt;

        wa_inbound msg;
        msg.message_id   = key.value("id", random_string());
        msg.sender       = sender;
        msg.push_name    = item.value("pushName", "");
        msg.raw_message  = message;
        msg.raw_key      = key;

        // Text content
        if (message.contains("conversation")) {
            msg.text = message.at("conversation").get<std::string>();
        } else if (message.contains("extendedTextMessage")) {
            msg.text = message.at("extendedTextMessage").value("text", "");
        }

        // Media content
        static const char * MEDIA_TYPES[] = {
            "imageMessage", "documentMessage", "videoMessage", "audioMessage", nullptr
        };
        for (const char ** mt = MEDIA_TYPES; *mt; ++mt) {
            if (!message.contains(*mt) || !message.at(*mt).is_object()) continue;
            const json & m = message.at(*mt);

            msg.media_kind     = std::string(*mt).substr(0, std::string(*mt).find("Message"));
            msg.media_filename = m.value("fileName", "");
            msg.media_mimetype = m.value("mimetype", "application/octet-stream");

            // Caption doubles as text for images/documents
            const std::string caption = m.value("caption", "");
            if (msg.text.empty() && !caption.empty()) {
                msg.text = caption;
            }

            // Base64 data may be embedded when webhookBase64=true
            if (m.contains("base64") && m.at("base64").is_string()) {
                msg.media_b64 = m.at("base64").get<std::string>();
            }
            break;
        }

        return msg;
    } catch (...) {
        return std::nullopt;
    }
}

// ---------------------------------------------------------------------------
// Keyword router
// ---------------------------------------------------------------------------

enum class keyword_action { NONE, OPT_OUT, OPT_IN, STATIC_REPLY };

struct keyword_result {
    keyword_action action = keyword_action::NONE;
    std::string    reply;
};

keyword_result check_keyword(const std::string & raw) {
    std::string upper;
    for (unsigned char c : raw) upper += (char) std::toupper(c);
    // Strip leading/trailing whitespace
    const auto first = upper.find_first_not_of(" \t\r\n");
    const auto last  = upper.find_last_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    upper = upper.substr(first, last - first + 1);

    if (upper == "STOP") {
        return {keyword_action::OPT_OUT,
            "You have been unsubscribed from notifications. Reply START to re-subscribe."};
    }
    if (upper == "START") {
        return {keyword_action::OPT_IN,
            "Welcome back! You are now subscribed to notifications again."};
    }
    if (upper == "HELP") {
        return {keyword_action::STATIC_REPLY,
            "Available commands:\n"
            "BOOK - make a booking\n"
            "CANCEL - cancel a booking\n"
            "RESCHEDULE - change your booking\n"
            "MENU - view current menu or products\n"
            "HOURS - opening hours\n"
            "STOP - unsubscribe from notifications\n"
            "START - re-subscribe to notifications\n\n"
            "Or just send a message and I'll help you."};
    }
    return {};
}

} // namespace

// ---------------------------------------------------------------------------
// impl
// ---------------------------------------------------------------------------

struct server_notification::impl {
    server_http_context::handler_t chat_handler;
    server_http_context::handler_t classify_handler;
    server_http_context::handler_t agent_run_handler;
    notification_config cfg;

    sqlite3 *          db = nullptr;
    mutable std::mutex db_mutex;

    std::unordered_set<std::string> allowed_senders;
    bool                            allow_all = false;

    std::thread        scheduler_thread;
    std::atomic<bool>  stop_flag{false};
    std::atomic<int>   active_threads{0};

    // Persistent stop function used for internal LLM calls not tied to a request
    std::function<bool()> internal_stop = [this] { return stop_flag.load(); };

    impl(server_http_context::handler_t chat,
         server_http_context::handler_t classify,
         server_http_context::handler_t agent_run,
         notification_config c)
        : chat_handler(std::move(chat)),
          classify_handler(std::move(classify)),
          agent_run_handler(std::move(agent_run)),
          cfg(std::move(c)) {
        // Parse allowed senders
        if (cfg.allowed_senders == "all") {
            allow_all = true;
        } else {
            std::istringstream ss(cfg.allowed_senders);
            std::string tok;
            while (std::getline(ss, tok, ',')) {
                const auto f = tok.find_first_not_of(" \t");
                const auto l = tok.find_last_not_of(" \t");
                if (f != std::string::npos) {
                    allowed_senders.insert(tok.substr(f, l - f + 1));
                }
            }
        }

        // Open SQLite
        if (cfg.db_path.empty()) {
            throw std::runtime_error("notification: db_path is required");
        }
        const int flags = SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX;
        if (sqlite3_open_v2(cfg.db_path.c_str(), &db, flags, nullptr) != SQLITE_OK) {
            const std::string msg = db ? sqlite3_errmsg(db) : "unknown";
            if (db) { sqlite3_close(db); db = nullptr; }
            throw std::runtime_error("notification: failed to open database: " + msg);
        }
        exec_sql("PRAGMA busy_timeout = 5000");
        exec_sql("PRAGMA journal_mode = WAL");
        init_schema();

        // Create media directory
        if (!cfg.media_dir.empty()) {
            std::error_code ec;
            std::filesystem::create_directories(cfg.media_dir, ec);
        }

        // Start scheduler
        scheduler_thread = std::thread([this] { scheduler_loop(); });
    }

    ~impl() {
        stop_flag.store(true);
        // Wait for in-flight processing threads before closing the DB
        for (int i = 0; i < 300 && active_threads.load() > 0; ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        if (scheduler_thread.joinable()) {
            scheduler_thread.join();
        }
        if (db) { sqlite3_close(db); }
    }

    // --- SQLite helpers ---

    void exec_sql(const char * sql) {
        char * err = nullptr;
        if (sqlite3_exec(db, sql, nullptr, nullptr, &err) != SQLITE_OK) {
            const std::string msg = err ? err : "unknown";
            sqlite3_free(err);
            throw std::runtime_error("notification db error: " + msg);
        }
    }

    void init_schema() {
        exec_sql(
            "CREATE TABLE IF NOT EXISTS wa_senders ("
            "  sender       TEXT PRIMARY KEY,"
            "  display_name TEXT NOT NULL DEFAULT '',"
            "  phone        TEXT NOT NULL DEFAULT '',"
            "  role         TEXT NOT NULL DEFAULT 'customer',"
            "  system_prompt TEXT NOT NULL DEFAULT '',"
            "  opted_out    INTEGER NOT NULL DEFAULT 0,"
            "  last_seen_at INTEGER NOT NULL,"
            "  created_at   INTEGER NOT NULL"
            ")"
        );
        exec_sql(
            "CREATE TABLE IF NOT EXISTS wa_messages ("
            "  message_id  TEXT PRIMARY KEY,"
            "  sender      TEXT NOT NULL,"
            "  text        TEXT NOT NULL,"
            "  media_path  TEXT NOT NULL DEFAULT '',"
            "  raw_json    TEXT NOT NULL,"
            "  received_at INTEGER NOT NULL"
            ")"
        );
        exec_sql("CREATE INDEX IF NOT EXISTS idx_wa_msg_sender ON wa_messages(sender, received_at)");
        exec_sql(
            "CREATE TABLE IF NOT EXISTS wa_conversations ("
            "  id          INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  sender      TEXT NOT NULL,"
            "  role        TEXT NOT NULL,"
            "  content     TEXT NOT NULL,"
            "  message_id  TEXT NOT NULL DEFAULT '',"
            "  created_at  INTEGER NOT NULL"
            ")"
        );
        exec_sql("CREATE INDEX IF NOT EXISTS idx_wa_conv_sender ON wa_conversations(sender, created_at)");
        exec_sql(
            "CREATE TABLE IF NOT EXISTS wa_scheduled ("
            "  id         TEXT PRIMARY KEY,"
            "  sender     TEXT NOT NULL,"
            "  message    TEXT NOT NULL,"
            "  send_at    INTEGER NOT NULL,"
            "  sent_at    INTEGER,"
            "  status     TEXT NOT NULL DEFAULT 'pending',"
            "  created_at INTEGER NOT NULL"
            ")"
        );
        exec_sql("CREATE INDEX IF NOT EXISTS idx_wa_sched_due ON wa_scheduled(send_at, status)");
        exec_sql(
            "CREATE TABLE IF NOT EXISTS wa_connection ("
            "  id INTEGER PRIMARY KEY CHECK (id = 1),"
            "  instance TEXT NOT NULL DEFAULT 'business',"
            "  status TEXT NOT NULL DEFAULT 'disconnected',"
            "  qr_code TEXT NOT NULL DEFAULT '',"
            "  updated_at INTEGER NOT NULL"
            ")"
        );
    }

    // --- Sender management ---

    bool is_allowed(const std::string & sender) const {
        if (allow_all) return true;
        return allowed_senders.count(sender) > 0;
    }

    void upsert_sender(const wa_inbound & msg) {
        const int64_t now = notif_now_ms();
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "INSERT INTO wa_senders (sender, display_name, phone, last_seen_at, created_at) "
            "VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(sender) DO UPDATE SET "
            "  display_name = excluded.display_name,"
            "  phone        = excluded.phone,"
            "  last_seen_at = excluded.last_seen_at",
            -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, msg.sender.c_str(),    -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, msg.push_name.c_str(), -1, SQLITE_TRANSIENT);
        const std::string phone = sender_to_number(msg.sender);
        sqlite3_bind_text(stmt, 3, phone.c_str(),         -1, SQLITE_TRANSIENT);
        sqlite3_bind_int64(stmt, 4, now);
        sqlite3_bind_int64(stmt, 5, now);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }

    bool is_opted_out(const std::string & sender) const {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "SELECT opted_out FROM wa_senders WHERE sender = ?", -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, sender.c_str(), -1, SQLITE_TRANSIENT);
        int opted_out = 0;
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            opted_out = sqlite3_column_int(stmt, 0);
        }
        sqlite3_finalize(stmt);
        return opted_out != 0;
    }

    void set_opted_out(const std::string & sender, bool value) {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "UPDATE wa_senders SET opted_out = ? WHERE sender = ?", -1, &stmt, nullptr);
        sqlite3_bind_int(stmt, 1, value ? 1 : 0);
        sqlite3_bind_text(stmt, 2, sender.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }

    std::string get_sender_role(const std::string & sender) const {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "SELECT role, system_prompt FROM wa_senders WHERE sender = ?", -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, sender.c_str(), -1, SQLITE_TRANSIENT);
        std::string role = "customer";
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            const char * r = (const char *) sqlite3_column_text(stmt, 0);
            if (r) role = r;
        }
        sqlite3_finalize(stmt);
        return role;
    }

    // --- Message log ---

    void store_message(const wa_inbound & msg, const std::string & media_path) {
        const int64_t now = notif_now_ms();
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "INSERT OR IGNORE INTO wa_messages "
            "(message_id, sender, text, media_path, raw_json, received_at) VALUES (?, ?, ?, ?, ?, ?)",
            -1, &stmt, nullptr);
        const std::string raw = msg.raw_message.dump();
        sqlite3_bind_text(stmt, 1, msg.message_id.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, msg.sender.c_str(),     -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 3, msg.text.c_str(),       -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 4, media_path.c_str(),     -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 5, raw.c_str(),            -1, SQLITE_TRANSIENT);
        sqlite3_bind_int64(stmt, 6, now);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }

    // --- Conversation history ---

    void add_turn(const std::string & sender, const std::string & role,
                  const std::string & content, const std::string & message_id = "") {
        const int64_t now = notif_now_ms();
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "INSERT INTO wa_conversations (sender, role, content, message_id, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, sender.c_str(),     -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, role.c_str(),       -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 3, content.c_str(),    -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 4, message_id.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int64(stmt, 5, now);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
        trim_history(sender);
    }

    void trim_history(const std::string & sender) {
        const int max_rows = cfg.max_history_turns * 2;
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "DELETE FROM wa_conversations WHERE sender = ? AND id NOT IN ("
            "  SELECT id FROM wa_conversations WHERE sender = ? "
            "  ORDER BY created_at DESC, id DESC LIMIT ?)",
            -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, sender.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, sender.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 3, max_rows);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }

    void clear_history(const std::string & sender) {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "DELETE FROM wa_conversations WHERE sender = ?", -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, sender.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }

    json get_history(const std::string & sender) const {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "SELECT role, content FROM wa_conversations "
            "WHERE sender = ? ORDER BY created_at DESC, id DESC LIMIT ?",
            -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, sender.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 2, cfg.max_history_turns * 2);
        std::vector<json> rows;
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            const char * role    = (const char *) sqlite3_column_text(stmt, 0);
            const char * content = (const char *) sqlite3_column_text(stmt, 1);
            rows.push_back({{"role", role ? role : ""}, {"content", content ? content : ""}});
        }
        sqlite3_finalize(stmt);
        // Rows are in DESC order — reverse to get chronological order
        json history = json::array();
        for (auto it = rows.rbegin(); it != rows.rend(); ++it) {
            history.push_back(*it);
        }
        return history;
    }

    // --- Media saving ---

    std::string save_media(const wa_inbound & msg) {
        if (msg.media_b64.empty() || cfg.media_dir.empty()) return "";
        try {
            const auto bytes = base64_decode(msg.media_b64);
            if (bytes.empty()) return "";

            // Determine file extension from mimetype
            std::string ext = ".bin";
            const std::string & mime = msg.media_mimetype;
            if (mime.find("jpeg") != std::string::npos || mime.find("jpg") != std::string::npos) ext = ".jpg";
            else if (mime.find("png") != std::string::npos)  ext = ".png";
            else if (mime.find("pdf") != std::string::npos)  ext = ".pdf";
            else if (mime.find("mp4") != std::string::npos)  ext = ".mp4";
            else if (mime.find("ogg") != std::string::npos)  ext = ".ogg";
            else if (mime.find("opus") != std::string::npos) ext = ".opus";
            else if (!msg.media_filename.empty()) {
                const auto dot = msg.media_filename.rfind('.');
                if (dot != std::string::npos) ext = msg.media_filename.substr(dot);
            }

            const std::string path = cfg.media_dir + "/" + msg.message_id + ext;
            std::ofstream out(path, std::ios::binary);
            out.write(reinterpret_cast<const char *>(bytes.data()), (std::streamsize) bytes.size());
            out.close();
            return path;
        } catch (...) {
            return "";
        }
    }

    // --- LLM calls ---

    // Build an internal server_http_req for handler calls
    server_http_req make_inner_req(
            const std::map<std::string, std::string> & params,
            const std::string & path,
            const std::string & body,
            const std::function<bool()> & stop_fn) const {
        return server_http_req {
            params,
            {},
            path,
            {},
            body,
            {},
            stop_fn,
        };
    }

    // Returns true if the prompt needs tools
    bool classify(const std::string & prompt, const std::function<bool()> & stop_fn) const {
        if (!classify_handler) return false;
        try {
            const auto req = make_inner_req({}, "/v1/classify",
                json{{"prompt", prompt.substr(0, 8192)}}.dump(), stop_fn);
            const auto res = classify_handler(req);
            if (!res || res->status != 200) return false;
            const json result = json::parse(res->data);
            return result.value("needs_tools", false);
        } catch (...) {
            return false;  // safe fallback: no tools
        }
    }

    // Call /v1/chat/completions with conversation history
    std::string run_chat(const std::string & sender, const std::string & prompt,
                         const std::function<bool()> & stop_fn) const {
        const json history = get_history(sender);
        json messages = json::array();

        const std::string sys = cfg.system_prompt.empty()
            ? "You are a helpful business assistant communicating via WhatsApp. "
              "Keep replies concise and friendly. Use plain text without markdown."
            : cfg.system_prompt;
        messages.push_back({{"role", "system"}, {"content", sys}});

        for (const auto & turn : history) {
            messages.push_back(turn);
        }
        messages.push_back({{"role", "user"}, {"content", prompt}});

        const json body = {
            {"messages",   messages},
            {"stream",     false},
            {"temperature", 0.7},
            {"max_tokens", 512},
        };
        const auto req = make_inner_req({}, "/v1/chat/completions", body.dump(), stop_fn);
        const auto res = chat_handler(req);
        if (!res || res->status != 200) {
            return "Sorry, I could not process your message right now. Please try again.";
        }
        try {
            return json::parse(res->data).at("choices").at(0)
                       .at("message").value("content", "").substr(0, 4000);
        } catch (...) {
            return "Sorry, something went wrong. Please try again.";
        }
    }

    // Call /v1/agents/:id/run (stored needle agent) with conversation context
    std::string run_agent(const std::string & sender, const std::string & prompt,
                          const std::function<bool()> & stop_fn) const {
        if (!agent_run_handler || cfg.agent_id.empty()) {
            return run_chat(sender, prompt, stop_fn);
        }
        // Build context string from recent history
        const json history = get_history(sender);
        std::string context;
        for (const auto & turn : history) {
            const std::string role    = turn.value("role", "");
            const std::string content = turn.value("content", "");
            if (role == "user" && content != prompt) {
                context += "User: " + content + "\n";
            } else if (role == "assistant") {
                context += "Assistant: " + content + "\n";
            }
        }
        const std::string full_prompt = context.empty()
            ? prompt
            : "Conversation so far:\n" + context + "\nCurrent message: " + prompt;

        const json body = {
            {"prompt",      full_prompt},
            {"allow_write", true},
        };
        const auto req = make_inner_req(
            {{"id", cfg.agent_id}},
            "/v1/agents/" + cfg.agent_id + "/run",
            body.dump(), stop_fn);
        const auto res = agent_run_handler(req);
        if (!res || res->status != 200) {
            SRV_WRN("notification: agent run failed (status %d), falling back to chat\n",
                    res ? res->status : 0);
            return run_chat(sender, prompt, stop_fn);
        }
        try {
            const json result = json::parse(res->data);
            // Prefer last step's plain_text_response, then summary
            const json & steps = result.value("steps", json::array());
            if (!steps.empty()) {
                const auto & last = steps.back();
                const std::string ptext = last.value(
                    json::json_pointer("/result/plain_text_response"), std::string(""));
                if (!ptext.empty()) return ptext.substr(0, 4000);
            }
            const std::string summary = result.value("summary", "");
            return summary.empty()
                ? "I've processed your request."
                : summary.substr(0, 4000);
        } catch (...) {
            return "I've processed your request.";
        }
    }

    // Classify then route
    std::string route(const std::string & sender, const std::string & prompt,
                      const std::function<bool()> & stop_fn) const {
        const bool needs_tools = classify(prompt, stop_fn);
        return needs_tools
            ? run_agent(sender, prompt, stop_fn)
            : run_chat(sender, prompt, stop_fn);
    }

    // --- Evolution API outbound ---

    std::string evolution_path(const std::string & path) const {
        const auto scheme_end = cfg.evolution_url.find("://");
        const auto host_end = scheme_end == std::string::npos
            ? std::string::npos
            : cfg.evolution_url.find('/', scheme_end + 3);
        std::string prefix;
        if (host_end != std::string::npos) {
            prefix = cfg.evolution_url.substr(host_end);
            while (!prefix.empty() && prefix.back() == '/') prefix.pop_back();
        }
        return prefix + "/" + path;
    }

    httplib::Headers evolution_headers() const {
        return {{"apikey", cfg.evolution_api_key}, {"Content-Type", "application/json"}};
    }

    std::optional<json> evolution_get(const std::string & path) const {
        httplib::Client cli(cfg.evolution_url);
        cli.set_connection_timeout(10);
        cli.set_read_timeout(30);
        auto res = cli.Get(evolution_path(path), evolution_headers());
        if (!res || res->status < 200 || res->status >= 300) return std::nullopt;
        try { return json::parse(res->body); } catch (...) { return json::object(); }
    }

    std::optional<json> evolution_post(const std::string & path, const json & body) const {
        httplib::Client cli(cfg.evolution_url);
        cli.set_connection_timeout(10);
        cli.set_read_timeout(30);
        auto res = cli.Post(evolution_path(path), evolution_headers(), body.dump(), "application/json");
        if (!res || res->status < 200 || res->status >= 300) return std::nullopt;
        try { return json::parse(res->body); } catch (...) { return json::object(); }
    }

    std::optional<json> evolution_delete(const std::string & path) const {
        httplib::Client cli(cfg.evolution_url);
        cli.set_connection_timeout(10);
        cli.set_read_timeout(30);
        auto res = cli.Delete(evolution_path(path), evolution_headers());
        if (!res || res->status < 200 || res->status >= 300) return std::nullopt;
        try { return json::parse(res->body); } catch (...) { return json::object(); }
    }

    void save_connection(const std::string & status, const std::string & qr) {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "INSERT INTO wa_connection (id, instance, status, qr_code, updated_at) VALUES (1, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET instance=excluded.instance, status=excluded.status, qr_code=excluded.qr_code, updated_at=excluded.updated_at",
            -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, cfg.evolution_instance.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, status.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 3, qr.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int64(stmt, 4, notif_now_ms());
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }

    json get_connection() const {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db, "SELECT instance, status, qr_code, updated_at FROM wa_connection WHERE id = 1", -1, &stmt, nullptr);
        json result = {{"instance", cfg.evolution_instance}, {"status", "disconnected"}, {"qr_code", ""}};
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            result["instance"] = (const char *) sqlite3_column_text(stmt, 0);
            result["status"] = (const char *) sqlite3_column_text(stmt, 1);
            result["qr_code"] = (const char *) sqlite3_column_text(stmt, 2);
            result["updated_at"] = sqlite3_column_int64(stmt, 3);
        }
        sqlite3_finalize(stmt);
        return result;
    }

    bool send_text(const std::string & number, const std::string & text) const {
        if (cfg.evolution_url.empty() || cfg.evolution_instance.empty()) return false;
        try {
            httplib::Client cli(cfg.evolution_url);
            cli.set_connection_timeout(10);
            cli.set_read_timeout(30);

            const std::string path = evolution_path("message/sendText/") +
                url_encode_component(cfg.evolution_instance);
            const json body = {
                {"number", number},
                {"text",   text},
            };
            httplib::Headers headers = {
                {"apikey",       cfg.evolution_api_key},
                {"Content-Type", "application/json"},
            };
            auto res = cli.Post(path, headers, body.dump(), "application/json");
            if (!res) {
                SRV_WRN("%s", "notification: send_text failed: no response from Evolution API\n");
                return false;
            }
            if (res->status != 200 && res->status != 201) {
                SRV_WRN("notification: send_text HTTP %d\n", res->status);
                return false;
            }
            SRV_DBG("whatsapp message sent: number=%s text=%s\n", number.c_str(), text.c_str());
            return true;
        } catch (const std::exception & e) {
            SRV_WRN("notification: send_text exception: %s\n", e.what());
            return false;
        }
    }

    // --- Process a single inbound message (called from background thread) ---

    void process_inbound(wa_inbound msg) {
        active_threads++;
        struct guard { std::atomic<int> & n; ~guard() { n--; } } g{active_threads};

        // Save media
        const std::string media_path = save_media(msg);
        SRV_DBG("whatsapp message received: sender=%s kind=%s text=%s media=%s\n",
            msg.sender.c_str(), msg.media_kind.c_str(), msg.text.c_str(), media_path.c_str());

        // Persist to message log
        store_message(msg, media_path);
        upsert_sender(msg);

        // Build prompt text
        std::string prompt = msg.text;
        if (prompt.empty() && !media_path.empty()) {
            prompt = "(attachment: " + media_path + ")";
        } else if (!media_path.empty()) {
            prompt += "\n[Attachment: " + media_path + "]";
        }
        if (prompt.empty()) {
            prompt = "(empty message)";
        }

        // Keyword check
        const auto kw = check_keyword(msg.text);
        if (kw.action == keyword_action::OPT_OUT) {
            set_opted_out(msg.sender, true);
            clear_history(msg.sender);
            send_text(sender_to_number(msg.sender), kw.reply);
            return;
        }
        if (kw.action == keyword_action::OPT_IN) {
            set_opted_out(msg.sender, false);
            send_text(sender_to_number(msg.sender), kw.reply);
            return;
        }
        if (kw.action == keyword_action::STATIC_REPLY) {
            send_text(sender_to_number(msg.sender), kw.reply);
            return;
        }

        // Store user turn in conversation history
        add_turn(msg.sender, "user", prompt, msg.message_id);

        // Route through LLM
        const std::string reply = route(msg.sender, prompt, internal_stop);

        // Store assistant turn
        add_turn(msg.sender, "assistant", reply);

        // Send reply back via Evolution API
        if (!reply.empty()) {
            send_text(sender_to_number(msg.sender), reply);
        }
    }

    // --- Outbound scheduler ---

    std::string schedule_notification(const std::string & sender,
                                      const std::string & message,
                                      int64_t send_at_ms) {
        const std::string id = random_string();
        const int64_t now = notif_now_ms();
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "INSERT INTO wa_scheduled (id, sender, message, send_at, status, created_at) "
            "VALUES (?, ?, ?, ?, 'pending', ?)",
            -1, &stmt, nullptr);
        sqlite3_bind_text(stmt, 1, id.c_str(),      -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, sender.c_str(),  -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 3, message.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int64(stmt, 4, send_at_ms);
        sqlite3_bind_int64(stmt, 5, now);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
        return id;
    }

    int process_due_notifications() {
        const int64_t now = notif_now_ms();
        std::vector<std::tuple<std::string, std::string, std::string>> due;
        {
            std::lock_guard<std::mutex> lock(db_mutex);
            sqlite3_stmt * stmt = nullptr;
            sqlite3_prepare_v2(db,
                "SELECT id, sender, message FROM wa_scheduled "
                "WHERE status = 'pending' AND send_at <= ? ORDER BY send_at LIMIT 50",
                -1, &stmt, nullptr);
            sqlite3_bind_int64(stmt, 1, now);
            while (sqlite3_step(stmt) == SQLITE_ROW) {
                const char * id  = (const char *) sqlite3_column_text(stmt, 0);
                const char * s   = (const char *) sqlite3_column_text(stmt, 1);
                const char * msg = (const char *) sqlite3_column_text(stmt, 2);
                if (id && s && msg) {
                    due.emplace_back(id, s, msg);
                }
            }
            sqlite3_finalize(stmt);
        }

        int sent = 0;
        for (const auto & [id, sender, message] : due) {
            const bool ok = send_text(sender_to_number(sender), message);
            const std::string status = ok ? "sent" : "failed";
            const int64_t sent_at = ok ? notif_now_ms() : 0;

            std::lock_guard<std::mutex> lock(db_mutex);
            sqlite3_stmt * stmt = nullptr;
            sqlite3_prepare_v2(db,
                "UPDATE wa_scheduled SET status = ?, sent_at = ? WHERE id = ?",
                -1, &stmt, nullptr);
            sqlite3_bind_text(stmt, 1, status.c_str(), -1, SQLITE_TRANSIENT);
            if (sent_at > 0) sqlite3_bind_int64(stmt, 2, sent_at);
            else             sqlite3_bind_null(stmt, 2);
            sqlite3_bind_text(stmt, 3, id.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_step(stmt);
            sqlite3_finalize(stmt);
            if (ok) sent++;
        }
        return sent;
    }

    void scheduler_loop() {
        while (!stop_flag.load()) {
            for (int i = 0; i < cfg.scheduler_interval_s * 10 && !stop_flag.load(); ++i) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            if (stop_flag.load()) break;
            try {
                process_due_notifications();
            } catch (const std::exception & e) {
                SRV_WRN("notification: scheduler error: %s\n", e.what());
            }
        }
    }

    // --- Query helpers ---

    json get_senders(int limit, int offset) const {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        sqlite3_prepare_v2(db,
            "SELECT sender, display_name, phone, role, opted_out, last_seen_at, created_at "
            "FROM wa_senders ORDER BY last_seen_at DESC LIMIT ? OFFSET ?",
            -1, &stmt, nullptr);
        sqlite3_bind_int(stmt, 1, limit);
        sqlite3_bind_int(stmt, 2, offset);
        json rows = json::array();
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            rows.push_back({
                {"sender",       (const char *) sqlite3_column_text(stmt, 0)},
                {"display_name", (const char *) sqlite3_column_text(stmt, 1)},
                {"phone",        (const char *) sqlite3_column_text(stmt, 2)},
                {"role",         (const char *) sqlite3_column_text(stmt, 3)},
                {"opted_out",    sqlite3_column_int(stmt, 4) != 0},
                {"last_seen_at", sqlite3_column_int64(stmt, 5)},
                {"created_at",   sqlite3_column_int64(stmt, 6)},
            });
        }
        sqlite3_finalize(stmt);
        return rows;
    }

    json get_conversations(const std::string & sender, int limit) const {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        const bool filter = !sender.empty();
        if (filter) {
            sqlite3_prepare_v2(db,
                "SELECT sender, role, content, message_id, created_at "
                "FROM wa_conversations WHERE sender = ? ORDER BY created_at DESC LIMIT ?",
                -1, &stmt, nullptr);
            sqlite3_bind_text(stmt, 1, sender.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_int(stmt, 2, limit);
        } else {
            sqlite3_prepare_v2(db,
                "SELECT sender, role, content, message_id, created_at "
                "FROM wa_conversations ORDER BY created_at DESC LIMIT ?",
                -1, &stmt, nullptr);
            sqlite3_bind_int(stmt, 1, limit);
        }
        json rows = json::array();
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            rows.push_back({
                {"sender",     (const char *) sqlite3_column_text(stmt, 0)},
                {"role",       (const char *) sqlite3_column_text(stmt, 1)},
                {"content",    (const char *) sqlite3_column_text(stmt, 2)},
                {"message_id", (const char *) sqlite3_column_text(stmt, 3)},
                {"created_at", sqlite3_column_int64(stmt, 4)},
            });
        }
        sqlite3_finalize(stmt);
        return rows;
    }

    json get_scheduled(const std::string & status_filter, int limit) const {
        std::lock_guard<std::mutex> lock(db_mutex);
        sqlite3_stmt * stmt = nullptr;
        if (!status_filter.empty()) {
            sqlite3_prepare_v2(db,
                "SELECT id, sender, message, send_at, sent_at, status, created_at "
                "FROM wa_scheduled WHERE status = ? ORDER BY send_at LIMIT ?",
                -1, &stmt, nullptr);
            sqlite3_bind_text(stmt, 1, status_filter.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_int(stmt, 2, limit);
        } else {
            sqlite3_prepare_v2(db,
                "SELECT id, sender, message, send_at, sent_at, status, created_at "
                "FROM wa_scheduled ORDER BY send_at DESC LIMIT ?",
                -1, &stmt, nullptr);
            sqlite3_bind_int(stmt, 1, limit);
        }
        json rows = json::array();
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            json row = {
                {"id",         (const char *) sqlite3_column_text(stmt, 0)},
                {"sender",     (const char *) sqlite3_column_text(stmt, 1)},
                {"message",    (const char *) sqlite3_column_text(stmt, 2)},
                {"send_at",    sqlite3_column_int64(stmt, 3)},
                {"status",     (const char *) sqlite3_column_text(stmt, 5)},
                {"created_at", sqlite3_column_int64(stmt, 6)},
            };
            if (sqlite3_column_type(stmt, 4) != SQLITE_NULL) {
                row["sent_at"] = sqlite3_column_int64(stmt, 4);
            }
            rows.push_back(row);
        }
        sqlite3_finalize(stmt);
        return rows;
    }
};

// ---------------------------------------------------------------------------
// server_notification — constructor wires up all handlers
// ---------------------------------------------------------------------------

server_notification::server_notification(
        server_http_context::handler_t chat_handler,
        server_http_context::handler_t classify_handler,
        server_http_context::handler_t agent_run_handler,
        const notification_config & cfg)
    : pimpl(std::make_unique<impl>(
          std::move(chat_handler),
          std::move(classify_handler),
          std::move(agent_run_handler),
          cfg)) {

    // POST /v1/whatsapp/webhook
    handle_webhook = [this](const server_http_req & req) -> server_http_res_ptr {
        try {
            const json payload = json::parse(req.body);

            auto msg_opt = parse_webhook(payload);
            if (!msg_opt.has_value()) {
                return notif_json_accepted({{"status", "ignored"}, {"reason", "unparseable"}});
            }
            wa_inbound msg = std::move(msg_opt.value());

            if (!pimpl->is_allowed(msg.sender)) {
                return notif_json_accepted({{"status", "ignored"}, {"reason", "sender_not_allowed"}});
            }
            if (pimpl->is_opted_out(msg.sender)) {
                return notif_json_accepted({{"status", "ignored"}, {"reason", "opted_out"}});
            }

            // Cap concurrent processing threads
            if (pimpl->active_threads.load() >= 8) {
                return notif_json_error("server busy", 503);
            }

            // Process asynchronously — return 202 immediately
            std::thread([this, m = std::move(msg)]() mutable {
                try {
                    pimpl->process_inbound(std::move(m));
                } catch (const std::exception & e) {
                    SRV_WRN("notification: process_inbound error: %s\n", e.what());
                }
            }).detach();

            return notif_json_accepted({{"status", "accepted"}});

        } catch (const json::exception & e) {
            return notif_json_error(e.what(), 400);
        } catch (const std::exception & e) {
            return notif_json_error(e.what(), 500);
        }
    };

    // POST /v1/whatsapp/notify
    // Body: { "sender": "919...", "message": "...", "send_at": <ms epoch, optional> }
    handle_notify = [this](const server_http_req & req) -> server_http_res_ptr {
        try {
            const json body   = json::parse(req.body);
            const std::string sender  = body.at("sender").get<std::string>();
            const std::string message = body.at("message").get<std::string>();

            if (sender.empty() || message.empty()) {
                return notif_json_error("sender and message are required", 400);
            }
            if (message.size() > 4096) {
                return notif_json_error("message must be at most 4096 bytes", 400);
            }

            if (body.contains("send_at") && !body.at("send_at").is_null()) {
                const int64_t send_at = body.at("send_at").get<int64_t>();
                const std::string id = pimpl->schedule_notification(sender, message, send_at);
                return notif_json_ok({{"status", "scheduled"}, {"id", id}});
            }

            // Immediate send
            const bool ok = pimpl->send_text(sender_to_number(sender), message);
            return notif_json_ok({{"status", ok ? "sent" : "failed"}});

        } catch (const json::exception & e) {
            return notif_json_error(e.what(), 400);
        } catch (const std::exception & e) {
            return notif_json_error(e.what(), 500);
        }
    };

    // POST /v1/whatsapp/broadcast
    // Body: { "senders": ["919...", ...], "message": "...", "send_at": <ms, optional> }
    handle_broadcast = [this](const server_http_req & req) -> server_http_res_ptr {
        try {
            const json body     = json::parse(req.body);
            const json & senders = body.at("senders");
            const std::string message = body.at("message").get<std::string>();

            if (!senders.is_array() || senders.empty()) {
                return notif_json_error("senders must be a non-empty array", 400);
            }
            if (senders.size() > 500) {
                return notif_json_error("senders array must not exceed 500 entries", 400);
            }
            if (message.empty() || message.size() > 4096) {
                return notif_json_error("message must be 1 to 4096 bytes", 400);
            }

            const bool scheduled = body.contains("send_at") && !body.at("send_at").is_null();
            const int64_t send_at = scheduled ? body.at("send_at").get<int64_t>() : 0;

            json ids = json::array();
            int sent = 0;
            for (const auto & s : senders) {
                const std::string sender = s.get<std::string>();
                if (pimpl->is_opted_out(sender)) continue;
                if (scheduled) {
                    ids.push_back(pimpl->schedule_notification(sender, message, send_at));
                } else {
                    if (pimpl->send_text(sender_to_number(sender), message)) sent++;
                }
            }

            if (scheduled) {
                return notif_json_ok({{"status", "scheduled"}, {"count", ids.size()}, {"ids", ids}});
            }
            return notif_json_ok({{"status", "sent"}, {"count", sent}});

        } catch (const json::exception & e) {
            return notif_json_error(e.what(), 400);
        } catch (const std::exception & e) {
            return notif_json_error(e.what(), 500);
        }
    };

    // GET /v1/whatsapp/health
    handle_get_health = [this](const server_http_req &) -> server_http_res_ptr {
        return notif_json_ok({
            {"status",            "ok"},
            {"active_threads",    pimpl->active_threads.load()},
            {"evolution_url",     pimpl->cfg.evolution_url},
            {"evolution_instance",pimpl->cfg.evolution_instance},
            {"agent_id",          pimpl->cfg.agent_id},
            {"allow_all_senders", pimpl->allow_all},
        });
    };

    // GET /v1/whatsapp/senders?limit=50&offset=0
    handle_get_senders = [this](const server_http_req & req) -> server_http_res_ptr {
        const int limit  = std::max(1, std::min(200, std::stoi(req.get_param("limit",  "50"))));
        const int offset = std::max(0, std::stoi(req.get_param("offset", "0")));
        return notif_json_ok({{"senders", pimpl->get_senders(limit, offset)}});
    };

    // GET /v1/whatsapp/conversations?sender=&limit=100
    handle_get_conversations = [this](const server_http_req & req) -> server_http_res_ptr {
        const std::string sender = req.get_param("sender");
        const int limit  = std::max(1, std::min(500, std::stoi(req.get_param("limit", "100"))));
        return notif_json_ok({{"conversations", pimpl->get_conversations(sender, limit)}});
    };

    // GET /v1/whatsapp/scheduled?status=pending&limit=100
    handle_get_scheduled = [this](const server_http_req & req) -> server_http_res_ptr {
        const std::string status = req.get_param("status");
        const int limit = std::max(1, std::min(500, std::stoi(req.get_param("limit", "100"))));
        return notif_json_ok({{"scheduled", pimpl->get_scheduled(status, limit)}});
    };

    handle_get_connection = [this](const server_http_req &) -> server_http_res_ptr {
        try {
            const auto state = pimpl->evolution_get("instance/connectionState/" +
                                                    url_encode_component(pimpl->cfg.evolution_instance));
            if (state) {
                const std::string status = state->value("instance", json::object()).value("state", "disconnected");
                pimpl->save_connection(status, status == "open" ? "" : pimpl->get_connection().value("qr_code", ""));
            }
            return notif_json_ok(pimpl->get_connection());
        } catch (const std::exception & e) {
            return notif_json_error(e.what(), 502);
        }
    };

    handle_connect = [this](const server_http_req &) -> server_http_res_ptr {
        try {
            const json body = {
                {"instanceName", pimpl->cfg.evolution_instance},
                {"integration", "WHATSAPP-BAILEYS"},
                {"qrcode", true},
                {"webhook", {
                    {"enabled", true},
                    {"url", "/v1/whatsapp/webhook"},
                    {"webhookByEvents", false},
                    {"webhookBase64", true},
                    {"events", {"MESSAGES_UPSERT"}}
                }}
            };
            const auto created = pimpl->evolution_post("instance/create", body);
            const auto connected = pimpl->evolution_get("instance/connect/" +
                                                         url_encode_component(pimpl->cfg.evolution_instance));
            if (!created && !connected) return notif_json_error("Evolution API connection failed", 502);
            std::string qr;
            if (connected) {
                qr = connected->value("base64", connected->value("qrcode", json::object()).value("base64", ""));
            }
            pimpl->save_connection(qr.empty() ? "connecting" : "qr", qr);
            json result = pimpl->get_connection();
            result["evolution"] = connected ? *connected : *created;
            return notif_json_ok(result);
        } catch (const std::exception & e) {
            return notif_json_error(e.what(), 502);
        }
    };

    handle_disconnect = [this](const server_http_req &) -> server_http_res_ptr {
        try {
            if (!pimpl->evolution_delete("instance/logout/" + url_encode_component(pimpl->cfg.evolution_instance))) {
                return notif_json_error("Evolution API disconnect failed", 502);
            }
            pimpl->save_connection("disconnected", "");
            return notif_json_ok(pimpl->get_connection());
        } catch (const std::exception & e) {
            return notif_json_error(e.what(), 502);
        }
    };
}

server_notification::~server_notification() = default;
