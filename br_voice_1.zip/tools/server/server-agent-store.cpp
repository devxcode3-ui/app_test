#include "server-agent-store.h"

#include "server-common.h"

#include <sqlite3.h>

#include <algorithm>
#include <chrono>
#include <cctype>
#include <mutex>
#include <set>
#include <stdexcept>
#include <utility>
#include <vector>

namespace {

constexpr size_t AGENT_ID_MAX_BYTES = 64;
constexpr size_t AGENT_NAME_MAX_BYTES = 100;
constexpr size_t AGENT_DESCRIPTION_MAX_BYTES = 1024;
constexpr size_t AGENT_INSTRUCTIONS_MAX_BYTES = 32 * 1024;
constexpr size_t AGENT_TOOL_NAME_MAX_BYTES = 128;
constexpr size_t AGENT_TOOLS_MAX = 32;
constexpr size_t AGENT_DEFINITIONS_MAX = 256;
constexpr size_t AGENT_DEFINITION_BODY_MAX_BYTES = 64 * 1024;

int64_t now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

bool valid_id(const std::string & id) {
    if (id.empty() || id.size() > AGENT_ID_MAX_BYTES) {
        return false;
    }
    for (unsigned char value : id) {
        if (!std::isalnum(value) && value != '-' && value != '_') {
            return false;
        }
    }
    return true;
}

json validate_definition(const json & input, const std::string & path_id = {}) {
    if (!input.is_object()) {
        throw std::invalid_argument("agent definition must be an object");
    }

    const std::set<std::string> fields = {
        "schema_version", "id", "name", "description", "instructions", "tools", "execution",
    };
    for (const auto & item : input.items()) {
        if (fields.find(item.key()) == fields.end()) {
            throw std::invalid_argument("unknown agent definition field: " + item.key());
        }
    }

    if (input.value("schema_version", 1) != 1) {
        throw std::invalid_argument("schema_version must be 1");
    }

    std::string id = input.value("id", path_id);
    if (id.empty()) {
        id = "agent-" + random_string();
    }
    if (!path_id.empty() && id != path_id) {
        throw std::invalid_argument("agent definition id does not match the request path");
    }
    if (!valid_id(id)) {
        throw std::invalid_argument("id must contain 1 to 64 letters, numbers, dashes, or underscores");
    }

    const std::string name = input.at("name").get<std::string>();
    const std::string description = input.value("description", "");
    const std::string instructions = input.at("instructions").get<std::string>();
    if (name.empty() || name.size() > AGENT_NAME_MAX_BYTES) {
        throw std::invalid_argument("name must contain 1 to 100 bytes");
    }
    if (description.size() > AGENT_DESCRIPTION_MAX_BYTES) {
        throw std::invalid_argument("description must contain at most 1024 bytes");
    }
    if (instructions.empty() || instructions.size() > AGENT_INSTRUCTIONS_MAX_BYTES) {
        throw std::invalid_argument("instructions must contain 1 to 32768 bytes");
    }

    const std::vector<std::string> tools = input.at("tools").get<std::vector<std::string>>();
    if (tools.empty() || tools.size() > AGENT_TOOLS_MAX) {
        throw std::invalid_argument("tools must contain 1 to 32 registered tool names");
    }
    std::set<std::string> unique_tools;
    for (const std::string & tool : tools) {
        if (tool.empty() || tool.size() > AGENT_TOOL_NAME_MAX_BYTES) {
            throw std::invalid_argument("tool names must contain 1 to 128 bytes");
        }
        if (!unique_tools.insert(tool).second) {
            throw std::invalid_argument("tool names must be unique");
        }
    }

    const json execution = input.value("execution", json::object());
    if (!execution.is_object()) {
        throw std::invalid_argument("execution must be an object");
    }
    const std::set<std::string> execution_fields = {
        "argument_source", "confidence_threshold", "max_steps", "max_new_tokens",
    };
    for (const auto & item : execution.items()) {
        if (execution_fields.find(item.key()) == execution_fields.end()) {
            throw std::invalid_argument("unknown agent execution field: " + item.key());
        }
    }
    const std::string argument_source = execution.value("argument_source", "needle");
    const double confidence_threshold = execution.value("confidence_threshold", 0.5);
    const int max_steps = execution.value("max_steps", 8);
    const int max_new_tokens = execution.value("max_new_tokens", 256);
    if (argument_source != "llm" && argument_source != "needle") {
        throw std::invalid_argument("execution.argument_source must be llm or needle");
    }
    if (confidence_threshold < 0.0 || confidence_threshold > 1.0) {
        throw std::invalid_argument("execution.confidence_threshold must be between 0 and 1");
    }
    if (max_steps < 1 || max_steps > 16) {
        throw std::invalid_argument("execution.max_steps must be between 1 and 16");
    }
    if (max_new_tokens < 1 || max_new_tokens > 512) {
        throw std::invalid_argument("execution.max_new_tokens must be between 1 and 512");
    }

    return {
        {"schema_version", 1},
        {"id", id},
        {"name", name},
        {"description", description},
        {"instructions", instructions},
        {"tools", tools},
        {"execution", {
            {"argument_source", argument_source},
            {"confidence_threshold", confidence_threshold},
            {"max_steps", max_steps},
            {"max_new_tokens", max_new_tokens},
        }},
    };
}

server_http_res_ptr json_response(const json & body, int status = 200) {
    auto response = std::make_unique<server_http_res>();
    response->status = status;
    response->data = safe_json_to_str(body);
    return response;
}

server_http_res_ptr error_response(const std::string & message, int status) {
    const error_type type = status == 400 || status == 409 ? ERROR_TYPE_INVALID_REQUEST : ERROR_TYPE_SERVER;
    json error = format_error_response(message, type);
    error["code"] = status;
    return json_response({{"error", error}}, status);
}

class sqlite_statement {
public:
    sqlite_statement(sqlite3 * db, const char * sql) {
        if (sqlite3_prepare_v2(db, sql, -1, &statement, nullptr) != SQLITE_OK) {
            throw std::runtime_error("failed to prepare agent database statement");
        }
    }

    ~sqlite_statement() {
        sqlite3_finalize(statement);
    }

    sqlite3_stmt * get() const {
        return statement;
    }

private:
    sqlite3_stmt * statement = nullptr;
};

void bind_text(sqlite3_stmt * statement, int index, const std::string & value) {
    if (sqlite3_bind_text(statement, index, value.c_str(), (int) value.size(), SQLITE_TRANSIENT) != SQLITE_OK) {
        throw std::runtime_error("failed to bind agent database value");
    }
}

json read_definition(sqlite3_stmt * statement) {
    const char * tools_text = reinterpret_cast<const char *>(sqlite3_column_text(statement, 4));
    return {
        {"schema_version", 1},
        {"id", reinterpret_cast<const char *>(sqlite3_column_text(statement, 0))},
        {"name", reinterpret_cast<const char *>(sqlite3_column_text(statement, 1))},
        {"description", reinterpret_cast<const char *>(sqlite3_column_text(statement, 2))},
        {"instructions", reinterpret_cast<const char *>(sqlite3_column_text(statement, 3))},
        {"tools", json::parse(tools_text ? tools_text : "[]")},
        {"execution", {
            {"argument_source", reinterpret_cast<const char *>(sqlite3_column_text(statement, 5))},
            {"confidence_threshold", sqlite3_column_double(statement, 6)},
            {"max_steps", sqlite3_column_int(statement, 7)},
            {"max_new_tokens", sqlite3_column_int(statement, 8)},
        }},
        {"built_in", sqlite3_column_int(statement, 9) != 0},
        {"created_at", sqlite3_column_int64(statement, 10)},
        {"updated_at", sqlite3_column_int64(statement, 11)},
    };
}

} // namespace

struct server_agent_store::impl {
    sqlite3 * db = nullptr;
    mutable std::mutex mutex;

    explicit impl(const std::string & path) {
        const int flags = SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX;
        if (sqlite3_open_v2(path.c_str(), &db, flags, nullptr) != SQLITE_OK) {
            const std::string message = db ? sqlite3_errmsg(db) : "unknown error";
            if (db) {
                sqlite3_close(db);
                db = nullptr;
            }
            throw std::runtime_error("failed to open agent database: " + message);
        }
        execute("PRAGMA busy_timeout = 5000");
        execute("PRAGMA journal_mode = WAL");
        execute("CREATE TABLE IF NOT EXISTS agent_definitions ("
                "id TEXT PRIMARY KEY,"
                "name TEXT NOT NULL,"
                "description TEXT NOT NULL,"
                "instructions TEXT NOT NULL,"
                "tools_json TEXT NOT NULL,"
                "argument_source TEXT NOT NULL,"
                "confidence_threshold REAL NOT NULL,"
                "max_steps INTEGER NOT NULL,"
                "max_new_tokens INTEGER NOT NULL,"
                "built_in INTEGER NOT NULL DEFAULT 0,"
                "created_at INTEGER NOT NULL,"
                "updated_at INTEGER NOT NULL"
                ")");
        seed_invoice_agent();
        seed_pos_agent();
        seed_store_agent();
    }

    ~impl() {
        if (db) {
            sqlite3_close(db);
        }
    }

    void execute(const char * sql) {
        char * error = nullptr;
        if (sqlite3_exec(db, sql, nullptr, nullptr, &error) != SQLITE_OK) {
            const std::string message = error ? error : "unknown error";
            sqlite3_free(error);
            throw std::runtime_error("agent database operation failed: " + message);
        }
    }

    void seed_invoice_agent() {
        const json definition = validate_definition({
            {"id", "invoice-agent"},
            {"name", "Invoice Agent"},
            {"description", "Extracts invoice details, submits validated data to ERP, and summarizes the result."},
            {"instructions", "Process the supplied invoice. Extract and validate its details, submit the validated invoice to ERP, and summarize only completed work."},
            {"tools", {"invoice_extract_invoice_details", "invoice_send_invoice_to_erp"}},
            {"execution", {
                {"argument_source", "llm"},
                {"confidence_threshold", 0.5},
                {"max_steps", 4},
                {"max_new_tokens", 512},
            }},
        });
        sqlite_statement statement(db,
            "INSERT OR IGNORE INTO agent_definitions "
            "(id, name, description, instructions, tools_json, argument_source, confidence_threshold, max_steps, max_new_tokens, built_in, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)");
        bind_definition(statement.get(), definition);
        const int64_t timestamp = now_ms();
        sqlite3_bind_int64(statement.get(), 10, timestamp);
        sqlite3_bind_int64(statement.get(), 11, timestamp);
        if (sqlite3_step(statement.get()) != SQLITE_DONE) {
            throw std::runtime_error("failed to seed Invoice Agent");
        }
    }

    void seed_pos_agent() {
        const json definition = validate_definition({
            {"id", "pos-agent"},
            {"name", "POS Agent"},
            {"description", "Answers sales, product, and inventory questions from verified POS reports."},
            {"instructions", "Use only POS reporting tools for business facts. Treat today as the server-local calendar day and last month as the previous calendar month. Rank best-selling items by quantity unless the user asks for revenue. State the reporting period and never invent missing values."},
            {"tools", {"pos_sales_summary", "pos_top_selling_items", "pos_inventory_status"}},
            {"execution", {
                {"argument_source", "needle"},
                {"confidence_threshold", 0.0},
                {"max_steps", 1},
                {"max_new_tokens", 256},
            }},
        });
        sqlite_statement statement(db,
            "INSERT OR IGNORE INTO agent_definitions "
            "(id, name, description, instructions, tools_json, argument_source, confidence_threshold, max_steps, max_new_tokens, built_in, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)");
        bind_definition(statement.get(), definition);
        const int64_t timestamp = now_ms();
        sqlite3_bind_int64(statement.get(), 10, timestamp);
        sqlite3_bind_int64(statement.get(), 11, timestamp);
        if (sqlite3_step(statement.get()) != SQLITE_DONE) {
            throw std::runtime_error("failed to seed POS Agent");
        }
    }

    void seed_store_agent() {
        const json definition = validate_definition({
            {"id", "store-agent"},
            {"name", "Store Agent"},
            {"description", "Answers online store product, inventory, category, and order questions."},
            {"instructions", "Use only online store tools for storefront facts. Use store_inventory_status for stock questions, including low-stock requests. Treat products at or below the requested threshold as low stock and state the threshold used."},
            {"tools", {"store_list_products", "store_inventory_status", "store_add_product", "store_update_product", "store_list_orders", "store_add_order", "store_list_categories", "store_add_category"}},
            {"execution", {
                {"argument_source", "needle"},
                {"confidence_threshold", 0.0},
                {"max_steps", 1},
                {"max_new_tokens", 256},
            }},
        });
        sqlite_statement statement(db,
            "INSERT OR IGNORE INTO agent_definitions "
            "(id, name, description, instructions, tools_json, argument_source, confidence_threshold, max_steps, max_new_tokens, built_in, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)");
        bind_definition(statement.get(), definition);
        const int64_t timestamp = now_ms();
        sqlite3_bind_int64(statement.get(), 10, timestamp);
        sqlite3_bind_int64(statement.get(), 11, timestamp);
        if (sqlite3_step(statement.get()) != SQLITE_DONE) {
            throw std::runtime_error("failed to seed Store Agent");
        }
    }

    static void bind_definition(sqlite3_stmt * statement, const json & definition) {
        const json & execution = definition.at("execution");
        bind_text(statement, 1, definition.at("id").get<std::string>());
        bind_text(statement, 2, definition.at("name").get<std::string>());
        bind_text(statement, 3, definition.at("description").get<std::string>());
        bind_text(statement, 4, definition.at("instructions").get<std::string>());
        bind_text(statement, 5, definition.at("tools").dump());
        bind_text(statement, 6, execution.at("argument_source").get<std::string>());
        sqlite3_bind_double(statement, 7, execution.at("confidence_threshold").get<double>());
        sqlite3_bind_int(statement, 8, execution.at("max_steps").get<int>());
        sqlite3_bind_int(statement, 9, execution.at("max_new_tokens").get<int>());
    }

    json find(const std::string & id) const {
        std::lock_guard<std::mutex> lock(mutex);
        return find_locked(id);
    }

    json find_locked(const std::string & id) const {
        sqlite_statement statement(db,
            "SELECT id, name, description, instructions, tools_json, argument_source, confidence_threshold, max_steps, max_new_tokens, built_in, created_at, updated_at "
            "FROM agent_definitions WHERE id = ?");
        bind_text(statement.get(), 1, id);
        if (sqlite3_step(statement.get()) != SQLITE_ROW) {
            return nullptr;
        }
        return read_definition(statement.get());
    }

    json list() const {
        std::lock_guard<std::mutex> lock(mutex);
        sqlite_statement statement(db,
            "SELECT id, name, description, instructions, tools_json, argument_source, confidence_threshold, max_steps, max_new_tokens, built_in, created_at, updated_at "
            "FROM agent_definitions ORDER BY built_in DESC, name COLLATE NOCASE, id");
        json result = json::array();
        int status;
        while ((status = sqlite3_step(statement.get())) == SQLITE_ROW) {
            result.push_back(read_definition(statement.get()));
        }
        if (status != SQLITE_DONE) {
            throw std::runtime_error("failed to list agent definitions");
        }
        return result;
    }

    json create(const json & input) {
        const json definition = validate_definition(input);
        std::lock_guard<std::mutex> lock(mutex);
        sqlite_statement count_statement(db, "SELECT COUNT(*) FROM agent_definitions");
        if (sqlite3_step(count_statement.get()) != SQLITE_ROW) {
            throw std::runtime_error("failed to count agent definitions");
        }
        if (sqlite3_column_int64(count_statement.get(), 0) >= static_cast<int64_t>(AGENT_DEFINITIONS_MAX)) {
            throw std::invalid_argument("agent definition limit reached");
        }
        sqlite_statement statement(db,
            "INSERT INTO agent_definitions "
            "(id, name, description, instructions, tools_json, argument_source, confidence_threshold, max_steps, max_new_tokens, built_in, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)");
        bind_definition(statement.get(), definition);
        const int64_t timestamp = now_ms();
        sqlite3_bind_int64(statement.get(), 10, timestamp);
        sqlite3_bind_int64(statement.get(), 11, timestamp);
        const int status = sqlite3_step(statement.get());
        if (status == SQLITE_CONSTRAINT) {
            throw std::invalid_argument("an agent with this id already exists");
        }
        if (status != SQLITE_DONE) {
            throw std::runtime_error("failed to create agent definition");
        }
        return find_locked(definition.at("id").get<std::string>());
    }

    json update(const std::string & id, const json & input) {
        const json definition = validate_definition(input, id);
        std::lock_guard<std::mutex> lock(mutex);
        sqlite_statement statement(db,
            "UPDATE agent_definitions SET name = ?, description = ?, instructions = ?, tools_json = ?, argument_source = ?, confidence_threshold = ?, max_steps = ?, max_new_tokens = ?, updated_at = ? WHERE id = ?");
        bind_text(statement.get(), 1, definition.at("name").get<std::string>());
        bind_text(statement.get(), 2, definition.at("description").get<std::string>());
        bind_text(statement.get(), 3, definition.at("instructions").get<std::string>());
        bind_text(statement.get(), 4, definition.at("tools").dump());
        const json & execution = definition.at("execution");
        bind_text(statement.get(), 5, execution.at("argument_source").get<std::string>());
        sqlite3_bind_double(statement.get(), 6, execution.at("confidence_threshold").get<double>());
        sqlite3_bind_int(statement.get(), 7, execution.at("max_steps").get<int>());
        sqlite3_bind_int(statement.get(), 8, execution.at("max_new_tokens").get<int>());
        sqlite3_bind_int64(statement.get(), 9, now_ms());
        bind_text(statement.get(), 10, id);
        if (sqlite3_step(statement.get()) != SQLITE_DONE) {
            throw std::runtime_error("failed to update agent definition");
        }
        if (sqlite3_changes(db) == 0) {
            return nullptr;
        }
        return find_locked(id);
    }

    int remove(const std::string & id) {
        std::lock_guard<std::mutex> lock(mutex);
        const json existing = find_locked(id);
        if (existing.is_null()) {
            return 0;
        }
        if (existing.value("built_in", false)) {
            return -1;
        }
        sqlite_statement statement(db, "DELETE FROM agent_definitions WHERE id = ?");
        bind_text(statement.get(), 1, id);
        if (sqlite3_step(statement.get()) != SQLITE_DONE) {
            throw std::runtime_error("failed to delete agent definition");
        }
        return sqlite3_changes(db);
    }
};

server_agent_store::server_agent_store(const std::string & path)
    : pimpl(std::make_unique<impl>(path)) {
    handle_list = [this](const server_http_req &) -> server_http_res_ptr {
        return json_response({{"agents", pimpl->list()}});
    };
    handle_get = [this](const server_http_req & req) -> server_http_res_ptr {
        const json definition = pimpl->find(req.get_param("id"));
        return definition.is_null() ? error_response("agent not found", 404) : json_response(definition);
    };
    handle_create = [this](const server_http_req & req) -> server_http_res_ptr {
        try {
            if (req.body.size() > AGENT_DEFINITION_BODY_MAX_BYTES) {
                throw std::invalid_argument("agent definition must contain at most 65536 bytes");
            }
            return json_response(pimpl->create(json::parse(req.body)), 201);
        } catch (const json::exception & e) {
            return error_response(e.what(), 400);
        } catch (const std::invalid_argument & e) {
            const int status = std::string(e.what()).find("already exists") != std::string::npos ? 409 : 400;
            return error_response(e.what(), status);
        }
    };
    handle_update = [this](const server_http_req & req) -> server_http_res_ptr {
        try {
            if (req.body.size() > AGENT_DEFINITION_BODY_MAX_BYTES) {
                throw std::invalid_argument("agent definition must contain at most 65536 bytes");
            }
            const json definition = pimpl->update(req.get_param("id"), json::parse(req.body));
            return definition.is_null() ? error_response("agent not found", 404) : json_response(definition);
        } catch (const json::exception & e) {
            return error_response(e.what(), 400);
        } catch (const std::invalid_argument & e) {
            return error_response(e.what(), 400);
        }
    };
    handle_delete = [this](const server_http_req & req) -> server_http_res_ptr {
        const int removed = pimpl->remove(req.get_param("id"));
        if (removed < 0) {
            return error_response("built-in agents cannot be deleted", 400);
        }
        if (removed == 0) {
            return error_response("agent not found", 404);
        }
        auto response = std::make_unique<server_http_res>();
        response->status = 204;
        return response;
    };
}

server_agent_store::~server_agent_store() = default;

json server_agent_store::get_definition(const std::string & id) const {
    if (!valid_id(id)) {
        return nullptr;
    }
    return pimpl->find(id);
}
