#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# get-whisper.sh
# Downloads whisper.cpp source files into this directory and patches them
# to use llama.cpp's ggml instead of whisper.cpp's vendored copy.
#
# Run once from the repo root:
#   bash tools/server/whisper/get-whisper.sh
#
# Then rebuild:
#   cmake -B build && cmake --build build --target dexai -j$(nproc)
#
# Requires: curl, python3
# ---------------------------------------------------------------------------

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WHISPER_TAG="master"
BASE="https://raw.githubusercontent.com/ggml-org/whisper.cpp/${WHISPER_TAG}"

cd "$SCRIPT_DIR"

echo "[whisper] downloading source files from ggml-org/whisper.cpp @ ${WHISPER_TAG} ..."

curl -fsSL "${BASE}/include/whisper.h"     -o whisper.h
curl -fsSL "${BASE}/src/whisper-arch.h"    -o whisper-arch.h
curl -fsSL "${BASE}/src/whisper.cpp"       -o whisper.cpp

echo "[whisper] patching: removing optional accelerator blocks and private ggml headers ..."

python3 - <<'PYEOF'
import re

for fname in ("whisper.cpp", "whisper.h"):
    try:
        src = open(fname).read()
    except FileNotFoundError:
        continue

    for macro in ("WHISPER_USE_COREML", "WHISPER_USE_OPENVINO", "WHISPER_USE_VITISAI"):
        lines_out = []
        depth = 0
        skip = False
        for line in src.splitlines(keepends=True):
            stripped = line.strip()
            if stripped.startswith(f"#ifdef {macro}") or stripped.startswith(f"#if defined({macro})"):
                skip = True
                depth = 1
                continue
            if skip:
                if re.match(r"#\s*if(n?def)?\s", stripped):
                    depth += 1
                elif stripped.startswith("#endif"):
                    depth -= 1
                    if depth == 0:
                        skip = False
                continue
            lines_out.append(line)
        src = "".join(lines_out)

    src = re.sub(r'^\s*#\s*include\s+"ggml-backend-impl\.h"\s*\n', '', src, flags=re.MULTILINE)
    open(fname, "w").write(src)
    print(f"  patched {fname}")
PYEOF

echo ""
echo "[whisper] done."
echo ""
echo "Files written to: $SCRIPT_DIR"
echo "  whisper.h"
echo "  whisper-arch.h"
echo "  whisper.cpp"
echo ""
echo "Now rebuild dexai:"
echo "  cmake -B build && cmake --build build --target dexai -j\$(nproc)"
echo ""
echo "Then start with a whisper model, e.g.:"
echo "  # Download whisper-small GGUF from HuggingFace (ggerganov/whisper.cpp)"
echo "  dexai --model lfm2-1.6b.gguf --voice-model ggml-small.gguf --voice-language hi"
