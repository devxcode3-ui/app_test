#pragma once

#include "server-http.h"

#include <memory>
#include <string>

struct server_tools;
class server_agent_store;

class server_agent {
public:
    server_agent(
            const std::string & needle_library,
            server_http_context::handler_t chat_handler,
            server_tools & tools,
            server_agent_store * store = nullptr);
    ~server_agent();

    server_agent(const server_agent &) = delete;
    server_agent & operator=(const server_agent &) = delete;

    server_http_context::handler_t handle_post;
    server_http_context::handler_t handle_post_stored;

private:
    struct impl;
    std::unique_ptr<impl> pimpl;
};
