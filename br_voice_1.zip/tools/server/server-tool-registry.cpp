#include "server-tool-registry.h"

#include <sqlite3.h>

#include <algorithm>
#include <cctype>
#include <mutex>
#include <set>
#include <sstream>
#include <stdexcept>

namespace {
const std::set<std::string> stopwords = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "if", "in", "is", "it", "of", "on", "or", "the", "to", "under", "with"
};

const std::set<std::string> generic_words = {
    "command", "content", "file", "files", "info", "output", "path", "result", "search", "shell", "tool", "use"
};

std::vector<std::string> words(const std::string & value) {
    std::string normalized = value;
    std::replace(normalized.begin(), normalized.end(), '_', ' ');
    std::replace(normalized.begin(), normalized.end(), '-', ' ');
    std::transform(normalized.begin(), normalized.end(), normalized.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    std::istringstream stream(normalized);
    std::vector<std::string> result;
    std::string word;
    while (stream >> word) {
        word.erase(std::remove_if(word.begin(), word.end(), [](unsigned char c) { return !std::isalnum(c); }), word.end());
        if (word.size() > 1 && !stopwords.count(word)) result.push_back(word);
    }
    return result;
}

std::string join_unique(const std::vector<std::string> & values, bool omit_generic = false) {
    std::set<std::string> unique;
    for (const auto & value : values) {
        if (!omit_generic || !generic_words.count(value)) unique.insert(value);
    }
    std::string result;
    for (const auto & value : unique) {
        if (!result.empty()) result += ' ';
        result += value;
    }
    return result;
}

std::string inferred_verbs(const std::string & name) {
    static const std::set<std::string> verbs = {
        "add", "create", "delete", "edit", "execute", "get", "list", "read", "remove", "run", "save", "search", "send", "update", "write"
    };
    std::vector<std::string> result;
    for (const auto & token : words(name)) if (verbs.count(token)) result.push_back(token);
    return join_unique(result);
}

std::string inferred_entities(const std::string & name, const std::string & description) {
    auto result = words(name);
    const auto description_words = words(description);
    result.insert(result.end(), description_words.begin(), description_words.end());
    return join_unique(result, true);
}

std::string metadata(const json & definition, const char * key, const std::string & fallback) {
    if (!definition.contains(key) || !definition.at(key).is_array()) return fallback;
    std::string result;
    for (const auto & value : definition.at(key)) {
        if (!value.is_string()) continue;
        if (!result.empty()) result += ' ';
        result += join_unique(words(value.get<std::string>()));
    }
    return result.empty() ? fallback : result;
}

server_http_res_ptr response(const json & body, int status = 200) {
    auto result = std::make_unique<server_http_res>();
    result->status = status;
    result->data = safe_json_to_str(body);
    return result;
}
}

struct server_tool_registry::impl {
    sqlite3 * db = nullptr;
    mutable std::mutex mutex;
    std::vector<tool_summary> cache;

    explicit impl(const std::string & path) {
        if (path.empty()) return;
        if (sqlite3_open_v2(path.c_str(), &db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, nullptr) != SQLITE_OK) {
            throw std::runtime_error("failed to open tool registry database");
        }
        exec("PRAGMA busy_timeout = 5000");
        exec("CREATE TABLE IF NOT EXISTS tool_registry (name TEXT PRIMARY KEY, description TEXT NOT NULL, verbs TEXT NOT NULL, entities TEXT NOT NULL, keywords TEXT NOT NULL)");
        load();
    }

    ~impl() { if (db) sqlite3_close(db); }

    void exec(const char * sql) {
        char * error = nullptr;
        if (sqlite3_exec(db, sql, nullptr, nullptr, &error) != SQLITE_OK) {
            std::string message = error ? error : "unknown error";
            sqlite3_free(error);
            throw std::runtime_error(message);
        }
    }

    void load() {
        if (!db) return;
        sqlite3_stmt * stmt = nullptr;
        if (sqlite3_prepare_v2(db, "SELECT name, description, verbs, entities, keywords FROM tool_registry ORDER BY name", -1, &stmt, nullptr) != SQLITE_OK) throw std::runtime_error("failed to load tool registry");
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            cache.push_back({
                reinterpret_cast<const char *>(sqlite3_column_text(stmt, 0)),
                reinterpret_cast<const char *>(sqlite3_column_text(stmt, 1)),
                reinterpret_cast<const char *>(sqlite3_column_text(stmt, 2)),
                reinterpret_cast<const char *>(sqlite3_column_text(stmt, 3)),
                reinterpret_cast<const char *>(sqlite3_column_text(stmt, 4)),
            });
        }
        sqlite3_finalize(stmt);
    }

    void seed(const json & definitions, bool force) {
        std::lock_guard<std::mutex> lock(mutex);
        if (!force && !cache.empty()) return;
        std::vector<tool_summary> next;
        for (const auto & definition : definitions) {
            const std::string name = definition.at("name").get<std::string>();
            const std::string description = definition.value("description", "");
            const std::string entity_terms = inferred_entities(name, description);
            const std::string keyword_terms = join_unique(words(name + " " + description), true);
            next.push_back({name, description,
                metadata(definition, "verbs", inferred_verbs(name)),
                metadata(definition, "entities", entity_terms), keyword_terms});
        }
        if (db) {
            exec("BEGIN IMMEDIATE");
            try {
                exec("DELETE FROM tool_registry");
                for (const auto & tool : next) {
                    sqlite3_stmt * stmt = nullptr;
                    if (sqlite3_prepare_v2(db, "INSERT INTO tool_registry (name, description, verbs, entities, keywords) VALUES (?, ?, ?, ?, ?)", -1, &stmt, nullptr) != SQLITE_OK) throw std::runtime_error("failed to prepare tool registry insert");
                    const std::string values[] = {tool.name, tool.description, tool.verbs, tool.entities, tool.keywords};
                    for (int index = 0; index < 5; ++index) sqlite3_bind_text(stmt, index + 1, values[index].c_str(), -1, SQLITE_TRANSIENT);
                    if (sqlite3_step(stmt) != SQLITE_DONE) { sqlite3_finalize(stmt); throw std::runtime_error("failed to write tool registry"); }
                    sqlite3_finalize(stmt);
                }
                exec("COMMIT");
            } catch (...) { try { exec("ROLLBACK"); } catch (...) {} throw; }
        }
        cache = std::move(next);
    }
};

server_tool_registry::server_tool_registry(const std::string & path) : pimpl(std::make_unique<impl>(path)) {
    handle_get = [this](const server_http_req &) {
        std::lock_guard<std::mutex> lock(pimpl->mutex);
        json tools = json::array();
        for (const auto & tool : pimpl->cache) tools.push_back({{"name", tool.name}, {"description", tool.description}, {"verbs", tool.verbs}, {"entities", tool.entities}, {"keywords", tool.keywords}});
        return response({{"tools", tools}});
    };
    handle_seed = [this](const server_http_req & req) {
        try {
            const json body = json::parse(req.body);
            if (!body.value("definitions", json()).is_array()) return response({{"error", "definitions must be an array"}}, 400);
            pimpl->seed(body.at("definitions"), true);
            return response({{"seeded", static_cast<int>(pimpl->cache.size())}});
        } catch (const std::exception & error) { return response({{"error", error.what()}}, 400); }
    };
}

server_tool_registry::~server_tool_registry() = default;
void server_tool_registry::seed(const json & definitions, bool force) { pimpl->seed(definitions, force); }
std::vector<tool_summary> server_tool_registry::get_summaries() const { std::lock_guard<std::mutex> lock(pimpl->mutex); return pimpl->cache; }
