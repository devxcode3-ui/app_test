import os
import shutil
import subprocess

import pytest
from utils import *


#@pytest.fixture(scope="module")
def needle_stub(tmp_path_factory):
    if os.name == "nt":
        pytest.skip("Needle stub build is not configured for Windows")
    compiler = shutil.which("cc")
    if compiler is None:
        pytest.skip("C compiler is required for the Needle agent test")
    source = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "fixtures", "needle_stub.c"))
    output = tmp_path_factory.mktemp("needle") / "libneedle_stub.so"
    subprocess.run([compiler, "-shared", "-fPIC", source, "-o", output], check=True)
    return str(output)


def make_server(needle_stub):
    server = ServerPreset.tinyllama2()
    server.server_tools = "get_info"
    server.agent_needle_lib = needle_stub
    server.n_ctx = 1024
    server.n_predict = 64
    return server


def test_agent_executes_tool_and_summarizes(needle_stub):
    server = make_server(needle_stub)
    server.start()

    response = server.make_request("POST", "/v1/agent", data={
        "prompt": "Inspect the runtime and report what completed.",
        "max_steps": 4,
        "max_new_tokens": 64,
    })

    assert response.status_code == 200, response.body
    assert response.body["status"] == "completed"
    assert response.body["stop_reason"] == "completed"
    assert isinstance(response.body["plan"], list)
    assert response.body["steps"][0]["tool"] == "get_info"
    assert response.body["steps"][0]["plan_step"] == response.body["plan"][0]["action"]
    assert response.body["steps"][0]["reasoning"] == "matched requested capability"
    assert "os" in response.body["steps"][0]["result"]
    assert isinstance(response.body["summary"], str)
    assert response.body["summary"].strip()
    assert response.body["summary"] != '{"task_completed": true}'


def test_agent_rejects_empty_tool_allowlist(needle_stub):
    server = make_server(needle_stub)
    server.start()

    response = server.make_request("POST", "/v1/agent", data={
        "prompt": "Inspect the runtime.",
        "tools": [],
    })

    assert response.status_code == 400, response.body
    assert "tools must contain 1 to 32 tool names" in response.body["error"]["message"]


def test_agent_stops_before_low_confidence_call(needle_stub):
    server = make_server(needle_stub)
    server.start()

    response = server.make_request("POST", "/v1/agent", data={
        "prompt": "low-confidence runtime request",
        "confidence_threshold": 0.8,
        "max_new_tokens": 32,
    })

    assert response.status_code == 200, response.body
    assert response.body["status"] == "stopped"
    assert response.body["stop_reason"] == "low_confidence"
    assert response.body["steps"] == []


def test_agent_rejects_write_call_without_permission(needle_stub):
    server = ServerPreset.tinyllama2()
    server.server_tools = "get_info,write_file"
    server.agent_needle_lib = needle_stub
    server.n_ctx = 1024
    server.start()

    response = server.make_request("POST", "/v1/agent", data={
        "prompt": "attempt-write",
        "max_steps": 1,
        "max_new_tokens": 32,
    })

    assert response.status_code == 200, response.body
    assert "requires allow_write" in response.body["steps"][0]["result"]["error"]


def test_agent_definitions_crud_and_persistence(tmp_path):
    database = tmp_path / "agents.db"
    server = ServerPreset.tinyllama2()
    server.agent_db = str(database)
    server.start()

    response = server.make_request("GET", "/v1/agents")
    assert response.status_code == 200, response.body
    assert response.body["agents"][0]["id"] == "invoice-agent"

    definition = {
        "schema_version": 1,
        "id": "inventory-agent",
        "name": "Inventory Agent",
        "description": "Checks local inventory.",
        "instructions": "Inspect inventory and report verified results.",
        "tools": ["get_info"],
        "execution": {
            "argument_source": "needle",
            "confidence_threshold": 0.6,
            "max_steps": 2,
            "max_new_tokens": 128,
        },
    }
    response = server.make_request("POST", "/v1/agents", data=definition)
    assert response.status_code == 201, response.body
    assert response.body["id"] == definition["id"]

    definition["description"] = "Checks inventory and runtime information."
    response = server.make_request("PUT", "/v1/agents/inventory-agent", data=definition)
    assert response.status_code == 200, response.body
    assert response.body["description"] == definition["description"]

    server.stop()
    server.start()
    response = server.make_request("GET", "/v1/agents/inventory-agent")
    assert response.status_code == 200, response.body
    assert response.body["name"] == "Inventory Agent"

    response = server.make_request("DELETE", "/v1/agents/inventory-agent")
    assert response.status_code == 204, response.body
    response = server.make_request("GET", "/v1/agents/inventory-agent")
    assert response.status_code == 404, response.body


def test_stored_agent_uses_definition_tools(needle_stub, tmp_path):
    server = make_server(needle_stub)
    server.agent_db = str(tmp_path / "agents.db")
    server.start()

    definition = {
        "name": "Runtime Agent",
        "description": "Inspects the runtime.",
        "instructions": "Use only verified runtime information.",
        "tools": ["get_info"],
    }
    created = server.make_request("POST", "/v1/agents", data=definition)
    assert created.status_code == 201, created.body

    response = server.make_request(
        "POST",
        f"/v1/agents/{created.body['id']}/run",
        data={"prompt": "Inspect the runtime."},
    )
    assert response.status_code == 200, response.body
    assert response.body["agent_id"] == created.body["id"]
    assert response.body["steps"][0]["tool"] == "get_info"


def test_agent_definition_rejects_unknown_fields(tmp_path):
    server = ServerPreset.tinyllama2()
    server.agent_db = str(tmp_path / "agents.db")
    server.start()

    response = server.make_request("POST", "/v1/agents", data={
        "name": "Unsafe Agent",
        "instructions": "Do a task.",
        "tools": ["get_info"],
        "command": "ignored-command",
    })

    assert response.status_code == 400, response.body
    assert "unknown agent definition field" in response.body["error"]["message"]


def test_app_definitions_crud_validation_and_persistence(tmp_path):
    database = tmp_path / "apps.db"
    server = ServerPreset.tinyllama2()
    server.agent_db = str(database)
    server.start()

    response = server.make_request("GET", "/v1/apps")
    assert response.status_code == 200, response.body
    app_ids = [app["id"] for app in response.body["apps"]]
    assert "pos_app" in app_ids
    assert "store_app" in app_ids
    store_app = next(app for app in response.body["apps"] if app["id"] == "store_app")
    assert store_app["tools"] == [
        "store_list_products",
        "store_add_product",
        "store_update_product",
        "store_list_orders",
        "store_add_order",
        "store_list_categories",
        "store_add_category",
    ]

    definition = {
        "id": "inventory_app",
        "name": "Inventory",
        "description": "Inventory reporting.",
        "launch_url": "http://127.0.0.1:4180",
        "agent_id": "inventory-agent",
        "tools": ["inventory_status"],
        "prompt": {
            "domain": "Warehouse inventory.",
            "entities": ["product", "stock_level"],
            "instructions": "Use inventory tools and report verified quantities.",
        },
    }
    response = server.make_request("POST", "/v1/apps", data=definition)
    assert response.status_code == 201, response.body
    assert response.body["id"] == definition["id"]

    server.stop()
    server.start()
    response = server.make_request("GET", "/v1/apps/inventory_app")
    assert response.status_code == 200, response.body
    assert response.body["prompt"]["entities"] == ["product", "stock_level"]

    invalid = dict(definition)
    invalid["id"] = "invalid_app"
    invalid["launch_url"] = "javascript:alert(1)"
    response = server.make_request("POST", "/v1/apps", data=invalid)
    assert response.status_code == 400, response.body
    assert "HTTP or HTTPS" in response.body["error"]["message"]

    response = server.make_request("DELETE", "/v1/apps/inventory_app")
    assert response.status_code == 204, response.body
