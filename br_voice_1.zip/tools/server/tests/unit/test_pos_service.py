import datetime as dt
import importlib.util
import json
import threading
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

import pytest


MODULE_PATH = Path(__file__).parents[2] / "apps" / "pos" / "pos_service.py"
SPEC = importlib.util.spec_from_file_location("pos_service", MODULE_PATH)
pos_service = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(pos_service)


def seed(store):
    store.record_sale({
        "id": "sale-1",
        "sold_at": "2026-08-25T10:00:00Z",
        "items": [
            {"product_id": "coffee", "name": "Coffee", "sku": "COF", "quantity": 3, "unit_price_cents": 500, "stock_quantity": 20},
            {"product_id": "tea", "name": "Tea", "sku": "TEA", "quantity": 1, "unit_price_cents": 400, "stock_quantity": 2},
        ],
    })
    store.record_sale({
        "id": "sale-2",
        "sold_at": "2026-08-26T10:00:00Z",
        "items": [
            {"product_id": "tea", "name": "Tea", "sku": "TEA", "quantity": 5, "unit_price_cents": 400, "stock_quantity": 2},
        ],
    })


def test_reporting_uses_half_open_boundaries_and_explicit_ranking(tmp_path):
    store = pos_service.PosStore(str(tmp_path / "pos.db"))
    seed(store)

    summary = store.sales_summary("2026-08-25T00:00:00Z", "2026-08-26T00:00:00Z")
    assert summary["transaction_count"] == 1
    assert summary["articles_sold"] == 4
    assert summary["revenue_cents"] == 1900

    result = store.top_selling_items("2026-08-01T00:00:00Z", "2026-09-01T00:00:00Z", 10, "quantity")
    assert result["items"][0]["product_id"] == "tea"
    assert result["items"][0]["quantity_sold"] == 6


def test_last_month_is_previous_calendar_month():
    now = dt.datetime(2026, 8, 25, 12, tzinfo=dt.timezone.utc)
    assert pos_service.period_bounds("last_month", now) == (
        "2026-07-01T00:00:00Z",
        "2026-08-01T00:00:00Z",
    )


def test_reporting_api_rejects_missing_token(tmp_path):
    store = pos_service.PosStore(str(tmp_path / "pos.db"))
    server = ThreadingHTTPServer(("127.0.0.1", 0), pos_service.PosApiHandler)
    server.store = store
    server.api_token = "test-token"
    server.static_dir = None
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        url = f"http://127.0.0.1:{server.server_port}/api/v1/reports/sales-summary?period=today"
        with pytest.raises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(url)
        assert error.value.code == 401
        assert json.loads(error.value.read())["error"] == "unauthorized"
    finally:
        server.shutdown()
        server.server_close()
        thread.join()
