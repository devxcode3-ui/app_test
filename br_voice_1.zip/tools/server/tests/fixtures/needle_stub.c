#include <stdio.h>
#include <string.h>

static int turn;

int needle_init(const char * system, const char * tools, const char * index_path) {
    (void) system;
    (void) tools;
    (void) index_path;
    turn = 0;
    return 0;
}

int needle_complete(const char * input, int max_tokens, char * output, int output_size) {
    (void) max_tokens;
    const char * response;
    if (turn++ == 0) {
        if (strstr(input, "\nPlan:\n")) {
            response = "{\"type\":\"call\",\"function_calls\":[],\"confidence\":0.99}";
        } else {
            const double confidence = strstr(input, "low-confidence") ? 0.1 : 0.99;
            const char * tool = strstr(input, "attempt-write") ? "write_file" : "get_info";
            const char * arguments = strstr(input, "attempt-write")
                ? "{\"path\":\"/tmp/needle-agent-forbidden-write\",\"content\":\"blocked\"}"
                : "{}";
            static char call[512];
            snprintf(call, sizeof(call),
                "{\"type\":\"call\",\"function_calls\":[{\"name\":\"%s\",\"arguments\":%s}],\"reasoning\":\"matched requested capability\",\"confidence\":%.2f}",
                tool, arguments, confidence);
            response = call;
        }
    } else {
        response = "{\"type\":\"respond\",\"function_calls\":[],\"confidence\":0.99}";
    }
    const int length = (int) strlen(response);
    if (length + 1 > output_size) {
        return -1;
    }
    memcpy(output, response, (size_t) length + 1);
    return 0;
}

void needle_reset(void) {
    turn = 0;
}
