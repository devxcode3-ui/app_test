#pragma once

#include "server-http.h"

#include <functional>
#include <memory>
#include <string>
#include <vector>

struct voice_config {
    // Path to a whisper GGUF model file for standalone ASR (no multimodal LLM needed).
    // When set and DEXAI_HAS_WHISPER is defined, whisper_full() is called directly.
    // Leave empty to fall back to the existing /v1/audio/transcriptions handler.
    std::string model_path;

    // Language forcing — "" = auto-detect; "hi", "bn", "pa", "gu"
    // Note: Odia ("or") is not in Whisper's language table — use "" for auto-detect
    // or load an IndicWhisper fine-tuned model.
    std::string default_language;

    // Displayed in /v1/voice/health; no functional effect
    std::string model_hint;

    // Reject audio longer than this
    int max_duration_s = 300;

    // Number of CPU threads for Whisper inference (0 = half of hardware threads)
    int n_threads = 0;

    // VAD tuning (used by POST /v1/voice/stream/chunk)
    float vad_threshold  = 0.6f;   // silence if energy_last < thold * energy_all
    float vad_freq_thold = 100.0f; // high-pass cutoff Hz applied before VAD
    int   vad_last_ms    = 1500;   // "recent" window in ms for silence detection

    // Audio resampling target
    int sample_rate = 16000;
};

class server_voice {
public:
    server_voice(server_http_context::handler_t transcribe_handler,
                 const voice_config & cfg);
    ~server_voice();
    server_voice(const server_voice &)             = delete;
    server_voice & operator=(const server_voice &) = delete;

    // HTTP handlers — register as routes in server.cpp
    server_http_context::handler_t handle_transcribe;       // POST /v1/voice/transcribe
    server_http_context::handler_t handle_stream_chunk;     // POST /v1/voice/stream/chunk
    server_http_context::handler_t handle_get_health;       // GET  /v1/voice/health
    server_http_context::handler_t handle_get_languages;    // GET  /v1/voice/languages

    // Internal API — call directly from server-notification for WhatsApp audio
    std::string transcribe_audio(const std::vector<uint8_t> & audio_data,
                                 const std::string          & mime_type,
                                 const std::string          & language_hint = "") const;

private:
    struct impl;
    std::unique_ptr<impl> pimpl;
};
