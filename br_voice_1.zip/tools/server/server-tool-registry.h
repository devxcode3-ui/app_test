#pragma once

#include "server-common.h"
#include "server-http.h"

#include <memory>
#include <string>
#include <vector>

struct tool_summary {
    std::string name;
    std::string description;
    std::string verbs;
    std::string entities;
    std::string keywords;
};

class server_tool_registry {
public:
    explicit server_tool_registry(const std::string & db_path = {});
    ~server_tool_registry();
    server_tool_registry(const server_tool_registry &) = delete;
    server_tool_registry & operator=(const server_tool_registry &) = delete;

    void seed(const json & definitions, bool force = false);
    std::vector<tool_summary> get_summaries() const;
    server_http_context::handler_t handle_get;
    server_http_context::handler_t handle_seed;

private:
    struct impl;
    std::unique_ptr<impl> pimpl;
};
