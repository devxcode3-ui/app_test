#include "server-query-processor.h"

#include <algorithm>
#include <cctype>
#include <sstream>
#include <stdexcept>
#include <unordered_set>

namespace {
std::string prompt_preview(const std::string & prompt) {
    constexpr size_t max_preview = 160;
    std::string preview = prompt.substr(0, max_preview);
    std::replace(preview.begin(), preview.end(), '\n', ' ');
    std::replace(preview.begin(), preview.end(), '\r', ' ');
    if (prompt.size() > max_preview) preview += "...";
    return preview;
}

std::string lower(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return value;
}

std::vector<std::string> words(const std::string & value) {
    std::istringstream stream(lower(value));
    std::vector<std::string> result;
    std::string word;
    while (stream >> word) {
        word.erase(std::remove_if(word.begin(), word.end(), [](unsigned char c) { return !std::isalnum(c); }), word.end());
        if (word.size() > 1) result.push_back(word);
    }
    return result;
}

std::unordered_set<std::string> word_set(const std::string & value) {
    const auto parsed = words(value);
    return {parsed.begin(), parsed.end()};
}

int word_hits(const std::unordered_set<std::string> & prompt_words, const std::string & terms) {
    int hits = 0;
    for (const auto & term : words(terms)) if (prompt_words.count(term) != 0) ++hits;
    return hits;
}

server_http_res_ptr result(const json & body, int status = 200) {
    auto response = std::make_unique<server_http_res>();
    response->status = status;
    response->data = safe_json_to_str(body);
    return response;
}
}

struct server_query_processor::impl {
    server_http_context::handler_t chat_handler;
    server_tool_registry & registry;

    impl(server_http_context::handler_t handler, server_tool_registry & value) : chat_handler(std::move(handler)), registry(value) {}

    json classify(const std::string & prompt) const {
        const auto tools = registry.get_summaries();
        const auto prompt_words = word_set(prompt);
        json selected = json::array();
        int best_score = 0;
        SRV_INF("query routing: prompt_bytes=%zu registry_tools=%zu preview=\\\"%s\\\"\n", prompt.size(), tools.size(), prompt_preview(prompt).c_str());
        for (const auto & tool : tools) {
            const int verb_hits = word_hits(prompt_words, tool.verbs);
            const int entity_hits = word_hits(prompt_words, tool.entities);
            const int keyword_hits = word_hits(prompt_words, tool.keywords);
            const int score = verb_hits * 3 + entity_hits * 2 + keyword_hits;
            SRV_DBG("query routing: tool=\\\"%s\\\" verb_hits=%d entity_hits=%d keyword_hits=%d score=%d\n", tool.name.c_str(), verb_hits, entity_hits, keyword_hits, score);
            if (score > best_score) best_score = score;
            if (score >= 5 && verb_hits > 0 && entity_hits > 0) selected.push_back(tool.name);
        }
        const bool needs_tools = best_score >= 5;
        if (!needs_tools) {
            SRV_INF("query routing result: needs_tools=false best_score=%d\n", best_score);
            return {{"needs_tools", false}, {"tool_names", json::array()}, {"confidence", 1.0}};
        }
        if (selected.empty()) {
            SRV_INF("query routing result: needs_tools=true selected=all reason=low-confidence best_score=%d\n", best_score);
            return {{"needs_tools", true}, {"tool_names", json::array()}, {"confidence", 0.0}};
        }
        const double confidence = std::min(1.0, static_cast<double>(best_score) / 6.0);
        SRV_INF("query routing result: needs_tools=true selected=%zu confidence=%.2f best_score=%d\n", selected.size(), confidence, best_score);
        return {{"needs_tools", true}, {"tool_names", selected}, {"confidence", confidence}};
    }
};

server_query_processor::server_query_processor(server_http_context::handler_t handler, server_tool_registry & registry)
    : pimpl(std::make_unique<impl>(std::move(handler), registry)) {
    handle_post = [this](const server_http_req & req) {
        try {
            const json body = json::parse(req.body);
            const std::string prompt = body.at("prompt").get<std::string>();
            if (prompt.empty() || prompt.size() > 8192) {
                SRV_WRN("query routing rejected: prompt_bytes=%zu (limit 1..8192)\n", prompt.size());
                return result({{"error", "prompt must be 1 to 8192 bytes"}}, 400);
            }
            return result(pimpl->classify(prompt));
        } catch (const std::exception & error) {
            SRV_WRN("query routing request failed: %s\n", error.what());
            return result({{"error", error.what()}}, 400);
        }
    };
}

server_query_processor::~server_query_processor() = default;
