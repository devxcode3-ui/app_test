#!/usr/bin/env bash

set -euo pipefail

pos_app_dir="${POS_APP_DIR:-$script_dir/../apps/pos}"

if [[ ! -f "$pos_app_dir/index.html" && -f "$script_dir/../../pos/index.html" ]]; then
    pos_app_dir="$script_dir/../../pos"
fi

if [[ ! -f "$pos_app_dir/index.html" ]]; then
    echo "POS_APP_DIR does not contain index.html: $pos_app_dir" >&2
    echo "Set POS_APP_DIR to the folder that contains the POS static site." >&2
fi

server_bin="${LLAMA_SERVER_BIN:-./build/bin/llama-server}"
agent_db="${LLAMA_AGENT_DB:-./agents.db}"
pid_file="${LLAMA_AGENT_APPS_PID_FILE:-/tmp/llama-agent-apps.pid}"
server_host="${LLAMA_SERVER_HOST:-0.0.0.0}"
server_port="${LLAMA_SERVER_PORT:-18093}"
server_ctx_size="${LLAMA_SERVER_CTX_SIZE:-10000}"
model_path="${LLAMA_MODEL:-/home/ubuntu/models/LFM2.5-VL-1.6B-UD-Q4_K_XL.gguf}"
pos_port="${POS_APP_PORT:-4174}"
pos_db="${POS_DB:-}"
store_port="${STORE_APP_PORT:-4175}"
store_db="${STORE_DB:-}"
pos_api_token="${POS_API_TOKEN:-local-pos-token}"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
pos_db="${pos_db:-$script_dir/../../../pos/data/pos.db}"
store_db="${store_db:-$script_dir/../../../store/data/store.db}"
pos_service="${POS_SERVICE:-$script_dir/../apps/pos/pos_service.py}"
if [[ ! -f "$pos_service" && -f "$script_dir/../../pos/pos_service.py" ]]; then
    pos_service="$script_dir/../../pos/pos_service.py"
fi
store_service="${STORE_SERVICE:-$script_dir/../../../store/store_service.py}"
relay_agent_enabled="${APP_RELAY_AGENT_ENABLED:-0}"
relay_agent_bin="${APP_RELAY_AGENT_BIN:-$script_dir/../../../app_relay/bin/app-relay-agent}"
relay_agent_config="${APP_RELAY_AGENT_CONFIG:-$script_dir/../../../app_relay/agent.json}"
store_relay_api="${STORE_RELAY_API:-}"
store_relay_host="${STORE_RELAY_HOST:-}"
store_relay_scheme="${STORE_RELAY_SCHEME:-}"
store_relay_user_id="${STORE_RELAY_USER_ID:-}"
store_relay_token="${STORE_RELAY_TOKEN:-}"
whatsapp_port="${WHATSAPP_APP_PORT:-8765}"
whatsapp_env_file="${WHATSAPP_ENV_FILE:-$script_dir/../../../evolution_test/local.env}"
whatsapp_inbox="${WHATSAPP_INBOX:-$script_dir/../apps/notification/data/whatsapp.db}"
whatsapp_media_dir="${WHATSAPP_MEDIA_DIR:-$script_dir/../apps/notification/data/whatsapp-media}"
whatsapp_enabled="${WHATSAPP_ENABLED:-1}"
whatsapp_service="${WHATSAPP_SERVICE:-$script_dir/../apps/notification/whatsapp.py}"
invoice_service="${INVOICE_SERVICE:-/home/ubuntu/llama_cpp/agent/invoice_mcp.py}"
invoice_pythonpath="${INVOICE_PYTHONPATH:-/home/ubuntu/llama_cpp:/home/ubuntu/llama_cpp/agent}"
erp_mock_url="${ERP_MOCK_URL:-http://127.0.0.1:3000/invoices}"
server_pid=""
pos_pid=""
store_pid=""
relay_agent_pid=""
whatsapp_pid=""

cleanup() {
    kill ${server_pid:-} ${pos_pid:-} ${store_pid:-} ${relay_agent_pid:-} ${whatsapp_pid:-} 2>/dev/null || true
    wait ${server_pid:-} ${pos_pid:-} ${store_pid:-} ${relay_agent_pid:-} ${whatsapp_pid:-} 2>/dev/null || true
    rm -f "$pid_file"
}

trap cleanup EXIT INT TERM

if [[ ! -f "$pos_service" ]]; then
    echo "POS_SERVICE does not exist: $pos_service" >&2
    exit 2
fi

if [[ ! -f "$store_service" ]]; then
    echo "STORE_SERVICE does not exist: $store_service" >&2
    exit 2
fi

if [[ "$relay_agent_enabled" == "1" ]]; then
    if [[ ! -x "$relay_agent_bin" ]]; then
        echo "APP_RELAY_AGENT_BIN is not executable: $relay_agent_bin" >&2
        exit 2
    fi
    if [[ ! -f "$relay_agent_config" ]]; then
        echo "APP_RELAY_AGENT_CONFIG does not exist: $relay_agent_config" >&2
        exit 2
    fi
fi

if [[ "$whatsapp_enabled" == "1" && ! -f "$whatsapp_service" ]]; then
    echo "WHATSAPP_SERVICE does not exist: $whatsapp_service" >&2
    exit 2
fi

check_port() {
    local port="$1"
    if python3 - "$port" <<'PY'
import socket
import sys

with socket.socket() as sock:
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("127.0.0.1", int(sys.argv[1])))
PY
    then
        return 0
    fi
    echo "Port $port is already in use; set the corresponding *_PORT variable or stop the existing process." >&2
    exit 1
}

check_port "$pos_port"
check_port "$store_port"
if [[ "$whatsapp_enabled" == "1" ]]; then
    check_port "$whatsapp_port"
# Read relay credentials from agent.json if not provided as environment variables
if [[ -z "$store_relay_user_id" && -z "$store_relay_token" && -f "$relay_agent_config" ]]; then
    store_relay_user_id=$(python3 -c "import json; print(json.load(open('$relay_agent_config')).get('user_id', ''))" 2>/dev/null || echo "")
    store_relay_token=$(python3 -c "import json; print(json.load(open('$relay_agent_config')).get('token', ''))" 2>/dev/null || echo "")
fi

fi

POS_API_TOKEN="$pos_api_token" python3 "$pos_service" serve --port "$pos_port" --db "$pos_db" --static-dir "$pos_app_dir" &
pos_pid=$!

STORE_RELAY_API="$store_relay_api" STORE_RELAY_HOST="$store_relay_host" STORE_RELAY_SCHEME="$store_relay_scheme" STORE_RELAY_USER_ID="$store_relay_user_id" STORE_RELAY_TOKEN="$store_relay_token" APP_RELAY_AGENT_CONFIG="$relay_agent_config" STORE_APP_PORT="$store_port" python3 "$store_service" serve --host 127.0.0.1 --port "$store_port" --db "$store_db" &
store_pid=$!

if [[ "$relay_agent_enabled" == "1" ]]; then
    "$relay_agent_bin" -config "$relay_agent_config" &
    relay_agent_pid=$!
fi

if [[ "$whatsapp_enabled" == "1" ]]; then
    python3 "$whatsapp_service" serve --env-file "$whatsapp_env_file" --inbox "$whatsapp_inbox" --media-dir "$whatsapp_media_dir" --host 0.0.0.0 --port "$whatsapp_port" &
    whatsapp_pid=$!
fi

mcp_servers_json="${LLAMA_MCP_SERVERS_JSON:-}"
mcp_servers_json="$(MCP_JSON="$mcp_servers_json" INVOICE_SERVICE="$invoice_service" INVOICE_PYTHONPATH="$invoice_pythonpath" ERP_MOCK_URL="$erp_mock_url" POS_SERVICE="$pos_service" POS_DB_PATH="$pos_db" STORE_SERVICE="$store_service" STORE_DB_PATH="$store_db" WHATSAPP_SERVICE="$whatsapp_service" WHATSAPP_ENV_FILE="$whatsapp_env_file" WHATSAPP_INBOX="$whatsapp_inbox" WHATSAPP_MEDIA_DIR="$whatsapp_media_dir" WHATSAPP_ENABLED="$whatsapp_enabled" python3 -c '
import json
import os

configured = json.loads(os.environ["MCP_JSON"]) if os.environ["MCP_JSON"] else {"mcpServers": {}}
servers = configured.setdefault("mcpServers", {})
servers.setdefault("invoice", {"command": "python3", "args": [os.environ["INVOICE_SERVICE"]], "env": {"PYTHONPATH": os.environ["INVOICE_PYTHONPATH"], "ERP_MOCK_URL": os.environ["ERP_MOCK_URL"]}})
servers.setdefault("pos", {"command": "python3", "args": [os.environ["POS_SERVICE"], "mcp", "--db", os.environ["POS_DB_PATH"]]})
servers.setdefault("store", {"command": "python3", "args": [os.environ["STORE_SERVICE"], "mcp", "--db", os.environ["STORE_DB_PATH"]]})
if os.environ["WHATSAPP_ENABLED"] == "1":
    servers.setdefault("whatsapp", {"command": "python3", "args": [os.environ["WHATSAPP_SERVICE"], "mcp", "--env-file", os.environ["WHATSAPP_ENV_FILE"], "--inbox", os.environ["WHATSAPP_INBOX"], "--media-dir", os.environ["WHATSAPP_MEDIA_DIR"]]})
print(json.dumps(configured))
')"

agent_args=()
if [[ ! " $* " =~ [[:space:]](-m|--model)([[:space:]=]) ]]; then
    agent_args+=(--model "$model_path")
fi
if [[ -n "${LLAMA_AGENT_NEEDLE_LIB:-}" ]]; then
    agent_args+=(--agent-needle-lib "$LLAMA_AGENT_NEEDLE_LIB")
fi

"$server_bin" --host "$server_host" --port "$server_port" --ctx-size "$server_ctx_size" --agent-db "$agent_db" --mcp-servers-json "$mcp_servers_json" "${agent_args[@]}" "$@" &
server_pid=$!

cat > "$pid_file" <<EOF
launcher $BASHPID
server $server_pid
pos $pos_pid
store $store_pid
relay-agent ${relay_agent_pid:-}
whatsapp ${whatsapp_pid:-}
EOF

while kill -0 "$server_pid" 2>/dev/null && kill -0 "$pos_pid" 2>/dev/null && kill -0 "$store_pid" 2>/dev/null && { [[ "$relay_agent_enabled" != "1" ]] || kill -0 "$relay_agent_pid" 2>/dev/null; } && { [[ -z "$whatsapp_pid" ]] || kill -0 "$whatsapp_pid" 2>/dev/null; }; do
    wait -n "$server_pid" "$pos_pid" "$store_pid" || true
done

exit 1
