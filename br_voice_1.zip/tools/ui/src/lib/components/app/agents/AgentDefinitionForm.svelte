<script lang="ts">
	import { Button } from '$lib/components/ui/button';
	import { Input } from '$lib/components/ui/input';
	import { Textarea } from '$lib/components/ui/textarea';
	import type { AgentDefinitionInput } from '$lib/types';
	import { untrack } from 'svelte';

	interface Props {
		definition?: AgentDefinitionInput;
		disabled?: boolean;
		onsubmit: (definition: AgentDefinitionInput) => void | Promise<void>;
		submitLabel?: string;
	}

	let { definition, disabled = false, onsubmit, submitLabel = 'Save agent' }: Props = $props();

	const initial = untrack(() => definition);
	let argumentSource = $state<'llm' | 'needle'>(initial?.execution?.argument_source ?? 'needle');
	let confidenceThreshold = $state(initial?.execution?.confidence_threshold ?? 0.5);
	let description = $state(initial?.description ?? '');
	let id = $state(initial?.id ?? '');
	let instructions = $state(initial?.instructions ?? '');
	let maxNewTokens = $state(initial?.execution?.max_new_tokens ?? 256);
	let maxSteps = $state(initial?.execution?.max_steps ?? 8);
	let name = $state(initial?.name ?? '');
	let tools = $state(initial?.tools.join('\n') ?? '');

	function submit(event: SubmitEvent) {
		event.preventDefault();
		const toolNames = tools
			.split(/[\n,]/)
			.map((tool) => tool.trim())
			.filter(Boolean);

		void onsubmit({
			description: description.trim(),
			execution: {
				argument_source: argumentSource,
				confidence_threshold: Number(confidenceThreshold),
				max_new_tokens: Number(maxNewTokens),
				max_steps: Number(maxSteps)
			},
			id: id.trim() || undefined,
			instructions: instructions.trim(),
			name: name.trim(),
			schema_version: 1,
			tools: [...new Set(toolNames)]
		});
	}
</script>

<form class="space-y-5" onsubmit={submit}>
	<div class="grid gap-4 md:grid-cols-2">
		<label class="space-y-2 text-sm font-medium">
			<span>Name</span>
			<Input bind:value={name} {disabled} maxlength={100} required />
		</label>
		<label class="space-y-2 text-sm font-medium">
			<span>ID</span>
			<Input
				bind:value={id}
				disabled={disabled || Boolean(initial?.id)}
				maxlength={64}
				pattern="[A-Za-z0-9_-]+"
				placeholder="Generated when blank"
			/>
		</label>
	</div>
	<label class="block space-y-2 text-sm font-medium">
		<span>Description</span>
		<Textarea bind:value={description} {disabled} maxlength={1024} rows={3} />
	</label>
	<label class="block space-y-2 text-sm font-medium">
		<span>Instructions</span>
		<Textarea bind:value={instructions} {disabled} maxlength={32768} required rows={8} />
	</label>
	<label class="block space-y-2 text-sm font-medium">
		<span>Registered tools</span>
		<Textarea
			bind:value={tools}
			{disabled}
			placeholder="One tool name per line"
			required
			rows={5}
		/>
		<span class="block text-xs font-normal text-muted-foreground"
			>Tool schemas remain in the server registry. Definitions store names only.</span
		>
	</label>
	<div class="grid gap-4 md:grid-cols-4">
		<label class="space-y-2 text-sm font-medium">
			<span>Argument source</span>
			<select
				bind:value={argumentSource}
				class="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
				{disabled}
			>
				<option value="needle">Needle</option>
				<option value="llm">LLM</option>
			</select>
		</label>
		<label class="space-y-2 text-sm font-medium">
			<span>Confidence</span>
			<Input
				bind:value={confidenceThreshold}
				{disabled}
				max={1}
				min={0}
				step={0.05}
				type="number"
			/>
		</label>
		<label class="space-y-2 text-sm font-medium">
			<span>Max steps</span>
			<Input bind:value={maxSteps} {disabled} max={16} min={1} type="number" />
		</label>
		<label class="space-y-2 text-sm font-medium">
			<span>Max tokens</span>
			<Input bind:value={maxNewTokens} {disabled} max={512} min={1} type="number" />
		</label>
	</div>
	<Button disabled={disabled || !name.trim() || !instructions.trim() || !tools.trim()} type="submit"
		>{submitLabel}</Button
	>
</form>
