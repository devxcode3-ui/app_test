#!/usr/bin/env python3
"""Import the electronics repository CSV formats into the local store database."""

import argparse
import csv
import re
import sqlite3
import sys
import uuid
from pathlib import Path

DEFAULT_DB = Path(__file__).with_name("data") / "store.db"
DEFAULT_FILES = (
    "bulk-upload-example.csv",
    "product-template-ready.csv",
    "product.csv",
)
CATEGORY_ALIASES = {
    "57943bc3-f5a3-4733-86a7-76ed3c4fde82": "electronics",
    "a54d7eab-6d86-42d3-a021-d286ab4fb852": "laptops",
    "659a91b9-3ff6-47d5-9830-5e7ac905b961": "audio",
    "ss6412b4-22fd-4fbb-9741-d77580dfdcd2": "televisions",
    "1cb9439a-ea47-4a33-913b-e9bf935bcc0b": "cameras",
}


def slugify(value: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return value or "product"


def parse_price(value: str) -> int:
    cleaned = value.strip().replace(",", "")
    if not cleaned:
        raise ValueError("price is required")
    amount = float(cleaned)
    if amount < 0:
        raise ValueError("price must not be negative")
    return round(amount * 100)


def parse_stock(value: str) -> int:
    stock = int(value.strip() or "0")
    if stock < 0:
        raise ValueError("inStock must not be negative")
    return stock


def canonical_category(value: str) -> str:
    key = value.strip().lower()
    return CATEGORY_ALIASES.get(key, slugify(value).replace("-", " "))


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError("CSV has no header")
        return [{key.strip(): (value or "").strip() for key, value in row.items()} for row in reader]


def normalize(row: dict[str, str], source: Path, row_number: int) -> dict:
    title = row.get("title", "").strip()
    manufacturer = row.get("manufacturer", "").strip()
    if not title or not manufacturer:
        raise ValueError("title and manufacturer are required")
    raw_slug = row.get("slug", "").strip()
    category_value = row.get("categoryId", "").strip() or row.get("category", "").strip()
    if not category_value:
        raise ValueError("categoryId or category is required")
    slug = slugify(raw_slug or f"{manufacturer}-{title}")
    return {
        "sku": f"{slugify(manufacturer)}-{slug}",
        "name": title,
        "description": row.get("description", ""),
        "category": canonical_category(category_value),
        "price_cents": parse_price(row.get("price", "")),
        "stock_quantity": parse_stock(row.get("inStock", "")),
        "image_url": row.get("mainImage", ""),
        "source": f"{source.name}:{row_number}",
    }


def initialize(db: sqlite3.Connection) -> None:
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS categories (
            id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS products (
            id TEXT PRIMARY KEY, sku TEXT NOT NULL UNIQUE, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            category_id TEXT, price_cents INTEGER NOT NULL, stock_quantity INTEGER NOT NULL DEFAULT 0,
            image_url TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
            FOREIGN KEY(category_id) REFERENCES categories(id)
        );
        """
    )


def import_files(db_path: Path, files: list[Path], dry_run: bool = False) -> dict[str, int]:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(db_path)
    now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
    summary = {"files": 0, "rows": 0, "imported": 0, "failed": 0, "categories": 0}
    try:
        initialize(db)
        for path in files:
            rows = read_rows(path)
            summary["files"] += 1
            for row_number, row in enumerate(rows, 2):
                summary["rows"] += 1
                try:
                    product = normalize(row, path, row_number)
                    category = db.execute("SELECT id FROM categories WHERE lower(name) = lower(?)", (product["category"],)).fetchone()
                    if category is None:
                        category_id = str(uuid.uuid4())
                        db.execute("INSERT INTO categories (id, name, description, created_at) VALUES (?, ?, ?, ?)", (category_id, product["category"].title(), "Imported from electronics catalog", now))
                        summary["categories"] += 1
                    else:
                        category_id = category[0]
                    existing = db.execute("SELECT id FROM products WHERE sku = ?", (product["sku"],)).fetchone()
                    if not dry_run:
                        product_id = existing[0] if existing else str(uuid.uuid4())
                        db.execute(
                            "INSERT INTO products (id, sku, name, description, category_id, price_cents, stock_quantity, image_url, active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?) "
                            "ON CONFLICT(sku) DO UPDATE SET name=excluded.name, description=excluded.description, category_id=excluded.category_id, price_cents=excluded.price_cents, stock_quantity=excluded.stock_quantity, image_url=excluded.image_url, active=1",
                            (product_id, product["sku"], product["name"], product["description"], category_id, product["price_cents"], product["stock_quantity"], product["image_url"], now),
                        )
                    summary["imported"] += 1
                except (ValueError, TypeError, sqlite3.IntegrityError) as error:
                    summary["failed"] += 1
                    print(f"{path}:{row_number}: {error}", file=sys.stderr)
        if dry_run:
            db.rollback()
        else:
            db.commit()
    finally:
        db.close()
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", nargs="*", type=Path, help="CSV files to import")
    parser.add_argument("--db", type=Path, default=DEFAULT_DB)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    files = args.files or [Path(__file__).with_name(name) for name in DEFAULT_FILES]
    missing = [str(path) for path in files if not path.is_file()]
    if missing:
        parser.error("CSV file not found: " + ", ".join(missing))
    summary = import_files(args.db, files, args.dry_run)
    prefix = "dry-run: " if args.dry_run else "imported: "
    print(prefix + str(summary))
    return 1 if summary["failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
