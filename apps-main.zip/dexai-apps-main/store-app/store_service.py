#!/usr/bin/env python3

import argparse
import json
import os
import signal
import sqlite3
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


DEFAULT_DB = Path(__file__).with_name("data") / "store.db"


class Store:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS categories (
                    id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS products (
                    id TEXT PRIMARY KEY, sku TEXT NOT NULL UNIQUE, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
                    category_id TEXT, price_cents INTEGER NOT NULL, stock_quantity INTEGER NOT NULL DEFAULT 0,
                    image_url TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
                    FOREIGN KEY(category_id) REFERENCES categories(id)
                );
                CREATE TABLE IF NOT EXISTS orders (
                    id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, customer_phone TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'pending', total_cents INTEGER NOT NULL, created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS order_items (
                    order_id TEXT NOT NULL, product_id TEXT NOT NULL, quantity INTEGER NOT NULL, unit_price_cents INTEGER NOT NULL,
                    PRIMARY KEY(order_id, product_id), FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(product_id) REFERENCES products(id)
                );
                CREATE TABLE IF NOT EXISTS relay_config (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    url TEXT NOT NULL DEFAULT '',
                    enabled INTEGER NOT NULL DEFAULT 0
                );
            """)

    def connect(self):
        db = sqlite3.connect(self.db_path)
        db.row_factory = sqlite3.Row
        return db

    @staticmethod
    def now():
        import datetime
        return datetime.datetime.now(datetime.timezone.utc).isoformat()

    @staticmethod
    def row(row):
        return dict(row) if row else None

    def list_categories(self):
        with self.lock, self.connect() as db:
            return [self.row(row) for row in db.execute("SELECT * FROM categories ORDER BY name COLLATE NOCASE")]

    def add_category(self, name, description=""):
        if not name.strip():
            raise ValueError("category name is required")
        category_id = str(uuid.uuid4())
        with self.lock, self.connect() as db:
            db.execute("INSERT INTO categories VALUES (?, ?, ?, ?)", (category_id, name.strip(), description.strip(), self.now()))
            db.commit()
        return self.get_category(category_id)

    def get_category(self, category_id):
        with self.connect() as db:
            return self.row(db.execute("SELECT * FROM categories WHERE id = ?", (category_id,)).fetchone())

    def list_products(self, active_only=False):
        query = "SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id"
        if active_only:
            query += " WHERE p.active = 1"
        query += " ORDER BY p.name COLLATE NOCASE"
        with self.lock, self.connect() as db:
            return [self.row(row) for row in db.execute(query)]

    def inventory_status(self, low_stock_only=False, threshold=5, limit=50):
        if not 0 <= int(threshold) <= 100000 or not 1 <= int(limit) <= 100:
            raise ValueError("threshold or limit is out of range")
        query = "SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.active = 1"
        params = []
        if low_stock_only:
            query += " AND p.stock_quantity <= ?"
            params.append(int(threshold))
        query += " ORDER BY p.stock_quantity, p.name COLLATE NOCASE LIMIT ?"
        params.append(int(limit))
        with self.lock, self.connect() as db:
            items = [self.row(row) for row in db.execute(query, params)]
        return {"low_stock_only": bool(low_stock_only), "threshold": int(threshold), "items": items}

    def add_product(self, product):
        required = ("sku", "name", "price_cents")
        if any(key not in product for key in required):
            raise ValueError("sku, name, and price_cents are required")
        product_id = str(uuid.uuid4())
        values = (
            product_id,
            product["sku"].strip(),
            product["name"].strip(),
            product.get("description", ""),
            product.get("category_id"),
            int(product["price_cents"]),
            int(product.get("stock_quantity", 0)),
            product.get("image_url", ""),
            int(product.get("active", True)),
            self.now(),
        )
        with self.lock, self.connect() as db:
            db.execute(
                "INSERT INTO products (id, sku, name, description, category_id, price_cents, stock_quantity, image_url, active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                values,
            )
            db.commit()
        return self.get_product(product_id)

    def update_product(self, product_id, changes):
        allowed = {"sku", "name", "description", "category_id", "price_cents", "stock_quantity", "image_url", "active"}
        changes = {key: value for key, value in changes.items() if key in allowed}
        if not changes:
            raise ValueError("no product fields to update")
        assignments = ", ".join(f"{key} = ?" for key in changes)
        with self.lock, self.connect() as db:
            cursor = db.execute(f"UPDATE products SET {assignments} WHERE id = ?", (*changes.values(), product_id))
            if cursor.rowcount == 0:
                raise ValueError("product not found")
            db.commit()
        return self.get_product(product_id)

    def get_product(self, product_id):
        with self.connect() as db:
            return self.row(db.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone())

    def list_orders(self, status=""):
        query = "SELECT * FROM orders"
        params = ()
        if status:
            query += " WHERE status = ?"
            params = (status,)
        query += " ORDER BY created_at DESC"
        with self.lock, self.connect() as db:
            orders = [self.row(row) for row in db.execute(query, params)]
            for order in orders:
                order["items"] = [self.row(row) for row in db.execute("SELECT * FROM order_items WHERE order_id = ?", (order["id"],))]
            return orders

    def add_order(self, order):
        items = order.get("items", [])
        if not order.get("customer_name") or not items:
            raise ValueError("customer_name and at least one item are required")
        order_id = str(uuid.uuid4())
        total = 0
        with self.lock, self.connect() as db:
            normalized = []
            for item in items:
                product = db.execute("SELECT id, price_cents FROM products WHERE id = ? AND active = 1", (item.get("product_id"),)).fetchone()
                quantity = int(item.get("quantity", 0))
                if not product or quantity < 1:
                    raise ValueError("each item needs an active product and positive quantity")
                total += product["price_cents"] * quantity
                normalized.append((product["id"], quantity, product["price_cents"]))
            db.execute("INSERT INTO orders VALUES (?, ?, ?, ?, ?, ?)", (order_id, order["customer_name"], order.get("customer_phone", ""), order.get("status", "pending"), total, self.now()))
            db.executemany("INSERT INTO order_items VALUES (?, ?, ?, ?)", [(order_id, product_id, quantity, price) for product_id, quantity, price in normalized])
            db.commit()
        return self.list_orders()[0]

    def get_relay_config(self):
        with self.lock, self.connect() as db:
            row = db.execute("SELECT url, enabled FROM relay_config WHERE id = 1").fetchone()
        return {"url": row["url"] if row else "", "enabled": bool(row["enabled"]) if row else False}

    def save_relay_config(self, url, enabled):
        with self.lock, self.connect() as db:
            db.execute(
                "INSERT INTO relay_config (id, url, enabled) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET url = excluded.url, enabled = excluded.enabled",
                (url, int(enabled)),
            )
            db.commit()


TOOLS = [
    ("store_list_products", "List products in the online store.", {"type": "object", "properties": {"active_only": {"type": "boolean"}}, "additionalProperties": False}),
    ("store_inventory_status", "List online store products and optionally return only products at or below a stock threshold.", {"type": "object", "properties": {"low_stock_only": {"type": "boolean", "default": False}, "threshold": {"type": "integer", "minimum": 0, "maximum": 100000, "default": 5}, "limit": {"type": "integer", "minimum": 1, "maximum": 100, "default": 50}}, "additionalProperties": False}),
    ("store_add_product", "Add a product to the online store.", {"type": "object", "properties": {"sku": {"type": "string"}, "name": {"type": "string"}, "description": {"type": "string"}, "category_id": {"type": "string"}, "price_cents": {"type": "integer"}, "stock_quantity": {"type": "integer"}, "image_url": {"type": "string"}}, "required": ["sku", "name", "price_cents"], "additionalProperties": False}),
    ("store_update_product", "Update product details in the online store.", {"type": "object", "properties": {"product_id": {"type": "string"}, "changes": {"type": "object"}}, "required": ["product_id", "changes"], "additionalProperties": False}),
    ("store_list_orders", "List online store orders.", {"type": "object", "properties": {"status": {"type": "string"}}, "additionalProperties": False}),
    ("store_add_order", "Create an online store order.", {"type": "object", "properties": {"customer_name": {"type": "string"}, "customer_phone": {"type": "string"}, "items": {"type": "array", "items": {"type": "object"}}}, "required": ["customer_name", "items"], "additionalProperties": False}),
    ("store_list_categories", "List product categories.", {"type": "object", "properties": {}, "additionalProperties": False}),
    ("store_add_category", "Add a product category.", {"type": "object", "properties": {"name": {"type": "string"}, "description": {"type": "string"}}, "required": ["name"], "additionalProperties": False}),
]


def mcp_response(value):
    return {"content": [{"type": "text", "text": json.dumps(value)}]}


def run_mcp(store):
    for line in sys.stdin:
        request = json.loads(line)
        method = request.get("method")
        if method == "initialize":
            result = {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}, "serverInfo": {"name": "online-store", "version": "1.0"}}
        elif method == "notifications/initialized":
            continue
        elif method == "tools/list":
            result = {"tools": [{"name": name, "description": description, "inputSchema": schema} for name, description, schema in TOOLS]}
        elif method == "tools/call":
            params = request.get("params", {})
            args = params.get("arguments", {})
            name = params.get("name")
            actions = {"store_list_products": lambda: store.list_products(args.get("active_only", False)), "store_inventory_status": lambda: store.inventory_status(args.get("low_stock_only", False), args.get("threshold", 5), args.get("limit", 50)), "store_add_product": lambda: store.add_product(args), "store_update_product": lambda: store.update_product(args["product_id"], args["changes"]), "store_list_orders": lambda: store.list_orders(args.get("status", "")), "store_add_order": lambda: store.add_order(args), "store_list_categories": store.list_categories, "store_add_category": lambda: store.add_category(args["name"], args.get("description", ""))}
            if name not in actions:
                raise ValueError("unknown store tool")
            result = mcp_response(actions[name]())
        else:
            continue
        print(json.dumps({"jsonrpc": "2.0", "id": request.get("id"), "result": result}), flush=True)


def agent_config():
    config_path = Path(os.environ.get("APP_RELAY_AGENT_CONFIG", "/home/ubuntu/llama_cpp/app_relay/agent.json"))
    if not config_path.exists():
        return {}
    return json.loads(config_path.read_text())


def relay_request(method, path, payload=None):
    base_url = os.environ.get("STORE_RELAY_API", "http://127.0.0.1:18080").rstrip("/")
    config = agent_config()
    user_id = os.environ.get("STORE_RELAY_USER_ID", config.get("user_id", ""))
    token = os.environ.get("STORE_RELAY_TOKEN", config.get("token", ""))
    if not user_id or not token:
        raise ValueError("STORE_RELAY_USER_ID and STORE_RELAY_TOKEN are required")
    body = None if payload is None else json.dumps(payload).encode()
    request = Request(
        base_url + path,
        data=body,
        method=method,
        headers={
            "Authorization": f"Bearer {user_id}:{token}",
            "Content-Type": "application/json",
        },
    )
    with urlopen(request, timeout=10) as response:
        return json.loads(response.read())


def update_agent_config(enabled):
    local_port = int(os.environ.get("STORE_APP_PORT", "4175"))
    config_path = Path(os.environ.get("APP_RELAY_AGENT_CONFIG", "/home/ubuntu/llama_cpp/app_relay/agent.json"))
    config = {}
    if config_path.exists():
        config = agent_config()
    config.setdefault("relay_host", os.environ.get("STORE_RELAY_HOST", ""))
    config.setdefault("relay_scheme", os.environ.get("STORE_RELAY_SCHEME", "wss"))
    config.setdefault("user_id", os.environ.get("STORE_RELAY_USER_ID", ""))
    config.setdefault("token", os.environ.get("STORE_RELAY_TOKEN", ""))
    config["enabled_apps"] = {"store": local_port} if enabled else {}
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2) + "\n")
    config_path.chmod(0o600)

    pid_path = Path(os.environ.get("LLAMA_AGENT_APPS_PID_FILE", "/tmp/llama-agent-apps.pid"))
    if not pid_path.exists():
        return
    for line in pid_path.read_text().splitlines():
        role, _, pid = line.partition(" ")
        if role == "relay-agent" and pid.isdigit():
            os.kill(int(pid), signal.SIGHUP)
            return


class Handler(BaseHTTPRequestHandler):
    store = None

    def send_json(self, status, value):
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/":
            body = (Path(__file__).with_name("index.html")).read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if parsed.path == "/health":
            return self.send_json(200, {"status": "ok"})
        if parsed.path == "/api/categories":
            return self.send_json(200, self.store.list_categories())
        if parsed.path == "/api/products":
            return self.send_json(200, self.store.list_products(parse_qs(parsed.query).get("active_only", ["false"])[0] == "true"))
        if parsed.path == "/api/orders":
            return self.send_json(200, self.store.list_orders(parse_qs(parsed.query).get("status", [""])[0]))
        if parsed.path == "/api/relay/status":
            return self.send_json(200, self.store.get_relay_config())
        self.send_error(404)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length))
            if self.path == "/api/categories":
                return self.send_json(201, self.store.add_category(body["name"], body.get("description", "")))
            if self.path == "/api/products":
                return self.send_json(201, self.store.add_product(body))
            if self.path == "/api/orders":
                return self.send_json(201, self.store.add_order(body))
            if self.path == "/api/relay/enable":
                local_port = int(os.environ.get("STORE_APP_PORT", "4175"))
                result = relay_request("POST", "/api/apps", {"app_slug": "store", "app_label": "Online Store", "local_port": local_port})
                update_agent_config(True)
                self.store.save_relay_config(result["url"], True)
                return self.send_json(200, {**self.store.get_relay_config(), "url": result["url"]})
            if self.path == "/api/relay/disable":
                config = self.store.get_relay_config()
                if config["url"]:
                    relay_request("PATCH", "/api/apps/store", {"enabled": False})
                update_agent_config(False)
                self.store.save_relay_config(config["url"], False)
                return self.send_json(200, self.store.get_relay_config())
            self.send_error(404)
        except (KeyError, TypeError, ValueError, sqlite3.IntegrityError, HTTPError, URLError, OSError) as error:
            self.send_json(400, {"error": str(error)})

    def do_PATCH(self):
        try:
            if not self.path.startswith("/api/products/"):
                return self.send_error(404)
            length = int(self.headers.get("Content-Length", "0"))
            return self.send_json(200, self.store.update_product(self.path.rsplit("/", 1)[1], json.loads(self.rfile.read(length))))
        except (KeyError, TypeError, ValueError, sqlite3.IntegrityError) as error:
            self.send_json(400, {"error": str(error)})

    def log_message(self, *_args):
        return


class ReusableHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True


def main():
    parser = argparse.ArgumentParser(description="Online Store service and MCP server")
    parser.add_argument("mode", choices=["serve", "mcp"])
    parser.add_argument("--db", type=Path, default=DEFAULT_DB)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=4175)
    args = parser.parse_args()
    store = Store(args.db)
    if args.mode == "mcp":
        run_mcp(store)
        return
    Handler.store = store
    ReusableHTTPServer((args.host, args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()