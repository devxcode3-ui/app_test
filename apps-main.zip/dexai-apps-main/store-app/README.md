# Online Store App

This local app is based on the electronics storefront domain from `Kuzma02/Electronics-eCommerce-Shop-With-Admin-Dashboard-NextJS-NodeJS`, with a small Python/SQLite runtime suitable for the llama.cpp agent workflow.

The SQLite database is stored at `data/store.db` and contains categories, products, orders, and order items. The service exposes a local admin view at `http://127.0.0.1:4175` and an MCP stdio mode.

## Online access demo

The Store admin dashboard includes an **Online access** toggle. The Store
backend calls the relay API and asks the running relay agent to reload its
configuration, so enabling or disabling online access does not restart the
Store service.

Start the launcher with `APP_RELAY_AGENT_ENABLED=1` and configure these
variables in the Store process environment:

```sh
STORE_RELAY_API=http://127.0.0.1:18080
STORE_RELAY_HOST=relay.yourdomain.com
STORE_RELAY_SCHEME=wss
STORE_RELAY_USER_ID=u1001
STORE_RELAY_TOKEN=<token>
APP_RELAY_AGENT_CONFIG=/path/to/agent.json
LLAMA_AGENT_APPS_PID_FILE=/tmp/llama-agent-apps.pid
```

The relay token stays server-side and is never sent to browser code. Use a
real HTTPS relay domain in production; IP and `nip.io` URLs are for testing.

Run the app:

```sh
python3 store_service.py serve --host 127.0.0.1 --port 4175 --db /home/ubuntu/llama_cpp/store/data/store.db
```

MCP configuration entry:

```json
"store": {
  "command": "python3",
  "args": ["/home/ubuntu/llama_cpp/store/store_service.py", "mcp", "--db", "/home/ubuntu/llama_cpp/store/data/store.db"]
}
```

Registered tools are `store_list_products`, `store_add_product`, `store_update_product`, `store_list_orders`, `store_add_order`, `store_list_categories`, and `store_add_category`.