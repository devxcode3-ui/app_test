import json
import tempfile
import unittest
from pathlib import Path

from store_service import Store, run_mcp


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / "data" / "store.db")

    def tearDown(self):
        self.temp.cleanup()

    def test_product_category_and_order_lifecycle(self):
        category = self.store.add_category("Laptops", "Portable computers")
        product = self.store.add_product({"sku": "LT-1", "name": "Laptop", "category_id": category["id"], "price_cents": 125000, "stock_quantity": 4})
        self.assertEqual(self.store.update_product(product["id"], {"stock_quantity": 3})["stock_quantity"], 3)
        order = self.store.add_order({"customer_name": "Test Buyer", "items": [{"product_id": product["id"], "quantity": 2}]})
        self.assertEqual(order["total_cents"], 250000)
        self.assertEqual(self.store.list_orders()[0]["items"][0]["quantity"], 2)
        self.assertEqual(self.store.inventory_status(True, 3)["items"][0]["id"], product["id"])

    def test_mcp_lists_requested_tools(self):
        self.assertEqual({name for name, _, _ in __import__("store_service").TOOLS}, {"store_list_products", "store_inventory_status", "store_add_product", "store_update_product", "store_list_orders", "store_add_order", "store_list_categories", "store_add_category"})


if __name__ == "__main__":
    unittest.main()