#!/bin/sh
set -eu

echo "=== DexAI Apps Build and Release Workflow ==="

ROOT_DIR="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT_DIR"

mkdir -p build

APP_DIRS="pos-app store-app"

for APP in $APP_DIRS; do
  if [ ! -d "$APP" ]; then
    echo "Missing app directory: $APP"
    exit 1
  fi
done

echo "Packaging app bundles..."
for APP in $APP_DIRS; do
  ARCHIVE="build/${APP}.tar.gz"
  tar -czf "$ARCHIVE" "$APP"
  echo "Created $ARCHIVE"
done

CURRENT_TAG=$(git describe --tags --exact-match HEAD 2>/dev/null || echo "")

if [ -n "$CURRENT_TAG" ]; then
    echo "Detected tag: $CURRENT_TAG"
    RELEASE_DIR="release-${CURRENT_TAG}"
    rm -rf "$RELEASE_DIR"
    mkdir -p "$RELEASE_DIR"

    cp build/pos-app.tar.gz "$RELEASE_DIR/"
    cp build/store-app.tar.gz "$RELEASE_DIR/"
    cp README.md "$RELEASE_DIR/" 2>/dev/null || true

    tar -czf "${RELEASE_DIR}.tar.gz" "$RELEASE_DIR"

    if command -v curl >/dev/null 2>&1; then
        echo "Creating GitBucket release for ${CURRENT_TAG}..."

        RELEASE_DESCRIPTION="Release created from tag ${CURRENT_TAG}

## Included apps
- pos-app.tar.gz
- store-app.tar.gz
- README.md

## Notes
This release bundles both DexAI apps for deployment or distribution."

        RESPONSE=$(curl -sS -X POST "http://localhost:9090/api/projects/root/dexai-apps/releases" \
            -H "Content-Type: application/json" \
            -d "{
                \"tag_name\": \"${CURRENT_TAG}\",
                \"name\": \"DexAI Apps ${CURRENT_TAG}\",
                \"description\": \"${RELEASE_DESCRIPTION}\",
                \"draft\": false,
                \"prerelease\": false
            }" 2>&1 || true)

        if printf '%s' "$RESPONSE" | grep -qiE 'error|Error'; then
            echo "GitBucket release API reported an error: $RESPONSE"
            echo "Continuing anyway..."
        else
            echo "GitBucket release created successfully"
            echo "URL: http://localhost:9090/root/dexai-apps/releases/${CURRENT_TAG}"
        fi
    else
        echo "curl not found; skipped GitBucket release creation"
    fi

    echo "Release archive ready: ${RELEASE_DIR}.tar.gz"
    ls -lh "${RELEASE_DIR}.tar.gz"
else
    echo "No git tag detected; packaging only."
    echo "To create a release, push a tag like:"
    echo "  git tag v1.0.0"
    echo "  git push origin v1.0.0"
fi

echo "=== Build Complete ==="
echo "Artifacts in: $ROOT_DIR/build"
