#!/bin/sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -d "$SCRIPT_DIR/workspace/client/windows" ]; then
    ROOT_DIR=$SCRIPT_DIR/workspace
else
    ROOT_DIR=$SCRIPT_DIR
fi
ARTIFACT=${DEXAI_WINDOWS_ZIP:-}
DOWNLOAD_DIR=${ROOT_DIR}/.build-download
ARTIFACT_ROOT=${DEXAI_ARTIFACT_ROOT:-/home/ubuntu/.gitbucket/repositories/root/dexai.cpp/build}

cleanup() {
    rm -rf "$DOWNLOAD_DIR"
}
trap cleanup EXIT

if [ -z "$ARTIFACT" ]; then
    LATEST_ARTIFACT=
    for CANDIDATE in $(find "$ARTIFACT_ROOT" -path '*/workspace/artifacts/dexai-windows-x86_64.zip' -type f -size +0c -printf '%T@ %p\n' 2>/dev/null | sort -nr | sed 's/^[^ ]* //'); do
        if unzip -tqq "$CANDIDATE" >/dev/null 2>&1; then
            LATEST_ARTIFACT=$CANDIDATE
            break
        fi
    done
    if [ -n "$LATEST_ARTIFACT" ]; then
        mkdir -p "$DOWNLOAD_DIR"
        ARTIFACT="$DOWNLOAD_DIR/dexai-windows-x86_64.zip"
        cp "$LATEST_ARTIFACT" "$ARTIFACT"
    fi
fi

if [ -z "$ARTIFACT" ]; then
    echo "No successful Windows artifact found under: $ARTIFACT_ROOT" >&2
    exit 2
fi
if [ ! -f "$ARTIFACT" ]; then
    echo "Windows artifact not found: $ARTIFACT" >&2
    exit 1
fi

DEXAI_WINDOWS_ZIP="$ARTIFACT" \
    "$ROOT_DIR/client/windows/release.sh"

printf 'Build output: %s\n' "$ROOT_DIR/client/windows/dist/dexai-windows-client-x86_64.zip"
