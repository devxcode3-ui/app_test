#!/bin/sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
ARTIFACT=${DEXAI_WINDOWS_ZIP:-${1:-}}
OUTPUT_DIR=${OUTPUT_DIR:-$ROOT_DIR/client/windows/dist}
PACKAGE_NAME=${PACKAGE_NAME:-dexai-windows-client-x86_64}
WORK_DIR=${WORK_DIR:-$OUTPUT_DIR/.work}
APP_ARTIFACT_ROOT=${DEXAI_APP_ARTIFACT_ROOT:-/home/ubuntu/.gitbucket/repositories/root/dexai-apps/build/5/workspace/build}
POS_APP_ARCHIVE=${DEXAI_POS_APP_ARCHIVE:-$APP_ARTIFACT_ROOT/pos-app.tar.gz}
STORE_APP_ARCHIVE=${DEXAI_STORE_APP_ARCHIVE:-$APP_ARTIFACT_ROOT/store-app.tar.gz}
RELAY_AGENT=${DEXAI_RELAY_AGENT:-/home/ubuntu/.gitbucket/repositories/root/dexai-relay/build/3/workspace/bin/app-relay-agent-windows.exe}
DEXAI_CPP_ROOT=${DEXAI_CPP_ROOT:-/home/ubuntu/.gitbucket/repositories/root/dexai.cpp}
START_SERVER_SCRIPT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/bin/start-server.bat
STOP_SERVER_SCRIPT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/bin/stop-server.bat
RELAY_SYNC_SCRIPT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/bin/sync-relay-apps.ps1
RUNTIME_DLL_ROOT=${DEXAI_RUNTIME_DLL_ROOT:-$DEXAI_CPP_ROOT}
RELAY_CONFIG_SOURCE=${DEXAI_RELAY_CONFIG:-/home/ubuntu/llama_cpp/app_relay/agent.json}

if [ -z "$ARTIFACT" ]; then
    echo "Usage: DEXAI_WINDOWS_ZIP=/path/dexai-windows-x86_64.zip $0" >&2
    exit 2
fi
if [ ! -f "$ARTIFACT" ]; then
    echo "Windows artifact not found: $ARTIFACT" >&2
    exit 1
fi
for APP_ARCHIVE in "$POS_APP_ARCHIVE" "$STORE_APP_ARCHIVE"; do
    if [ ! -f "$APP_ARCHIVE" ]; then
        echo "Application archive not found: $APP_ARCHIVE" >&2
        exit 1
    fi
done
if [ ! -f "$RELAY_AGENT" ]; then
    echo "Relay agent not found: $RELAY_AGENT" >&2
    exit 1
fi
if [ ! -f "$RELAY_CONFIG_SOURCE" ]; then
    echo "Relay configuration not found: $RELAY_CONFIG_SOURCE" >&2
    exit 1
fi
for SERVER_SCRIPT in "$START_SERVER_SCRIPT" "$STOP_SERVER_SCRIPT" "$RELAY_SYNC_SCRIPT"; do
    if [ ! -f "$SERVER_SCRIPT" ]; then
        echo "Server script not found: $SERVER_SCRIPT" >&2
        exit 1
    fi
done
AGENTS_DB=
for CANDIDATE in $(find "$DEXAI_CPP_ROOT" -path '*/workspace/agents.db' -type f -size +0c -printf '%T@ %p\n' 2>/dev/null | sort -nr | sed 's/^[^ ]* //'); do
    AGENTS_DB=$CANDIDATE
    break
done
if [ -z "$AGENTS_DB" ]; then
    echo "Agents database not found under: $DEXAI_CPP_ROOT" >&2
    exit 1
fi

rm -rf "$WORK_DIR" "$OUTPUT_DIR/$PACKAGE_NAME" "$OUTPUT_DIR/$PACKAGE_NAME.zip"
mkdir -p "$WORK_DIR/extracted" "$OUTPUT_DIR/$PACKAGE_NAME/bin" \
    "$OUTPUT_DIR/$PACKAGE_NAME/lib" "$OUTPUT_DIR/$PACKAGE_NAME/app" \
    "$OUTPUT_DIR/$PACKAGE_NAME/data" \
    "$OUTPUT_DIR/$PACKAGE_NAME/logs"

unzip -q "$ARTIFACT" -d "$WORK_DIR/extracted"

find "$WORK_DIR/extracted" -type d -name bin -exec cp -R "{}/." \
    "$OUTPUT_DIR/$PACKAGE_NAME/bin/" \;
find "$WORK_DIR/extracted" -type d -name lib -exec cp -R "{}/." \
    "$OUTPUT_DIR/$PACKAGE_NAME/lib/" \;

find "$WORK_DIR/extracted" -type f \( -iname '*.exe' -o -iname '*.com' \) \
    -exec cp "{}" "$OUTPUT_DIR/$PACKAGE_NAME/bin/" \;
find "$WORK_DIR/extracted" -type f \( -iname '*.dll' -o -iname '*.lib' \) \
    -exec cp "{}" "$OUTPUT_DIR/$PACKAGE_NAME/lib/" \;

tar -xzf "$POS_APP_ARCHIVE" -C "$OUTPUT_DIR/$PACKAGE_NAME/app"
tar -xzf "$STORE_APP_ARCHIVE" -C "$OUTPUT_DIR/$PACKAGE_NAME/app"
cp "$RELAY_AGENT" "$OUTPUT_DIR/$PACKAGE_NAME/bin/app-relay-agent-windows.exe"
cp "$AGENTS_DB" "$OUTPUT_DIR/$PACKAGE_NAME/data/agents.db"
cp "$RELAY_CONFIG_SOURCE" "$OUTPUT_DIR/$PACKAGE_NAME/data/agent.json"
cp "$START_SERVER_SCRIPT" "$OUTPUT_DIR/$PACKAGE_NAME/bin/start-server.bat"
cp "$STOP_SERVER_SCRIPT" "$OUTPUT_DIR/$PACKAGE_NAME/bin/stop-server.bat"
cp "$RELAY_SYNC_SCRIPT" "$OUTPUT_DIR/$PACKAGE_NAME/bin/sync-relay-apps.ps1"
if [ -f "$OUTPUT_DIR/$PACKAGE_NAME/lib/libneedle.dll" ]; then
    cp "$OUTPUT_DIR/$PACKAGE_NAME/lib/libneedle.dll" "$OUTPUT_DIR/$PACKAGE_NAME/bin/libneedle.dll"
fi
for RUNTIME_DLL in libgcc_s_seh-1.dll libgomp-1.dll libstdc++-6.dll libwinpthread-1.dll; do
    RUNTIME_SOURCE=
    for CANDIDATE in $(find "$WORK_DIR/extracted" -type f -name "$RUNTIME_DLL" -size +0c -print 2>/dev/null); do
        RUNTIME_SOURCE=$CANDIDATE
        break
    done
    if [ -z "$RUNTIME_SOURCE" ]; then
        for CANDIDATE in $(find "$RUNTIME_DLL_ROOT" -path '*/workspace/build-release/'"$RUNTIME_DLL" -type f -size +0c -printf '%T@ %p\n' 2>/dev/null | sort -nr | sed 's/^[^ ]* //'); do
            RUNTIME_SOURCE=$CANDIDATE
            break
        done
    fi
    if [ -z "$RUNTIME_SOURCE" ]; then
        echo "Windows runtime DLL not found: $RUNTIME_DLL" >&2
        exit 1
    fi
    cp "$RUNTIME_SOURCE" "$OUTPUT_DIR/$PACKAGE_NAME/bin/$RUNTIME_DLL"
done

if ! find "$OUTPUT_DIR/$PACKAGE_NAME/bin" -type f -print -quit | grep -q .; then
    echo "The Windows artifact contains no executable files" >&2
    exit 1
fi

(cd "$OUTPUT_DIR" && zip -q -r "$PACKAGE_NAME.zip" "$PACKAGE_NAME")
rm -rf "$WORK_DIR"
echo "Created $OUTPUT_DIR/$PACKAGE_NAME.zip"