# Windows client release

Run `release.sh` with the latest `dexai-windows-x86_64.zip` archive:

```sh
DEXAI_WINDOWS_ZIP=/path/to/dexai-windows-x86_64.zip ./release.sh
```

The generated package contains `app/bin`, `app/lib`, `data`, and `logs` and is
written to `dist/dexai-windows-client-x86_64.zip`.