# DexAI installer

Installer packages are organized under `client/windows`, `client/linux`, and
`server`. The Windows package builder is documented in
`client/windows/README.md`.

Run the build script with a local release archive:

```sh
DEXAI_WINDOWS_ZIP=/path/to/dexai-windows-x86_64.zip ./build.sh
```

Or provide a downloadable archive URL with `DEXAI_WINDOWS_ZIP_URL`. The output
is `client/windows/dist/dexai-windows-client-x86_64.zip`.