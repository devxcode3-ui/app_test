#!/usr/bin/env bash

set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
env_file="$script_dir/local.env"

if [[ ! -f "$env_file" ]]; then
    umask 077
    python3 - "$env_file" <<'PY'
from pathlib import Path
import secrets
import sys

Path(sys.argv[1]).write_text(
    "POSTGRES_PASSWORD=" + secrets.token_hex(24) + "\n"
    "AUTHENTICATION_API_KEY=" + secrets.token_hex(32) + "\n"
    "EVOLUTION_INSTANCE=business\n"
    "EVOLUTION_API_URL=http://127.0.0.1:8080\n",
    encoding="utf-8",
)
PY
fi

cd "$script_dir"
docker compose --env-file local.env -f compose.yaml up -d

python3 - <<'PY'
import time
import urllib.request

request = urllib.request.Request(
    "http://127.0.0.1:3000/api/",
    headers={"Origin": "http://127.0.0.1:3000"},
)
for _ in range(120):
    try:
        with urllib.request.urlopen(request, timeout=2) as response:
            if response.status == 200:
                print("Evolution Manager: http://127.0.0.1:3000")
                print("Evolution API: http://127.0.0.1:8080")
                raise SystemExit(0)
    except Exception:
        time.sleep(1)
raise SystemExit("Evolution did not become ready within 120 seconds")
PY
