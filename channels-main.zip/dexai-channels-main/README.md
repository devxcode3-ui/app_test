# Evolution API standalone deployment

This package runs Evolution API 2.3.7 with the free Baileys connection, Evolution Manager, PostgreSQL, and Redis. It is intended for a host with unrestricted outbound WhatsApp connectivity.

## Requirements

- Docker with Compose support
- Python 3.10 or newer
- OpenSSL

## Start

```sh
chmod 750 start.sh
./start.sh
```

The first run creates `local.env` with random API and database credentials and mode `0600`. Keep this file private and back it up securely.

The default services listen only on loopback:

- Manager: `http://127.0.0.1:3000`
- API: `http://127.0.0.1:8080`

For a remote server, use an SSH tunnel from your workstation:

```sh
ssh -L 3000:127.0.0.1:3000 -L 8080:127.0.0.1:8080 your-user@your-server
```

Then open `http://127.0.0.1:3000`. In the Manager login form, use `http://127.0.0.1:3000/api` as the Server URL and copy `AUTHENTICATION_API_KEY` from `local.env` locally. Do not paste that key into chat or commit it.

## Pair WhatsApp

Create or open an instance named `business`, select the `WHATSAPP-BAILEYS` integration, and request its QR code. On the phone, open **WhatsApp > Settings > Linked devices > Link a device** and scan the QR. Wait until the instance state is `open`.

## Send the test message

Pass your destination number in international format without spaces or punctuation:

```sh
python3 send_hi.py --number 15551234567
```

The script first checks that `business` is connected, sends exactly one `Hi`, and prints the resulting message ID. It does not print the destination or API key.

## Stop

```sh
docker compose --env-file local.env -f compose.yaml down
```

Do not add `-v` unless you intend to permanently delete the database and paired WhatsApp session.

## Tests

```sh
python3 -m unittest -v test_send_hi.py
```

Scenarios:

- Given a connected instance, when the test runs, then exactly one `Hi` message is submitted.
- Given a disconnected instance, when the test runs, then no message is submitted.
- Given an invalid recipient number or API URL, when validation runs, then the request is rejected locally.
