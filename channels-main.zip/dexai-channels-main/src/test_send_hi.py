import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent))

import send_hi


class FakeResponse:
    def __init__(self, value):
        self.value = value

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self):
        return json.dumps(self.value).encode()


class SendHiTests(unittest.TestCase):
    def test_normalizes_international_number(self):
        self.assertEqual(send_hi.normalize_number("+15551234567"), "15551234567")

    def test_rejects_invalid_number(self):
        with self.assertRaises(ValueError):
            send_hi.normalize_number("+1 (555) 123")

    @patch("send_hi.urlopen")
    def test_checks_connection_and_sends_hi(self, mock_urlopen):
        mock_urlopen.side_effect = [
            FakeResponse({"instance": {"state": "open"}}),
            FakeResponse({"key": {"id": "message-1"}}),
        ]
        client = send_hi.EvolutionClient("http://127.0.0.1:8080", "secret", "business", "http://127.0.0.1:3000")

        self.assertEqual(client.connection_state(), "open")
        self.assertEqual(client.send_text("15551234567", "Hi"), "message-1")

        send_request = mock_urlopen.call_args_list[1].args[0]
        self.assertEqual(json.loads(send_request.data), {"number": "15551234567", "text": "Hi"})

    def test_rejects_api_url_with_path(self):
        with self.assertRaises(ValueError):
            send_hi.EvolutionClient("http://127.0.0.1:8080/api", "secret", "business", "http://127.0.0.1:3000")

    def test_disconnected_instance_does_not_send(self):
        client = Mock()
        client.connection_state.return_value = "close"

        with self.assertRaisesRegex(RuntimeError, "not connected"):
            send_hi.send_test_message(client, "15551234567", "Hi")

        client.send_text.assert_not_called()


if __name__ == "__main__":
    unittest.main()
