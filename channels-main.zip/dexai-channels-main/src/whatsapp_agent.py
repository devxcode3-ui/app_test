#!/usr/bin/env python3

import argparse
import base64
import json
import mimetypes
import os
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent))

from send_hi import EvolutionClient, load_env, normalize_number


MAX_MESSAGE_BYTES = 4096
MAX_INBOX_MESSAGES = 1000


def json_request(url: str, body: dict, headers: dict[str, str]) -> dict:
    request = Request(
        url,
        data=json.dumps(body, separators=(",", ":")).encode(),
        headers={"Content-Type": "application/json", **headers},
        method="POST",
    )
    with urlopen(request, timeout=60) as response:
        result = json.load(response)
    if not isinstance(result, dict):
        raise RuntimeError("llama-server returned an invalid response")
    return result


def message_text(message: dict) -> str:
    for key in ("conversation", "text", "caption"):
        value = message.get(key)
        if isinstance(value, str):
            return value
    for key in ("extendedTextMessage", "imageMessage", "documentMessage", "videoMessage"):
        nested = message.get(key)
        if isinstance(nested, dict):
            text = message_text(nested)
            if text:
                return text
    return ""


def message_record(payload: dict) -> dict | None:
    data = payload.get("data")
    candidates = data if isinstance(data, list) else [data]
    for item in candidates:
        if not isinstance(item, dict):
            continue
        key = item.get("key", {})
        if not isinstance(key, dict) or key.get("fromMe"):
            continue
        remote_jid = key.get("remoteJid")
        message = item.get("message")
        if not isinstance(remote_jid, str) or not isinstance(message, dict):
            continue
        return {
            "id": key.get("id", str(uuid.uuid4())),
            "sender": remote_jid,
            "text": message_text(message),
            "message_type": item.get("messageType", "text"),
            "message": message,
        }
    return None


class WhatsAppBridge:
    def __init__(self, env: dict[str, str], inbox: Path, media_dir: Path):
        self.client = EvolutionClient(
            env.get("EVOLUTION_API_URL", "http://127.0.0.1:8080"),
            env.get("AUTHENTICATION_API_KEY", ""),
            env.get("EVOLUTION_INSTANCE", "business"),
            env.get("EVOLUTION_ORIGIN", "http://127.0.0.1:3000"),
        )
        self.llama_url = env.get("LLAMA_SERVER_URL", "http://127.0.0.1:8081").rstrip("/")
        self.agent_id = env.get("LLAMA_AGENT_ID", "")
        self.agent_api_key = env.get("LLAMA_API_KEY", "")
        self.webhook_url = env.get("WHATSAPP_WEBHOOK_URL", "http://127.0.0.1:8765/webhook")
        self.inbox = inbox
        self.media_dir = media_dir
        self.inbox.parent.mkdir(parents=True, exist_ok=True)
        self.media_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()

    def append_message(self, record: dict) -> None:
        with self.lock, self.inbox.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, separators=(",", ":")) + "\n")

    def read_messages(self, limit: int = 20, sender: str = "") -> list[dict]:
        if not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100")
        if not self.inbox.exists():
            return []
        with self.lock:
            rows = [json.loads(line) for line in self.inbox.read_text(encoding="utf-8").splitlines() if line]
        if sender:
            rows = [row for row in rows if row.get("sender") == sender]
        return rows[-limit:]

    def materialize_media(self, record: dict) -> str | None:
        message = record["message"]
        media = next((message[key] for key in ("imageMessage", "documentMessage", "videoMessage") if isinstance(message.get(key), dict)), None)
        if not media:
            return None
        encoded = media.get("base64") or message.get("base64")
        if not isinstance(encoded, str):
            result = self.client.request(
                "POST",
                f"/chat/getBase64FromMediaMessage/{quote(self.client.instance, safe='')}",
                {"message": message, "convertToMp4": False},
            )
            encoded = result.get("base64")
        if not isinstance(encoded, str):
            raise RuntimeError("Evolution API did not return media data")
        suffix = Path(media.get("fileName", "")).suffix or mimetypes.guess_extension(media.get("mimetype", "")) or ".bin"
        path = self.media_dir / f"{record['id']}{suffix}"
        path.write_bytes(base64.b64decode(encoded))
        return str(path)

    def process(self, record: dict) -> dict:
        media_path = self.materialize_media(record)
        prompt = (
            "Process this WhatsApp request using the available tools. "
            "When a response is needed, send it back with the WhatsApp send tool "
            f"to {record['sender']}.\n"
            f"Sender: {record['sender']}\nMessage: {record['text'] or '(no text)'}"
        )
        if media_path:
            prompt += f"\nAttachment path: {media_path}"
        if not self.agent_id:
            raise RuntimeError("LLAMA_AGENT_ID is required")
        headers = {"Authorization": f"Bearer {self.agent_api_key}"} if self.agent_api_key else {}
        return json_request(
            f"{self.llama_url}/v1/agents/{quote(self.agent_id, safe='')}/run",
            {"prompt": prompt, "allow_write": True},
            headers,
        )


class WebhookHandler(BaseHTTPRequestHandler):
    bridge: WhatsAppBridge

    def do_POST(self) -> None:
        if self.path != "/webhook":
            self.send_error(404)
            return
        try:
            payload = json.loads(self.rfile.read(int(self.headers.get("Content-Length", "0"))))
            record = message_record(payload)
            if record:
                self.bridge.append_message(record)
                result = self.bridge.process(record)
            else:
                result = {"status": "ignored"}
            body = json.dumps(result).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except (ValueError, RuntimeError, json.JSONDecodeError, OSError) as error:
            body = json.dumps({"error": str(error)}).encode()
            self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    def log_message(self, *_args) -> None:
        return


def mcp_tools() -> list[dict]:
    return [
        {"name": "whatsapp_read_messages", "description": "Read recent inbound WhatsApp messages.", "inputSchema": {"type": "object", "properties": {"limit": {"type": "integer"}, "sender": {"type": "string"}}}},
        {"name": "whatsapp_send_text", "description": "Send a text message on WhatsApp.", "inputSchema": {"type": "object", "properties": {"number": {"type": "string"}, "text": {"type": "string"}}, "required": ["number", "text"]}},
        {"name": "whatsapp_send_media", "description": "Send an invoice or other media file on WhatsApp.", "inputSchema": {"type": "object", "properties": {"number": {"type": "string"}, "media_path": {"type": "string"}, "caption": {"type": "string"}}, "required": ["number", "media_path"]}},
    ]


def run_mcp(bridge: WhatsAppBridge) -> int:
    for line in sys.stdin:
        request = json.loads(line)
        method = request.get("method")
        request_id = request.get("id")
        if method == "initialize":
            result = {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}, "serverInfo": {"name": "whatsapp", "version": "1.0"}}
        elif method == "notifications/initialized":
            continue
        elif method == "tools/list":
            result = {"tools": mcp_tools()}
        elif method == "tools/call":
            args = request.get("params", {}).get("arguments", {})
            name = request.get("params", {}).get("name")
            if name == "whatsapp_read_messages":
                value = bridge.read_messages(args.get("limit", 20), args.get("sender", ""))
            elif name == "whatsapp_send_text":
                number = args["number"]
                number = normalize_number(number) if "@" not in number else number
                text = args["text"]
                if not text or len(text.encode()) > MAX_MESSAGE_BYTES:
                    raise ValueError("text must contain 1 to 4096 bytes")
                value = {"message_id": bridge.client.send_text(number, text)}
            elif name == "whatsapp_send_media":
                value = {"message_id": bridge.client.send_media(args["number"], args["media_path"], args.get("caption", ""))}
            else:
                raise ValueError("unknown WhatsApp tool")
            result = {"content": [{"type": "text", "text": json.dumps(value)}]}
        else:
            continue
        print(json.dumps({"jsonrpc": "2.0", "id": request_id, "result": result}), flush=True)
    return 0


def register_webhook(bridge: WhatsAppBridge) -> None:
    bridge.client.request("POST", f"/webhook/set/{quote(bridge.client.instance, safe='')}", {"enabled": True, "url": bridge.webhook_url, "webhookByEvents": False, "webhookBase64": True, "events": ["MESSAGES_UPSERT"]})


def main() -> int:
    parser = argparse.ArgumentParser(description="Bridge Evolution WhatsApp messages to a llama.cpp agent.")
    parser.add_argument("command", choices=["serve", "mcp", "register-webhook"])
    parser.add_argument("--env-file", type=Path, default=Path(__file__).with_name("local.env"))
    parser.add_argument("--inbox", type=Path, default=Path(__file__).with_name("data") / "whatsapp-inbox.jsonl")
    parser.add_argument("--media-dir", type=Path, default=Path(__file__).with_name("data") / "whatsapp-media")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    bridge = WhatsAppBridge(load_env(args.env_file), args.inbox, args.media_dir)
    if args.command == "mcp":
        return run_mcp(bridge)
    if args.command == "register-webhook":
        register_webhook(bridge)
        print(json.dumps({"status": "registered", "url": bridge.webhook_url}))
        return 0
    WebhookHandler.bridge = bridge
    register_webhook(bridge)
    ThreadingHTTPServer((args.host, args.port), WebhookHandler).serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())