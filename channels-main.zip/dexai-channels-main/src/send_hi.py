#!/usr/bin/env python3

import argparse
import base64
import json
import mimetypes
import re
import sys
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen


def load_env(path: Path) -> dict[str, str]:
    values = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ValueError(f"invalid environment line in {path.name}")
        key, value = line.split("=", 1)
        values[key] = value
    return values


def normalize_number(value: str) -> str:
    number = value.strip().removeprefix("+")
    if not re.fullmatch(r"[0-9]{7,20}", number):
        raise ValueError("number must contain 7 to 20 digits, with an optional leading +")
    return number


class EvolutionClient:
    def __init__(self, base_url: str, api_key: str, instance: str, origin: str):
        parsed = urlparse(base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.path not in {"", "/"}:
            raise ValueError("EVOLUTION_API_URL must be an HTTP origin without a path")
        if not api_key or not instance:
            raise ValueError("API key and instance are required")
        self.base_url = base_url.rstrip("/")
        self.headers = {"Content-Type": "application/json", "Origin": origin, "apikey": api_key}
        self.instance = instance

    def request(self, method: str, path: str, body: dict | None = None) -> dict:
        data = json.dumps(body, separators=(",", ":")).encode() if body is not None else None
        request = Request(self.base_url + path, data=data, headers=self.headers, method=method)
        try:
            with urlopen(request, timeout=20) as response:
                result = json.load(response)
        except HTTPError as error:
            error.close()
            raise RuntimeError(f"Evolution API returned HTTP {error.code}") from None
        except URLError:
            raise RuntimeError("Evolution API is unavailable") from None
        if not isinstance(result, dict):
            raise RuntimeError("Evolution API returned an invalid response")
        return result

    def connection_state(self) -> str:
        result = self.request("GET", f"/instance/connectionState/{quote(self.instance, safe='')}")
        instance = result.get("instance", {})
        state = instance.get("state") if isinstance(instance, dict) else None
        if not isinstance(state, str):
            raise RuntimeError("Evolution API did not return a connection state")
        return state

    def send_text(self, number: str, text: str) -> str:
        result = self.request(
            "POST",
            f"/message/sendText/{quote(self.instance, safe='')}",
            {"number": number, "text": text},
        )
        message_id = result.get("key", {}).get("id")
        if not isinstance(message_id, str) or not message_id:
            raise RuntimeError("Evolution API did not return a message ID")
        return message_id

    def send_media(self, number: str, media_path: str, caption: str = "") -> str:
        path = Path(media_path)
        if not path.is_file():
            raise ValueError("media file does not exist")
        media_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        result = self.request(
            "POST",
            f"/message/sendMedia/{quote(self.instance, safe='')}",
            {"number": number, "mediatype": media_type.split("/", 1)[0], "mimetype": media_type, "caption": caption, "media": base64.b64encode(path.read_bytes()).decode(), "fileName": path.name},
        )
        message_id = result.get("key", {}).get("id")
        if not isinstance(message_id, str) or not message_id:
            raise RuntimeError("Evolution API did not return a message ID")
        return message_id


def send_test_message(client: EvolutionClient, number: str, text: str) -> str:
    state = client.connection_state()
    if state != "open":
        raise RuntimeError(f"WhatsApp instance is not connected (state: {state})")
    return client.send_text(number, text)


def main() -> int:
    parser = argparse.ArgumentParser(description="Send one WhatsApp test message through Evolution API.")
    parser.add_argument("--number", required=True, help="Destination in international format, for example 15551234567")
    parser.add_argument("--message", default="Hi")
    parser.add_argument("--env-file", type=Path, default=Path(__file__).with_name("local.env"))
    args = parser.parse_args()

    try:
        env = load_env(args.env_file)
        number = normalize_number(args.number)
        text = args.message.strip()
        if not text or len(text.encode()) > 4096:
            raise ValueError("message must contain 1 to 4096 bytes")
        client = EvolutionClient(
            env.get("EVOLUTION_API_URL", "http://127.0.0.1:8080"),
            env.get("AUTHENTICATION_API_KEY", ""),
            env.get("EVOLUTION_INSTANCE", "business"),
            "http://127.0.0.1:3000",
        )
        message_id = send_test_message(client, number, text)
        print(json.dumps({"status": "sent", "message_id": message_id}))
        return 0
    except (OSError, ValueError, RuntimeError) as error:
        print(f"send failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
