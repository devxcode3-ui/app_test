#!/usr/bin/env python
import urllib.request, json
data=json.load(urllib.request.urlopen('http://127.0.0.1:18093/v1/apps'))
apps = data.get('apps', [])
print(f'Loaded apps: {len(apps)}')
for a in apps:
    print(f"  - {a.get('name')}: {a.get('launch_url')}")
    tools = a.get('tools', [])
    if tools:
        print(f"    Tools: {tools[:3]}")
