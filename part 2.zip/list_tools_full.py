#!/usr/bin/env python
import urllib.request, json

data=json.load(urllib.request.urlopen('http://127.0.0.1:18093/tools'))
print(f'Total tools: {len(data)}')
for i, item in enumerate(data):
    name = item.get('tool') or item.get('definition',{}).get('function',{}).get('name','?')
    server = item.get('serverName', 'built-in')
    print(f'{i+1}. {name} [{server}]')
