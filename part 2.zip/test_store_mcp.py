#!/usr/bin/env python
import subprocess
import json

# Start Store service in MCP mode
p = subprocess.Popen(
    ['python', r'D:\Projects\llama_cpp\temp\store\store_service.py', 'mcp', '--db', r'D:\Projects\llama_cpp\temp\store\data\store.db'],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    bufsize=1
)

# Send initialize request
init_req = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {}})
p.stdin.write(init_req + '\n')
p.stdin.flush()

# Read response
line = p.stdout.readline()
print(f'Initialize response: {line[:100] if line else "NO RESPONSE"}...')

# Send tools/list request
tools_req = json.dumps({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list'})
p.stdin.write(tools_req + '\n')
p.stdin.flush()

# Read response
line = p.stdout.readline()
if line:
    resp = json.loads(line)
    tools = resp.get('result', {}).get('tools', [])
    print(f'Store MCP returned {len(tools)} tools:')
    for tool in tools:
        print(f"  - {tool.get('name')}")
else:
    print('No response from Store service')

p.terminate()
